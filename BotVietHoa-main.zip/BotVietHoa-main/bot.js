
const { Client, GatewayIntentBits, REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');

// Khởi tạo client
const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages] });

// Đọc config.json
const config = JSON.parse(fs.readFileSync('./config.json', 'utf-8'));

// Import các chức năng
const { setupPremiumCommands, handlePremium, checkRoleExpiry } = require('./chucnang/Premium');
const { setupVietHoaCommands, handleVietHoa } = require('./chucnang/VietHoa');
const { setupClearChatCommands, handleClearChat } = require('./chucnang/ClearChat');
const { autoRemoveMessages } = require('./chucnang/AutoRemove');
const { setupStatusCommands, handleStatus } = require('./chucnang/Status');

// Sự kiện khi bot đã sẵn sàng
client.once('ready', async () => {
    console.log('Bot đã sẵn sàng!');
    
    // Đăng ký các lệnh
    const commands = [
        ...await setupPremiumCommands(), // Đảm bảo gọi hàm với await
        ...setupVietHoaCommands(),
        ...setupClearChatCommands(),
        ...setupStatusCommands()
    ];

    const rest = new REST({ version: '10' }).setToken(config.token);

    try {
        console.log('Đang làm mới các lệnh ứng dụng (/)');

        await rest.put(
            Routes.applicationGuildCommands(config.clientId, config.guildId),
            { body: commands }
        );

        console.log('Đã làm mới thành công các lệnh ứng dụng (/)');
    } catch (error) {
        console.error(error);
    }

    // Thiết lập kiểm tra định kỳ để thu hồi roles đã hết hạn
    setInterval(() => checkRoleExpiry(client), 60 * 1000); // Kiểm tra mỗi phút
});

// Xử lý lệnh tương tác
client.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;
    const { commandName } = interaction;

    switch (commandName) {
        case 'viethoa':
            await handleVietHoa(interaction);
            break;
        case 'clear':
            await handleClearChat(interaction);
            break;
        case 'kichhoat':
        case 'huydichvu':
        case 'kiemtradichvu':
            await handlePremium(interaction);
            break;
        case 'uptime':
        case 'ping':
            await handleStatus(interaction);
            break;
        default:
            await interaction.reply({ content: 'Lệnh không hợp lệ!', ephemeral: true });
    }
});

// Xóa tin nhắn tự động
client.on('messageCreate', async message => {
    autoRemoveMessages(message);
});

// Đăng nhập bot
client.login(config.token);
