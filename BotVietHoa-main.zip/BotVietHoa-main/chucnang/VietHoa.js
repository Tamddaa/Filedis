const { SlashCommandBuilder, EmbedBuilder, ActivityType } = require('discord.js');
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const yaml = require('js-yaml');
const prompts = require('../data/prompts');
const crypto = require('crypto');

let isTranslating = false;
let translationQueue = []; // Hàng đợi để xử lý yêu cầu dịch
let currentFileName;

// Đọc config.json
const config = JSON.parse(fs.readFileSync('./config.json', 'utf-8'));
const statsFilePath = path.join(__dirname, '../data/translation_stats.json');

const readTotalTranslatedFiles = () => {
    if (fs.existsSync(statsFilePath)) {
        const stats = JSON.parse(fs.readFileSync(statsFilePath, 'utf-8'));
        return stats.totalTranslatedFiles || 0;
    }
    return 0;
};

const updateTotalTranslatedFiles = (count) => {
    const stats = { totalTranslatedFiles: count };
    fs.writeFileSync(statsFilePath, JSON.stringify(stats), 'utf-8');
};

let totalTranslatedFiles = readTotalTranslatedFiles();

const ensureDirectoryExistence = (directory) => {
    if (!fs.existsSync(directory)) {
        fs.mkdirSync(directory, { recursive: true });
        console.log(`Thư mục đã được tạo: ${directory}`);
    }
};

const writeFile = (filePath, content) => {
    const directory = path.dirname(filePath);
    ensureDirectoryExistence(directory);
    fs.writeFileSync(filePath, content, 'utf-8');
};

const splitYamlContent = (content, maxLength) => {
    try {
        const yamlDoc = yaml.load(content);
        const entries = Object.entries(yamlDoc);
        const parts = [];
        let currentPart = {};
        let currentSize = 0;

        for (const [key, value] of entries) {
            const entryYaml = yaml.dump({ [key]: value });
            if (currentSize + entryYaml.length > maxLength && Object.keys(currentPart).length > 0) {
                parts.push(yaml.dump(currentPart, { 
                    indent: 2,
                    lineWidth: -1,
                    quotingType: '"',
                    forceQuotes: false 
                }));
                currentPart = {};
                currentSize = 0;
            }
            currentPart[key] = value;
            currentSize += entryYaml.length;
        }

        if (Object.keys(currentPart).length > 0) {
            parts.push(yaml.dump(currentPart, { 
                indent: 2,
                lineWidth: -1,
                quotingType: '"',
                forceQuotes: false 
            }));
        }

        return parts;
    } catch (error) {
        console.error('Lỗi khi chia nhỏ YAML:', error);
        throw error;
    }
};

const mergeParts = (parts) => {
    try {
        const mergedObj = {};
        for (const part of parts) {
            try {
                const partObj = yaml.load(part);
                if (partObj && typeof partObj === 'object') {
                    Object.assign(mergedObj, partObj);
                }
            } catch (error) {
                console.error('Lỗi khi phân tích phần:', error);
                console.log('Phần có vấn đề:', part);
            }
        }
        return yaml.dump(mergedObj, {
            indent: 2,
            lineWidth: -1,
            quotingType: '"',
            forceQuotes: false
        });
    } catch (error) {
        console.error('Lỗi khi hợp nhất các phần YAML:', error);
        throw error;
    }
};

const cleanYamlString = (str) => {
    return str.replace(/```yaml\n?|```\n?/g, '')
              .replace(/^\s+|\s+$/g, '');
};

const translatePart = async (prompt, part) => {
    try {
        const response = await axios.post('https://api.zukijourney.com/v1/chat/completions', {

            model: 'gpt-4o-mini',
            messages: [
                { role: 'system', content: prompt },
                { role: 'user', content: part }
            ],
            temperature: 1,
            max_tokens: 13000
        }, {
            headers: {
                'Authorization': `Bearer ${config.openai}`,
                'Content-Type': 'application/json'
            }
        });

        let translatedContent = response.data.choices[0].message.content;
        translatedContent = cleanYamlString(translatedContent);

        try {
            yaml.load(translatedContent);
        } catch (error) {
            console.error('YAML không hợp lệ trong kết quả dịch:', error);
            throw new Error('Dịch dẫn đến cấu trúc YAML không hợp lệ');
        }

        return translatedContent;
    } catch (error) {
        console.error('Lỗi dịch:', error);
        throw error;
    }
};

const generateRandomString = (length) => {
    return crypto.randomBytes(length).toString('hex').slice(0, length);
};

const processQueue = async () => {
    if (isTranslating || translationQueue.length === 0) return;

    const { filePath, originalFileName, interaction } = translationQueue.shift();
    await processFile(filePath, originalFileName, interaction);

    // Thông báo trạng thái hàng đợi
    if (translationQueue.length > 0) {
        const nextInQueue = translationQueue[0].originalFileName;
        await interaction.channel.send({
            embeds: [
                new EmbedBuilder()
                    .setColor('#3498DB')
                    .setTitle('🔄 Hàng đợi dịch')
                    .setDescription(`📄 **File tiếp theo trong hàng đợi:** \`${nextInQueue}\`\n🕒 Vui lòng chờ...`)
                    .setFooter({ text: '@Nexus Studio', iconURL: interaction.client.user.displayAvatarURL() })
            ]
        });
    }
};
const scheduleFileCleanup = (outputFilePath) => {
    setTimeout(() => {
        try {
            if (fs.existsSync(outputFilePath)) {
                fs.unlinkSync(outputFilePath);
                console.log(`Đã xóa file output sau 5 phút: ${outputFilePath}`);
            }
        } catch (error) {
            console.error(`Lỗi khi xóa file ${outputFilePath}:`, error);
        }
    }, 30 * 1000); // 30 giây
};
const processFile = async (filePath, originalFileName, interaction) => {
    if (isTranslating) return;

    isTranslating = true;
    currentFileName = originalFileName;

    try {
        const content = fs.readFileSync(filePath, 'utf-8');
        const credit = `# Facebook: https://www.facebook.com/tazukivn ; Discord: https://discord.gg/nexusstudio\n` +
            `##########################################\n` +
            `# |  -> Auto Việt Hoá By Tuyền |  #\n` +
            `##########################################\n\n`;

        try {
            yaml.load(content);
        } catch (error) {
            throw new Error('File YAML đầu vào không hợp lệ');
        }
        
        const parts = splitYamlContent(content, 1000);

        const replyMessage = await interaction.followUp({
            embeds: [
                new EmbedBuilder()
                    .setColor('#4B0082')
                    .setTitle('🌹 Đã Phân tích thành công')
                    .setDescription(`📊 **File:** \`${originalFileName}\`\n> - 📁 File đã được chia thành \`${parts.length}\` phần.\n> - 📝 Bắt đầu quá trình dịch...`)
                    .setThumbnail('https://media.discordapp.net/attachments/1267428542958928024/1302255825406001273/a_1a8fc652acd911f92403f024bd2fa6ad.png?ex=672773bf&is=6726223f&hm=21e6da590446dcd323d6601fd9a77e00e06fcfab7b7230afecf24a902ff8fd24&=&format=webp&quality=lossless&width=359&height=359')
                    .setFooter({ text: '@Nexus Studio', iconURL: interaction.client.user.displayAvatarURL() })
                    .setTimestamp()
            ]
        });

        const translatedParts = [];
        const translationPrompt = prompts.translateYaml("Vietnamese");

        for (let i = 0; i < parts.length; i++) {
            await replyMessage.edit({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#FFC300')
                        .setTitle('Tiến trình Việt hoá 📊')
                        .setDescription(`> - 📝 Đang dịch phần \`${i + 1}/${parts.length}\`...`)
                        .setThumbnail('https://media.discordapp.net/attachments/1267428542958928024/1302255825406001273/a_1a8fc652acd911f92403f024bd2fa6ad.png?ex=672773bf&is=6726223f&hm=21e6da590446dcd323d6601fd9a77e00e06fcfab7b7230afecf24a902ff8fd24&=&format=webp&quality=lossless&width=359&height=359')
                        .setFooter({ text: '@Nexus Studio', iconURL: interaction.client.user.displayAvatarURL() })
                ]
            });
            const translatedPart = await translatePart(translationPrompt, parts[i]);
            translatedParts.push(translatedPart);
        }

        const translatedContent = credit + mergeParts(translatedParts);

        const randomString = generateRandomString(6);
        const baseFileName = path.basename(originalFileName, path.extname(originalFileName));
        const outputFileName = `${baseFileName}_${randomString}.yml`;
        const outputFilePath = path.join('./File/output_files', outputFileName);
        writeFile(outputFilePath, translatedContent);

        // Xóa file input sau khi dịch xong
        fs.unlinkSync(filePath);
        console.log(`Đã xóa file input: ${filePath}`);

        await replyMessage.edit({
            embeds: [
                new EmbedBuilder()
                    .setColor('#2ECC71')
                    .setTitle('📜 ✅ Việt Hoá Hoàn tất')
                    .setDescription(`**💕 Tên File:** \`${originalFileName}\`\n> - 📚 Có tổng \`${parts.length}\` phần... được dịch\n> - 🔰 File đã được gửi riêng cho bạn, hãy check DMs\n> - 🗑️ File input đã được tự động xóa`)
                    .setThumbnail('https://media.discordapp.net/attachments/1267428542958928024/1302255825406001273/a_1a8fc652acd911f92403f024bd2fa6ad.png?ex=672773bf&is=6726223f&hm=21e6da590446dcd323d6601fd9a77e00e06fcfab7b7230afecf24a902ff8fd24&=&format=webp&quality=lossless&width=359&height=359')
                    .setFooter({ text: '@Nexus Studio', iconURL: interaction.client.user.displayAvatarURL() })
            ]
        });

        const logChannel = interaction.client.channels.cache.get(config.logChannelId);
        if (logChannel) {
            await logChannel.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#2ECC71')
                        .setTitle('Lịch Sử Việt Hoá 🗓️')
                        .setDescription(`**🔰 Discord:** <@${interaction.user.id}> | \`(${interaction.user.id})\`\n**🕐 Thời gian:** \`${new Date().toLocaleString()}\`\n**🧷 File Việt Hoá:** \`${originalFileName}\``)
                        .setImage('https://i.imgur.com/8kkhXYf.gif')
                        .setFooter({ text: '@Nexus Studio', iconURL: interaction.client.user.displayAvatarURL() })
                ],
                files: [outputFilePath]
            });
        }
        const user = interaction.client.users.cache.get('1155358959755071518');
        if (user) {
            await user.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#2ECC71')
                        .setTitle('Lịch Sử Việt Hoá 🗓️')
                        .setDescription(`**🔰 Discord:** <@${interaction.user.id}> | \`(${interaction.user.id})\`\n**🕐 Thời gian:** \`${new Date().toLocaleString()}\`\n**🧷 File Việt Hoá:** \`${originalFileName}\``)
                        .setImage('https://i.imgur.com/8kkhXYf.gif')
                        .setFooter({ text: '@Nexus Studio', iconURL: interaction.client.user.displayAvatarURL() })
                ],
                files: [outputFilePath]
            });
        }

        // Send to user and schedule file cleanup
        await interaction.user.send({
            embeds: [
                new EmbedBuilder()
                    .setColor('#2ECC71')
                    .setTitle('✅ 📦 File của bạn đã được dịch')
                    .setDescription(`🧷 File: \`${originalFileName}\`\n🔰 Discord: <@${interaction.user.id}>\n🕐 Thời gian: \`${new Date().toLocaleString()}\`\n⏰ File sẽ tự động xóa sau 5 phút`)
                    .setThumbnail('https://media.discordapp.net/attachments/1267428542958928024/1302255825406001273/a_1a8fc652acd911f92403f024bd2fa6ad.png?ex=672773bf&is=6726223f&hm=21e6da590446dcd323d6601fd9a77e00e06fcfab7b7230afecf24a902ff8fd24&=&format=webp&quality=lossless&width=359&height=359')
                    .setFooter({ text: '@Nexus Studio', iconURL: interaction.client.user.displayAvatarURL() })
            ],
            files: [outputFilePath]
        });

        // Schedule the output file for deletion after 5 minutes
        scheduleFileCleanup(outputFilePath);

        totalTranslatedFiles++;
        updateTotalTranslatedFiles(totalTranslatedFiles);
    } catch (error) {
        console.error(error);
        await interaction.followUp({ 
            embeds: [new EmbedBuilder()
                .setColor('#FF0000')
                .setDescription(`❌ Lỗi khi xử lý tệp: ${error.message}`)]
        });
    } finally {
        isTranslating = false;
        updateBotStatus(interaction.client);
        processQueue(); // Xử lý mục tiếp theo trong hàng đợi
    }
};

function updateBotStatus(client) {
    if (isTranslating) {
        client.user.setActivity(`GPT | Đang việt hoá file (${currentFileName})`, { type: ActivityType.Playing });
    } else {
        client.user.setActivity(`GPT | Đã việt hoá tổng ${totalTranslatedFiles} file | @Bot By TazukiVN`, { type: ActivityType.Playing });
    }
}

function setupVietHoaCommands() {
    return [
        new SlashCommandBuilder()
            .setName('viethoa')
            .setDescription('📝 Việt hóa file YAML')
            .addAttachmentOption(option => 
                option.setName('file')
                      .setDescription('📄 File YAML cần việt hóa')
                      .setRequired(true)
            )
    ];
}

async function handleVietHoa(interaction) {
    const config = JSON.parse(fs.readFileSync('./config.json', 'utf-8'));
    if (interaction.commandName === 'viethoa') {
        if (interaction.channelId !== config.channel) {
            await interaction.reply({ 
                embeds: [new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('❌ Bot chỉ hoạt động trong kênh được chỉ định.\n')
                    .setFooter({ text: '@Nexus Studio', iconURL: interaction.client.user.displayAvatarURL() })
                ],
                ephemeral: true
            });
            return;
        }

        const file = interaction.options.getAttachment('file');
        if (!file) {
            await interaction.reply({ 
                embeds: [new EmbedBuilder()
                    .setColor('#FFA500')
                    .setDescription('⚠️ Vui lòng chọn một file .yml hoặc .yaml.\n')
                    .setFooter({ text: '@Nexus Studio', iconURL: interaction.client.user.displayAvatarURL() })
                ]
            });
            return;
        }
        if (file.name.endsWith('.yaml') || file.name.endsWith('.yml')) {
            const filePath = path.join('./File/input_files', file.name);
            try {
                const response = await axios.get(file.url, { responseType: 'arraybuffer' });
                fs.writeFileSync(filePath, response.data);
                await interaction.reply({ 
                    embeds: [new EmbedBuilder()
                        .setColor('#0000FF')
                        .setDescription(`☄️ Đang Phân tích file \`${file.name}\` ...\n`)
                        .setFooter({ text: '@Nexus Studio', iconURL: interaction.client.user.displayAvatarURL() })
                    ]
                });
                translationQueue.push({ filePath, originalFileName: file.name, interaction });
                processQueue(); // Bắt đầu xử lý hàng đợi
            } catch (error) {
                console.error(error);
                await interaction.followUp({ 
                    embeds: [new EmbedBuilder()
                        .setColor('#FF0000')
                        .setDescription('❌ Đã xảy ra lỗi khi xử lý tệp.\n')
                        .setFooter({ text: '@Nexus Studio', iconURL: interaction.client.user.displayAvatarURL() })
                    ]
                });
            }
        } else {
            await interaction.reply({ 
                embeds: [new EmbedBuilder()
                    .setColor('#FFA500')
                    .setDescription('⚠️ Vui lòng tải lên tệp .yaml hoặc .yml.\n')
                    .setFooter({ text: '@Nexus Studio', iconURL: interaction.client.user.displayAvatarURL() })
                ]
            });
        }
    }
}

module.exports = {
    setupVietHoaCommands,
    handleVietHoa
};
