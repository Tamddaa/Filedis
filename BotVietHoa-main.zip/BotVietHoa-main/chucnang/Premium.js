
const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

// Đọc config.json
const config = JSON.parse(fs.readFileSync('./config.json', 'utf-8'));

const rolesExpiryFilePath = path.join(__dirname, '../roles_expiry.json');
let userRolesExpiry = loadRolesExpiry();

function loadRolesExpiry() {
    if (!fs.existsSync(rolesExpiryFilePath)) return {};

    const content = fs.readFileSync(rolesExpiryFilePath, 'utf-8');
    try {
        return JSON.parse(content);
    } catch (error) {
        console.error("Error loading roles expiry data:", error.message);
        return {}; // Trả về rỗng nếu có lỗi
    }
}

function saveRolesExpiry() {
    fs.writeFileSync(rolesExpiryFilePath, JSON.stringify(userRolesExpiry, null, 2), 'utf-8');
}

async function checkRoleExpiry(client) {
    const currentTime = Date.now();
    for (const userId in userRolesExpiry) {
        const expiryTimestamp = userRolesExpiry[userId];

        if (expiryTimestamp <= currentTime) {
            const guild = client.guilds.cache.get(config.guildId);
            if (!guild) continue;

            const member = await guild.members.fetch(userId).catch(() => null);
            const role = guild.roles.cache.get(config.roles);

            if (member && role) {
                await member.roles.remove(role);
                console.log(`Role đã được xóa cho ${member.user.tag}`);
                delete userRolesExpiry[userId]; // Xóa khỏi danh sách
                await sendExpiryNotification(member); // Gửi thông báo hết hạn
            }
        }
    }
    saveRolesExpiry(); // Lưu file mỗi khi kiểm tra hết hạn
}

async function sendExpiryNotification(member) {
    await member.send(`❌ Vai trò của bạn đã hết hạn. Vui lòng gia hạn để tiếp tục sử dụng dịch vụ.`);
}

async function setupPremiumCommands() {
    return [
        new SlashCommandBuilder()
            .setName('kichhoat')
            .setDescription('🔑 Cấp quyền cho người dùng với thời gian chỉ định')
            .addUserOption(option => option.setName('user').setDescription('👤 Người dùng cần cấp quyền').setRequired(true))
            .addIntegerOption(option => option.setName('days').setDescription('🕒 Số ngày để cấp quyền').setRequired(false))
            .addIntegerOption(option => option.setName('hours').setDescription('🕒 Số giờ để cấp quyền').setRequired(false))
            .addIntegerOption(option => option.setName('minutes').setDescription('🕒 Số phút để cấp quyền').setRequired(false)),
        new SlashCommandBuilder()
            .setName('kiemtra')
            .setDescription('🔍 Kiểm tra dịch vụ của một người dùng')
            .addUserOption(option => option.setName('user').setDescription('👤 Người dùng cần kiểm tra').setRequired(true)),
        new SlashCommandBuilder()
            .setName('kiemtradichvu')
            .setDescription('🔍 Kiểm tra thời gian còn lại của vai trò được cấp'),
        new SlashCommandBuilder()
            .setName('huydichvu')
            .setDescription('🚫 Hủy dịch vụ của người dùng')
            .addUserOption(option => option.setName('user').setDescription('👤 Người dùng cần hủy dịch vụ').setRequired(true))
            .addStringOption(option => option.setName('reason').setDescription('✏️ Lý do hủy dịch vụ').setRequired(false)),
        new SlashCommandBuilder()
            .setName('listuser')
            .setDescription('📜 Hiển thị tất cả người dùng với thời gian vai trò hết hạn'),
    ];
}

async function handlePremium(interaction) {
    const command = interaction.commandName;
    switch (command) {
        case 'kichhoat':
            await activateRole(interaction);
            break;
        case 'kiemtra':
            await checkService(interaction);
            break;
        case 'kiemtradichvu':
            await checkUserService(interaction);
            break;
        case 'huydichvu':
            await cancelService(interaction);
            break;
        case 'listuser':
            await listUsers(interaction);
            break;
    }
}

async function activateRole(interaction) {
    const user = interaction.options.getUser('user');
    const days = interaction.options.getInteger('days') || 0;
    const hours = interaction.options.getInteger('hours') || 0;
    const minutes = interaction.options.getInteger('minutes') || 0;

    const guild = interaction.guild;
    const member = await guild.members.fetch(user.id).catch(() => null);
    const role = guild.roles.cache.get(config.roles);

    if (member && role) {
        const expiryDate = Date.now() + (days * 86400000) + (hours * 3600000) + (minutes * 60000);
        userRolesExpiry[user.id] = expiryDate; // Cập nhật thời gian hết hạn
        saveRolesExpiry(); // Lưu lại file dưới định dạng mới
        await member.roles.add(role);
        
        // Ghi lại thông tin hết hạn vào file
        const timeString = `${days}ngay${hours}gio${minutes}phut`;
        userRolesExpiry[`${user.id}`] = expiryDate; // Trả về số millisecond
       
        await interaction.reply(`🎉 Đã cấp quyền cho ${user.tag} trong ${days} ngày, ${hours} giờ, và ${minutes} phút.`);
    } else {
        await interaction.reply('❌ Không thể cấp quyền cho người dùng hoặc vai trò không hợp lệ.');
    }
}

async function listUsers(interaction) {
    const guild = interaction.guild;

    const userList = Object.entries(userRolesExpiry).map(([userId, expiry]) => {
        const member = guild.members.cache.get(userId);
        if (member) {
            const timeLeft = expiry - Date.now();
            const daysLeft = Math.floor(timeLeft / 86400000);
            const hoursLeft = Math.floor((timeLeft % 86400000) / 3600000);
            const minutesLeft = Math.floor((timeLeft % 3600000) / 60000);
            return `👤 ${member.user.tag} - Thời gian còn lại: ${daysLeft} ngày, ${hoursLeft} giờ, ${minutesLeft} phút`;
        }
        return null;
    }).filter(user => user).join('\n');

    if (userList) {
        await interaction.reply(`📜 Danh sách người dùng:\n${userList}`);
    } else {
        await interaction.reply('❌ Không có người dùng nào với quyền hạn đang hoạt động.');
    }
}

async function checkService(interaction) {
    const targetUser = interaction.options.getUser('user');
    const expiryDate = userRolesExpiry[targetUser.id];

    if (expiryDate) {
        const timeLeft = expiryDate - Date.now();
        if (timeLeft > 0) {
            const daysLeft = Math.floor(timeLeft / 86400000);
            const hoursLeft = Math.floor((timeLeft % 86400000) / 3600000);
            const minutesLeft = Math.floor((timeLeft % 3600000) / 60000);
            await interaction.reply(`⏳ ${targetUser.tag} còn lại ${daysLeft} ngày, ${hoursLeft} giờ, và ${minutesLeft} phút.`);
        } else {
            await interaction.reply(`❌ Gói dịch vụ của ${targetUser.tag} đã hết hạn.`);
        }
    } else {
        await interaction.reply(`❌ ${targetUser.tag} không có gói dịch vụ nào hoạt động.`);
    }
}

async function checkUserService(interaction) {
    const expiryDate = userRolesExpiry[interaction.user.id];

    if (expiryDate) {
        const timeLeft = expiryDate - Date.now();
        if (timeLeft > 0) {
            const daysLeft = Math.floor(timeLeft / 86400000);
            const hoursLeft = Math.floor((timeLeft % 86400000) / 3600000);
            const minutesLeft = Math.floor((timeLeft % 3600000) / 60000);
            await interaction.reply(`⏳ Bạn còn lại ${daysLeft} ngày, ${hoursLeft} giờ, và ${minutesLeft} phút.`);
        } else {
            await interaction.reply('❌ Gói dịch vụ của bạn đã hết hạn.');
        }
    } else {
        await interaction.reply('❌ Bạn không có gói dịch vụ nào hoạt động.');
    }
}

async function cancelService(interaction) {
    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'Không có lý do cụ thể.';

    const guild = interaction.guild;
    const member = await guild.members.fetch(user.id).catch(() => null);
    const role = guild.roles.cache.get(config.roles);

    if (member && role) {
        await member.roles.remove(role);
        delete userRolesExpiry[user.id]; // Xóa người dùng khỏi danh sách
        saveRolesExpiry();

        await interaction.reply(`🚫 Gói dịch vụ của ${user.tag} đã bị hủy.\n**Lý do:** ${reason}`);
    } else {
        await interaction.reply('❌ Không thể hủy dịch vụ cho người dùng này.');
    }
}

module.exports = {
    setupPremiumCommands,
    handlePremium,
    checkRoleExpiry
};