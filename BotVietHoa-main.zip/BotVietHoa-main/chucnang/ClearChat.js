const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');

function setupClearChatCommands() {
    return [
        new SlashCommandBuilder()
            .setName('clear')
            .setDescription('🧹 Xóa tin nhắn trong kênh')
            .addIntegerOption(option => 
                option.setName('amount')
                      .setDescription('🔢 Số lượng tin nhắn cần xóa (0 để xóa tất cả)')
                      .setRequired(false)
            )
    ];
}

async function handleClearChat(interaction) {
    if (interaction.commandName === 'clear') {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            await interaction.reply({ 
                embeds: [new EmbedBuilder()
                    .setColor('#FF0000')
                    .setDescription('❌ Bạn không có quyền quản lý tin nhắn.')
                    .setFooter({ text: '@Nexus Studio', iconURL: interaction.client.user.displayAvatarURL() })
                ],
                ephemeral: true
            });
            return;
        }

        const amount = interaction.options.getInteger('amount');
        const limit = amount > 100 ? 100 : amount || 100;
        const fetched = await interaction.channel.messages.fetch({ limit });
        await interaction.channel.bulkDelete(fetched, true).catch(error => console.error('Không thể xóa tin nhắn:', error));
        
        const reply = await interaction.reply({ 
            content: `🧹 Đã xóa \`${limit}\` tin nhắn.`, 
            fetchReply: true 
        });
        
        setTimeout(() => reply.delete(), 5000);
    }
}

module.exports = {
    setupClearChatCommands,
    handleClearChat
};
