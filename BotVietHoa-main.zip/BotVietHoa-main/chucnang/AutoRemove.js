const fs = require('fs');

function autoRemoveMessages(message) {
    const config = JSON.parse(fs.readFileSync('./config.json', 'utf-8'));
    if (message.channelId === config.channel && !message.author.bot) {
        message.delete().catch(console.error);
    }
}

module.exports = {
    autoRemoveMessages
};
