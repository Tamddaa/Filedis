const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

function setupStatusCommands() {
    return [
        new SlashCommandBuilder()
            .setName('uptime')
            .setDescription('⏰ Xem thời gian bot đã hoạt động'),
        new SlashCommandBuilder()
            .setName('ping')
            .setDescription('🏓 Kiểm tra độ trễ của bot')
    ];
}

async function handleStatus(interaction) {
    if (interaction.commandName === 'uptime') {
        const uptime = Date.now() - interaction.client.readyTimestamp;
        const uptimeInHours = Math.floor(uptime / (1000 * 60 * 60));
        const uptimeInMinutes = Math.floor((uptime / (1000 * 60)) % 60);
        const uptimeInSeconds = Math.floor((uptime / 1000) % 60);

        const embed = new EmbedBuilder()
            .setColor('#1E90FF')
            .setTitle('⏰ Thời gian hoạt động của Bot')
            .setDescription(`> 🕒 **Thời gian hoạt động:**\n> - ${uptimeInHours} giờ, ${uptimeInMinutes} phút, ${uptimeInSeconds} giây`)
            .setThumbnail('https://media.discordapp.net/attachments/1295370741247905895/1301908126924279808/N_logo.png?ex=67262fed&is=6724de6d&hm=a6d2a34a9e2f66f504a6e6c72a9c4b5205f6284db74fdd5410d41fc117f2c1bc&=&format=webp&quality=lossless&width=400&height=400')
            .setFooter({ text: '@Nexus Studio', iconURL: interaction.client.user.displayAvatarURL() });

        await interaction.reply({ embeds: [embed] });
    } else if (interaction.commandName === 'ping') {
        const sent = await interaction.reply({ content: 'Đang kiểm tra độ trễ...', fetchReply: true });
        const latency = sent.createdTimestamp - interaction.createdTimestamp;
        
        const embed = new EmbedBuilder()
            .setColor('#32CD32')
            .setTitle('🏓 Ping...')
            .setDescription(`> 📶 **Pong!**\n> - Độ trễ là ${latency}ms.`)
            .setThumbnail('https://media.discordapp.net/attachments/1295370741247905895/1301908126924279808/N_logo.png?ex=67262fed&is=6724de6d&hm=a6d2a34a9e2f66f504a6e6c72a9c4b5205f6284db74fdd5410d41fc117f2c1bc&=&format=webp&quality=lossless&width=400&height=400')
            .setFooter({ text: '@Nexus Studio', iconURL: interaction.client.user.displayAvatarURL() });

        await interaction.editReply({ embeds: [embed] });
    }
}

module.exports = {
    setupStatusCommands,
    handleStatus
};
