module.exports = {
  translateYaml: (outputLanguage) => `
# Prompt for Translating Minecraft Plugin Language Files to Vietnamese

I need help translating the following Minecraft plugin language file from English to Vietnamese. Please follow these specific requirements:

1. Maintain the exact YAML structure and formatting
2. Keep all keys (before the colon) unchanged
3. Only translate the values (after the colon)
4. Preserve all placeholders (text within {}, %, or $)
5. Keep all color codes (like &a, &b, &c)
6. Maintain any special characters or formatting symbols
7. Ensure translations are appropriate for the Minecraft gaming context
8. Use formal Vietnamese for commands and system messages
9. Use casual Vietnamese for in-game messages and player interactions

Example of correct translation:

Original:
```yaml
messages:
  welcome: "&aWelcome to the server, {player}!"
  inventory-full: "&cYour inventory is full!"
  level-up: "&bCongratulations! You reached level {level}"
```

Translated:
```yaml
messages:
  welcome: "&aCh?o m?ng ??n v?i m?y ch?, {player}!"
  inventory-full: "&cT?i ?? c?a b?n ?? ??y!"
  level-up: "&bCh?c m?ng! B?n ?? ??t c?p ?? {level}"
```

Translation Guidelines:
1. Game-specific terms:
   - Keep item names consistent with official Minecraft Vietnamese translations
   - Maintain standard Vietnamese gaming terminology
   - Use "b?n" for "you" in most contexts
   - Use "ng??i ch?i" for "player" when not in a placeholder

2. Message tone:
   - Error messages: Polite but direct
   - Success messages: Enthusiastic and encouraging
   - System notifications: Clear and formal
   - Tutorial messages: Friendly and helpful

3. Technical considerations:
   - Don't translate variable names in placeholders like {player}, {amount}, {level}
   - Preserve all formatting codes (&a, &b, &c, etc.)
   - Keep quotation marks when present in the original
   - Maintain any existing line breaks and indentation

Please provide your translation following this format, and I will review it for accuracy and consistency with Minecraft's Vietnamese localization.

[ YAML file for translation]
`
};
