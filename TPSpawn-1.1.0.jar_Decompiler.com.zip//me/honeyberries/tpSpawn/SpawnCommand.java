package me.honeyberries.tpSpawn;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class SpawnCommand implements CommandExecutor, TabExecutor {
   private final Plugin plugin = TPSpawn.getInstance();
   private final TPSpawnSettings settings = TPSpawnSettings.getInstance();
   private final Map<UUID, Double> cooldowns = new HashMap();

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
      if (sender instanceof Player) {
         Player player = (Player)sender;
         if (!player.hasPermission("tpspawn.command.spawn")) {
            player.sendMessage(Component.text("You don't have permission to teleport to the world spawn!", NamedTextColor.RED));
            return true;
         } else if (args.length == 1 && args[0].equalsIgnoreCase("help")) {
            this.sendHelpMessage(player);
            return true;
         } else {
            double cooldownTime = this.settings.getCooldown() * 1000.0D;
            double currentTime = (double)System.currentTimeMillis();
            UUID playerUUID = player.getUniqueId();
            if (this.cooldowns.containsKey(playerUUID) && !player.hasPermission("tpspawn.cooldown.bypass")) {
               double lastUsed = (Double)this.cooldowns.get(playerUUID);
               if (currentTime - lastUsed < cooldownTime) {
                  int timeLeft = (int)Math.ceil((cooldownTime - (currentTime - lastUsed)) / 1000.0D);
                  player.sendMessage(((TextComponent)Component.text("You must wait ", NamedTextColor.RED).append(Component.text(timeLeft, NamedTextColor.GREEN))).append(Component.text(" seconds before using this command again!", NamedTextColor.RED)));
                  return true;
               }
            }

            World world = (World)Objects.requireNonNull(Bukkit.getWorld("world"), "Overworld does not exist!");
            player.teleportAsync(world.getSpawnLocation());
            player.sendMessage(Component.text("You went to the world's spawn!", NamedTextColor.GOLD).clickEvent(ClickEvent.suggestCommand("spawn")));
            this.plugin.getLogger().info(player.getName() + " went to the world spawn!");
            if (this.settings.isTeleportSound()) {
               player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0F, 1.0F);
            }

            this.cooldowns.put(playerUUID, currentTime);
            return true;
         }
      } else {
         sender.sendMessage(Component.text("Only players can use this command! Sorry", NamedTextColor.RED));
         return true;
      }
   }

   @Nullable
   public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
      return args.length == 1 ? List.of("help") : List.of();
   }

   private void sendHelpMessage(Player player) {
      player.sendMessage(Component.text("------ Spawn Command Help ------", NamedTextColor.GREEN));
      player.sendMessage(Component.text("/spawn", NamedTextColor.AQUA).append(Component.text(" - Teleports you to the world's spawn.", NamedTextColor.GOLD)));
      player.sendMessage(Component.text("/spawn help", NamedTextColor.AQUA).append(Component.text(" - Displays this help message.", NamedTextColor.GOLD)));
      player.sendMessage(Component.text("--------------------------------", NamedTextColor.GREEN));
   }
}
