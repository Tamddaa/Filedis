package me.honeyberries.tpSpawn;

import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

public final class Scheduler {
   private static boolean isFolia;
   private static final Plugin plugin = TPSpawn.getInstance();

   public static void runTask(Runnable runnable) {
      try {
         if (isFolia) {
            Bukkit.getGlobalRegionScheduler().execute(plugin, runnable);
         } else {
            Bukkit.getScheduler().runTask(plugin, runnable);
         }
      } catch (Exception var2) {
         var2.printStackTrace();
      }

   }

   public static void runTaskAsynchronously(Runnable runnable) {
      try {
         if (isFolia) {
            Bukkit.getGlobalRegionScheduler().execute(plugin, runnable);
         } else {
            Bukkit.getScheduler().runTaskAsynchronously(plugin, runnable);
         }
      } catch (Exception var2) {
         var2.printStackTrace();
      }

   }

   public static Task runTaskLater(Runnable runnable, long delayTicks) {
      try {
         return isFolia ? new Task(Bukkit.getGlobalRegionScheduler().runDelayed(plugin, (t) -> {
            runnable.run();
         }, delayTicks)) : new Task(Bukkit.getScheduler().runTaskLater(plugin, runnable, delayTicks));
      } catch (Exception var4) {
         var4.printStackTrace();
         return null;
      }
   }

   public static Task runTaskLaterAsynchronously(Runnable runnable, long delayTicks) {
      try {
         return isFolia ? new Task(Bukkit.getGlobalRegionScheduler().runDelayed(plugin, (t) -> {
            runnable.run();
         }, delayTicks)) : new Task(Bukkit.getScheduler().runTaskLaterAsynchronously(plugin, runnable, delayTicks));
      } catch (Exception var4) {
         var4.printStackTrace();
         return null;
      }
   }

   public static Task runTaskTimer(Runnable runnable, long delayTicks, long periodTicks) {
      try {
         return isFolia ? new Task(Bukkit.getGlobalRegionScheduler().runAtFixedRate(plugin, (t) -> {
            runnable.run();
         }, delayTicks < 1L ? 1L : delayTicks, periodTicks)) : new Task(Bukkit.getScheduler().runTaskTimer(plugin, runnable, delayTicks, periodTicks));
      } catch (Exception var6) {
         var6.printStackTrace();
         return null;
      }
   }

   public static Task runTaskTimerAsynchronously(Runnable runnable, long delayTicks, long periodTicks) {
      try {
         return isFolia ? new Task(Bukkit.getGlobalRegionScheduler().runAtFixedRate(plugin, (t) -> {
            runnable.run();
         }, delayTicks < 1L ? 1L : delayTicks, periodTicks)) : new Task(Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, runnable, delayTicks, periodTicks));
      } catch (Exception var6) {
         var6.printStackTrace();
         return null;
      }
   }

   public static boolean isFolia() {
      return isFolia;
   }

   static {
      try {
         Class.forName("io.papermc.paper.threadedregions.RegionizedServer");
         isFolia = true;
      } catch (ClassNotFoundException var1) {
         isFolia = false;
      }

   }
}
