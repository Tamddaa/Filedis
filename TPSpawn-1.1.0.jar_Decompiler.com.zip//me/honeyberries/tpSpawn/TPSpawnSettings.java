package me.honeyberries.tpSpawn;

import java.io.File;
import java.io.IOException;
import org.bukkit.configuration.file.YamlConfiguration;
import org.jetbrains.annotations.NotNull;

public class TPSpawnSettings {
   private static final TPSpawnSettings INSTANCE = new TPSpawnSettings();
   private File configFile;
   private YamlConfiguration yamlConfig;
   private double cooldown;
   private boolean teleportSound;

   private TPSpawnSettings() {
   }

   public static TPSpawnSettings getInstance() {
      return INSTANCE;
   }

   public void loadConfig() {
      this.configFile = new File(TPSpawn.getInstance().getDataFolder(), "config.yml");
      if (!this.configFile.exists()) {
         TPSpawn.getInstance().saveResource("config.yml", false);
      }

      this.yamlConfig = YamlConfiguration.loadConfiguration(this.configFile);
      this.yamlConfig.options().parseComments(true);

      try {
         this.cooldown = Math.abs(this.yamlConfig.getDouble("cooldown"));
      } catch (Exception var3) {
         TPSpawn.getInstance().getLogger().warning("Failed to load cooldown time. Defaulting to 0!");
         this.cooldown = 0.0D;
      }

      try {
         this.teleportSound = this.yamlConfig.getBoolean("teleport-sound");
      } catch (Exception var2) {
         TPSpawn.getInstance().getLogger().warning("Failed to load teleport sound! Defaulting to false");
         this.teleportSound = false;
      }

      TPSpawn.getInstance().getLogger().info("Configuration successfully loaded");
      TPSpawn.getInstance().getLogger().info("Cooldown: " + this.cooldown + " seconds");
      TPSpawn.getInstance().getLogger().info("Play teleport sound: " + this.teleportSound);
   }

   public void saveConfig() {
      try {
         this.yamlConfig.save(this.configFile);
      } catch (IOException var2) {
         TPSpawn.getInstance().getLogger().warning("Failed to save configuration file.");
      }

   }

   public void set(@NotNull String path, @NotNull Object value) {
      this.yamlConfig.set(path, value);
      this.saveConfig();
   }

   public double getCooldown() {
      return this.cooldown;
   }

   public void setCooldown(double cooldown) {
      this.cooldown = cooldown;
      this.set("cooldown", cooldown);
   }

   public boolean isTeleportSound() {
      return this.teleportSound;
   }

   public void setTeleportSound(boolean teleportSound) {
      this.teleportSound = teleportSound;
      this.set("teleport-sound", teleportSound);
   }
}
