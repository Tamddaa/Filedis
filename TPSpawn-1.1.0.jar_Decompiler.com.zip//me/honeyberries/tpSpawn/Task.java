package me.honeyberries.tpSpawn;

import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import org.bukkit.scheduler.BukkitTask;

public class Task {
   private ScheduledTask foliaTask;
   private BukkitTask bukkitTask;

   public Task(ScheduledTask foliaTask) {
      this.foliaTask = foliaTask;
   }

   public Task(BukkitTask bukkitTask) {
      this.bukkitTask = bukkitTask;
   }

   public void cancel() {
      try {
         if (this.foliaTask != null) {
            this.foliaTask.cancel();
         } else if (this.bukkitTask != null) {
            this.bukkitTask.cancel();
         }
      } catch (Exception var2) {
         var2.printStackTrace();
      }

   }

   public boolean isCancelled() {
      if (this.foliaTask != null) {
         return this.foliaTask.isCancelled();
      } else {
         return this.bukkitTask != null ? this.bukkitTask.isCancelled() : true;
      }
   }
}
