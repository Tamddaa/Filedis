package me.honeyberries.tpSpawn;

import java.util.Objects;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class TPSpawn extends JavaPlugin {
   public void onEnable() {
      this.getLogger().info("TP Spawn has been enabled!");
      if (this.getServer().getPluginCommand("spawn") != null) {
         ((PluginCommand)Objects.requireNonNull(this.getServer().getPluginCommand("spawn"))).setExecutor(new SpawnCommand());
         this.getLogger().info("Successfully registered /spawn command.");
      } else {
         this.getLogger().warning("Failed to register /spawn command!");
      }

      if (this.getServer().getPluginCommand("tpspawn") != null) {
         ((PluginCommand)Objects.requireNonNull(this.getServer().getPluginCommand("tpspawn"))).setExecutor(new TPSpawnCommand());
         this.getLogger().info("Successfully registered /tpspawn command.");
      } else {
         this.getLogger().warning("Failed to register /tpspawn command!");
      }

      try {
         TPSpawnSettings.getInstance().loadConfig();
         this.getLogger().info("Configuration successfully loaded!");
      } catch (Exception var2) {
         this.getLogger().warning("Failed to load the configuration file!");
         var2.printStackTrace();
      }

   }

   public void onDisable() {
      this.getLogger().info("TP Spawn has been disabled!");
   }

   public static TPSpawn getInstance() {
      return (TPSpawn)getPlugin(TPSpawn.class);
   }
}
