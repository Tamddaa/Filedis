package me.honeyberries.tpSpawn;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class TPSpawnCommand implements CommandExecutor, TabExecutor {
   private final Plugin plugin = TPSpawn.getInstance();
   private final TPSpawnSettings settings = TPSpawnSettings.getInstance();

   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
      if (!sender.hasPermission("tpspawn.command.edit")) {
         sender.sendMessage(Component.text("Sorry, you don't have the permissions to run this command!", NamedTextColor.RED));
         return true;
      } else {
         String var5;
         byte var6;
         if (args.length == 1) {
            var5 = args[0].toLowerCase();
            var6 = -1;
            switch(var5.hashCode()) {
            case -934641255:
               if (var5.equals("reload")) {
                  var6 = 1;
               }
               break;
            case -546109589:
               if (var5.equals("cooldown")) {
                  var6 = 2;
               }
               break;
            case 3198785:
               if (var5.equals("help")) {
                  var6 = 0;
               }
               break;
            case 109627663:
               if (var5.equals("sound")) {
                  var6 = 3;
               }
            }

            switch(var6) {
            case 0:
               this.sendHelpMessage(sender);
               break;
            case 1:
               this.settings.loadConfig();
               sender.sendMessage(Component.text("Configuration successfully reloaded!", NamedTextColor.AQUA));
               break;
            case 2:
               double cooldown = this.settings.getCooldown();
               sender.sendMessage(Component.text("Cooldown time is set to ", NamedTextColor.GOLD).append(Component.text(cooldown + " seconds!", NamedTextColor.AQUA)));
               break;
            case 3:
               boolean playSound = this.settings.isTeleportSound();
               sender.sendMessage(Component.text("Teleport sound is currently set to ", NamedTextColor.GOLD).append(Component.text(String.valueOf(playSound), NamedTextColor.AQUA)));
               break;
            default:
               this.sendHelpMessage(sender);
            }

            return true;
         } else if (args.length == 2) {
            var5 = args[0].toLowerCase();
            var6 = -1;
            switch(var5.hashCode()) {
            case -546109589:
               if (var5.equals("cooldown")) {
                  var6 = 0;
               }
               break;
            case 109627663:
               if (var5.equals("sound")) {
                  var6 = 1;
               }
            }

            switch(var6) {
            case 0:
               this.setCooldown(sender, args[1]);
               break;
            case 1:
               this.setSound(sender, args[1]);
               break;
            default:
               this.sendHelpMessage(sender);
            }

            return true;
         } else {
            this.sendHelpMessage(sender);
            return true;
         }
      }
   }

   private void sendHelpMessage(CommandSender sender) {
      sender.sendMessage(Component.text("------ TPSpawn Command Help ------", NamedTextColor.GREEN));
      sender.sendMessage(Component.text("/tpspawn reload", NamedTextColor.AQUA).append(Component.text(" - Reloads the plugin configuration.", NamedTextColor.GOLD)));
      sender.sendMessage(Component.text("/tpspawn cooldown", NamedTextColor.AQUA).append(Component.text(" - Displays the current cooldown time.", NamedTextColor.GOLD)));
      sender.sendMessage(Component.text("/tpspawn cooldown <value>", NamedTextColor.AQUA).append(Component.text(" - Sets a new cooldown time (in seconds).", NamedTextColor.GOLD)));
      sender.sendMessage(Component.text("/tpspawn sound", NamedTextColor.AQUA).append(Component.text(" - Shows if teleport sound is enabled.", NamedTextColor.GOLD)));
      sender.sendMessage(Component.text("/tpspawn sound <true/false>", NamedTextColor.AQUA).append(Component.text(" - Enables or disables teleport sound.", NamedTextColor.GOLD)));
      sender.sendMessage(Component.text("/tpspawn help", NamedTextColor.AQUA).append(Component.text(" - Displays this help message.", NamedTextColor.GOLD)));
      sender.sendMessage(Component.text("----------------------------------", NamedTextColor.GREEN));
   }

   private void setCooldown(CommandSender sender, String cooldownStr) {
      try {
         double cooldown = Double.parseDouble(cooldownStr);
         if (cooldown < 0.0D) {
            sender.sendMessage(Component.text("Cooldown must be non-negative", NamedTextColor.RED));
            return;
         }

         this.settings.setCooldown(cooldown);
         this.plugin.getLogger().info("Cooldown: " + cooldown);
         sender.sendMessage(Component.text("Cooldown is now set to ", NamedTextColor.GOLD).append(Component.text(cooldown + " seconds!", NamedTextColor.AQUA)));
      } catch (NumberFormatException var5) {
         sender.sendMessage(Component.text("Invalid number for cooldown.", NamedTextColor.RED));
      }

   }

   private void setSound(CommandSender sender, String soundStr) {
      boolean playSound = Boolean.parseBoolean(soundStr);
      this.settings.setTeleportSound(playSound);
      this.plugin.getLogger().info("Teleport sound is set to " + playSound);
      sender.sendMessage(Component.text("Teleport sound is now set to ", NamedTextColor.GOLD).append(Component.text(String.valueOf(playSound), NamedTextColor.AQUA)));
   }

   @Nullable
   public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
      if (args.length == 1) {
         return (List)Stream.of("reload", "cooldown", "sound", "help").filter((option) -> {
            return option.startsWith(args[0].toLowerCase());
         }).collect(Collectors.toList());
      } else {
         return args.length == 2 && "sound".equalsIgnoreCase(args[0]) ? (List)Stream.of("true", "false").filter((option) -> {
            return option.startsWith(args[1].toLowerCase());
         }).collect(Collectors.toList()) : List.of();
      }
   }
}
