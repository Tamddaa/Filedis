/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import com.donutsmp.teams.G.A.A.A;
import com.donutsmp.teams.G.A.G;
import com.donutsmp.teams.G.A.P;
import com.donutsmp.teams.G.A.U;
import com.donutsmp.teams.G.A.X;
import java.util.Map;
import java.util.Set;

public final class S
extends P {
    private final A<String, P> A = new A(false);

    public S _() {
        S s = new S();
        for (Map.Entry<String, P> entry : this.A.entrySet()) {
            s.A(entry.getKey(), entry.getValue().N());
        }
        return s;
    }

    public void A(String string, P p) {
        this.A.put(string, p == null ? U.B : p);
    }

    public P C(String string) {
        return this.A.remove(string);
    }

    public void A(String string, String string2) {
        this.A(string, string2 == null ? U.B : new G(string2));
    }

    public void A(String string, Number number) {
        this.A(string, number == null ? U.B : new G(number));
    }

    public void A(String string, Boolean bl) {
        this.A(string, bl == null ? U.B : new G(bl));
    }

    public void A(String string, Character c) {
        this.A(string, c == null ? U.B : new G(c));
    }

    public Set<Map.Entry<String, P>> Z() {
        return this.A.entrySet();
    }

    public Set<String> W() {
        return this.A.keySet();
    }

    public int Y() {
        return this.A.size();
    }

    public boolean X() {
        return this.A.size() == 0;
    }

    public boolean E(String string) {
        return this.A.containsKey(string);
    }

    public P B(String string) {
        return this.A.get(string);
    }

    public G A(String string) {
        return (G)this.A.get(string);
    }

    public X F(String string) {
        return (X)this.A.get(string);
    }

    public S D(String string) {
        return (S)this.A.get(string);
    }

    public Map<String, P> V() {
        return this.A;
    }

    public boolean equals(Object object) {
        return object == this || object instanceof S && ((S)object).A.equals(this.A);
    }

    public int hashCode() {
        return this.A.hashCode();
    }
}

