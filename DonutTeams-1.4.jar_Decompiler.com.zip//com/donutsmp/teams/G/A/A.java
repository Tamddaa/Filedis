/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import com.donutsmp.teams.G.A.T;

public final class A
extends T {
    private static final long B = 1L;

    public A(String string) {
        super(string);
    }

    public A(String string, Throwable throwable) {
        super(string, throwable);
    }

    public A(Throwable throwable) {
        super(throwable);
    }
}

