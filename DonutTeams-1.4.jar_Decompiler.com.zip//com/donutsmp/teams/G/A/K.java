/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import com.donutsmp.teams.G.A.P;
import com.donutsmp.teams.G.A.T;
import java.lang.reflect.Type;

public interface K {
    public <T> T A(P var1, Type var2) throws T;
}

