/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import com.donutsmp.teams.G.A.G;
import com.donutsmp.teams.G.A.P;
import com.donutsmp.teams.G.A.U;

public enum Z {
    A{

        @Override
        public P A(Long l) {
            if (l == null) {
                return U.B;
            }
            return new G(l);
        }
    }
    ,
    B{

        @Override
        public P A(Long l) {
            if (l == null) {
                return U.B;
            }
            return new G(l.toString());
        }
    };


    public abstract P A(Long var1);
}

