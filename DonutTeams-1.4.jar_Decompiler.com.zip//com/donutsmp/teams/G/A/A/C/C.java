/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A.C;

import com.donutsmp.teams.G.A.A;
import com.donutsmp.teams.G.A.B;
import com.donutsmp.teams.G.A.E;
import com.donutsmp.teams.G.A.M;
import com.donutsmp.teams.G.A.Q;
import com.donutsmp.teams.G.A.V;
import java.io.IOException;

public final class C
extends V<Number> {
    private static final B K = C.A(M.B);
    private final E J;

    private C(E e) {
        this.J = e;
    }

    private static B A(E e) {
        C c = new C(e);
        return new B(){

            @Override
            public <T> V<T> A(Q q, com.donutsmp.teams.G.A.B.A<T> a) {
                return a.C() == Number.class ? C.this : null;
            }
        };
    }

    public static B B(E e) {
        if (e == M.B) {
            return K;
        }
        return C.A(e);
    }

    public Number G(com.donutsmp.teams.G.A.D.E e) throws IOException {
        com.donutsmp.teams.G.A.D.A a = e.G();
        switch (a) {
            case E: {
                e.S();
                return null;
            }
            case B: 
            case G: {
                return this.J.A(e);
            }
        }
        throw new A("Expecting number, got: " + (Object)((Object)a) + "; at path " + e.J());
    }

    @Override
    public void A(com.donutsmp.teams.G.A.D.C c, Number number) throws IOException {
        c.A(number);
    }
}

