/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A;

import com.donutsmp.teams.G.A.A.E;
import com.donutsmp.teams.G.A.W;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Method;
import java.util.List;

public class M {
    private M() {
    }

    public static boolean A(Class<?> clazz) {
        return M.B(clazz.getName());
    }

    private static boolean B(String string) {
        return string.startsWith("java.") || string.startsWith("javax.");
    }

    public static boolean B(Class<?> clazz) {
        return M.A(clazz.getName());
    }

    private static boolean A(String string) {
        return string.startsWith("android.") || string.startsWith("androidx.") || M.B(string);
    }

    public static boolean C(Class<?> clazz) {
        String string = clazz.getName();
        return M.A(string) || string.startsWith("kotlin.") || string.startsWith("kotlinx.") || string.startsWith("scala.");
    }

    public static W._A A(List<W> list, Class<?> clazz) {
        for (W w : list) {
            W._A _A2 = w.A(clazz);
            if (_A2 == W._A.E) continue;
            return _A2;
        }
        return W._A.C;
    }

    public static boolean A(AccessibleObject accessibleObject, Object object) {
        return _A.A.A(accessibleObject, object);
    }

    private static abstract class _A {
        public static final _A A;

        private _A() {
        }

        public abstract boolean A(AccessibleObject var1, Object var2);

        static {
            _A _A2 = null;
            if (E.B()) {
                try {
                    final Method method = AccessibleObject.class.getDeclaredMethod("canAccess", Object.class);
                    _A2 = new _A(){

                        @Override
                        public boolean A(AccessibleObject accessibleObject, Object object) {
                            try {
                                return (Boolean)method.invoke(accessibleObject, object);
                            } catch (Exception exception) {
                                throw new RuntimeException("Failed invoking canAccess", exception);
                            }
                        }
                    };
                } catch (NoSuchMethodException noSuchMethodException) {
                    // empty catch block
                }
            }
            if (_A2 == null) {
                _A2 = new _A(){

                    @Override
                    public boolean A(AccessibleObject accessibleObject, Object object) {
                        return true;
                    }
                };
            }
            A = _A2;
        }
    }
}

