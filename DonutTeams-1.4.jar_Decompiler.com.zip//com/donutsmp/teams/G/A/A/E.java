/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A;

public final class E {
    private static final int A = E.A();

    private static int A() {
        String string = System.getProperty("java.version");
        return E.C(string);
    }

    static int C(String string) {
        int n = E.B(string);
        if (n == -1) {
            n = E.A(string);
        }
        if (n == -1) {
            return 6;
        }
        return n;
    }

    private static int B(String string) {
        try {
            String[] stringArray = string.split("[._]");
            int n = Integer.parseInt(stringArray[0]);
            if (n == 1 && stringArray.length > 1) {
                return Integer.parseInt(stringArray[1]);
            }
            return n;
        } catch (NumberFormatException numberFormatException) {
            return -1;
        }
    }

    private static int A(String string) {
        try {
            char c;
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 0; i < string.length() && Character.isDigit(c = string.charAt(i)); ++i) {
                stringBuilder.append(c);
            }
            return Integer.parseInt(stringBuilder.toString());
        } catch (NumberFormatException numberFormatException) {
            return -1;
        }
    }

    public static int C() {
        return A;
    }

    public static boolean B() {
        return A >= 9;
    }

    private E() {
    }
}

