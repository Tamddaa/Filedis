/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A;

import java.io.IOException;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.Comparator;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Set;

public final class A<K, V>
extends AbstractMap<K, V>
implements Serializable {
    private static final Comparator<Comparable> C = new Comparator<Comparable>(){

        public int A(Comparable comparable, Comparable comparable2) {
            return comparable.compareTo(comparable2);
        }
    };
    private final Comparator<? super K> B;
    private final boolean D;
    _B<K, V> I;
    int J = 0;
    int G = 0;
    final _B<K, V> F;
    private _C H;
    private _A E;

    public A() {
        this(C, true);
    }

    public A(boolean bl) {
        this(C, bl);
    }

    public A(Comparator<? super K> comparator, boolean bl) {
        this.B = comparator != null ? comparator : C;
        this.D = bl;
        this.F = new _B(bl);
    }

    @Override
    public int size() {
        return this.J;
    }

    @Override
    public V get(Object object) {
        _B<K, V> _B2 = this.B(object);
        return _B2 != null ? (V)_B2.E : null;
    }

    @Override
    public boolean containsKey(Object object) {
        return this.B(object) != null;
    }

    @Override
    public V put(K k, V v) {
        if (k == null) {
            throw new NullPointerException("key == null");
        }
        if (v == null && !this.D) {
            throw new NullPointerException("value == null");
        }
        _B<K, V> _B2 = this.A(k, true);
        Object v2 = _B2.E;
        _B2.E = v;
        return v2;
    }

    @Override
    public void clear() {
        this.I = null;
        this.J = 0;
        ++this.G;
        _B<K, V> _B2 = this.F;
        _B2.C = _B2;
        _B2.D = _B2.C;
    }

    @Override
    public V remove(Object object) {
        _B<K, V> _B2 = this.A(object);
        return _B2 != null ? (V)_B2.E : null;
    }

    _B<K, V> A(K k, boolean bl) {
        _B<K, V> _B2;
        Object object;
        Comparator<K> comparator = this.B;
        _B<K, V> _B3 = this.I;
        int n = 0;
        if (_B3 != null) {
            object = comparator == C ? (Comparable)k : null;
            while (true) {
                int n2 = n = object != null ? object.compareTo(_B3.H) : comparator.compare(k, _B3.H);
                if (n == 0) {
                    return _B3;
                }
                _B _B4 = _B2 = n < 0 ? _B3.A : _B3.G;
                if (_B2 == null) break;
                _B3 = _B2;
            }
        }
        if (!bl) {
            return null;
        }
        object = this.F;
        if (_B3 == null) {
            if (comparator == C && !(k instanceof Comparable)) {
                throw new ClassCastException(k.getClass().getName() + " is not Comparable");
            }
            _B2 = new _B<K, V>(this.D, _B3, k, object, ((_B)object).C);
            this.I = _B2;
        } else {
            _B2 = new _B<K, V>(this.D, _B3, k, object, ((_B)object).C);
            if (n < 0) {
                _B3.A = _B2;
            } else {
                _B3.G = _B2;
            }
            this.A(_B3, true);
        }
        ++this.J;
        ++this.G;
        return _B2;
    }

    _B<K, V> B(Object object) {
        try {
            return object != null ? this.A(object, false) : null;
        } catch (ClassCastException classCastException) {
            return null;
        }
    }

    _B<K, V> A(Map.Entry<?, ?> entry) {
        _B<K, V> _B2 = this.B(entry.getKey());
        boolean bl = _B2 != null && this.A(_B2.E, entry.getValue());
        return bl ? _B2 : null;
    }

    private boolean A(Object object, Object object2) {
        return Objects.equals(object, object2);
    }

    void B(_B<K, V> _B2, boolean bl) {
        if (bl) {
            _B2.C.D = _B2.D;
            _B2.D.C = _B2.C;
        }
        _B _B3 = _B2.A;
        _B _B4 = _B2.G;
        _B _B5 = _B2.F;
        if (_B3 != null && _B4 != null) {
            _B _B6 = _B3.I > _B4.I ? _B3.A() : _B4.B();
            this.B(_B6, false);
            int n = 0;
            _B3 = _B2.A;
            if (_B3 != null) {
                n = _B3.I;
                _B6.A = _B3;
                _B3.F = _B6;
                _B2.A = null;
            }
            int n2 = 0;
            _B4 = _B2.G;
            if (_B4 != null) {
                n2 = _B4.I;
                _B6.G = _B4;
                _B4.F = _B6;
                _B2.G = null;
            }
            _B6.I = Math.max(n, n2) + 1;
            this.A(_B2, _B6);
            return;
        }
        if (_B3 != null) {
            this.A(_B2, _B3);
            _B2.A = null;
        } else if (_B4 != null) {
            this.A(_B2, _B4);
            _B2.G = null;
        } else {
            this.A(_B2, null);
        }
        this.A(_B5, false);
        --this.J;
        ++this.G;
    }

    _B<K, V> A(Object object) {
        _B<K, V> _B2 = this.B(object);
        if (_B2 != null) {
            this.B(_B2, true);
        }
        return _B2;
    }

    private void A(_B<K, V> _B2, _B<K, V> _B3) {
        _B _B4 = _B2.F;
        _B2.F = null;
        if (_B3 != null) {
            _B3.F = _B4;
        }
        if (_B4 != null) {
            if (_B4.A == _B2) {
                _B4.A = _B3;
            } else {
                assert (_B4.G == _B2);
                _B4.G = _B3;
            }
        } else {
            this.I = _B3;
        }
    }

    private void A(_B<K, V> _B2, boolean bl) {
        _B<K, V> _B3 = _B2;
        while (_B3 != null) {
            int n;
            _B _B4;
            int n2;
            int n3;
            _B _B5;
            _B _B6;
            int n4;
            _B _B7 = _B3.A;
            int n5 = _B7 != null ? _B7.I : 0;
            int n6 = n5 - (n4 = (_B6 = _B3.G) != null ? _B6.I : 0);
            if (n6 == -2) {
                _B5 = _B6.A;
                n3 = _B5 != null ? _B5.I : 0;
                n = n3 - (n2 = (_B4 = _B6.G) != null ? _B4.I : 0);
                if (n == -1 || n == 0 && !bl) {
                    this.A(_B3);
                } else {
                    assert (n == 1);
                    this.B(_B6);
                    this.A(_B3);
                }
                if (bl) {
                    break;
                }
            } else if (n6 == 2) {
                _B5 = _B7.A;
                n3 = _B5 != null ? _B5.I : 0;
                n = n3 - (n2 = (_B4 = _B7.G) != null ? _B4.I : 0);
                if (n == 1 || n == 0 && !bl) {
                    this.B(_B3);
                } else {
                    assert (n == -1);
                    this.A(_B7);
                    this.B(_B3);
                }
                if (bl) {
                    break;
                }
            } else if (n6 == 0) {
                _B3.I = n5 + 1;
                if (bl) {
                    break;
                }
            } else {
                assert (n6 == -1 || n6 == 1);
                _B3.I = Math.max(n5, n4) + 1;
                if (!bl) break;
            }
            _B3 = _B3.F;
        }
    }

    private void A(_B<K, V> _B2) {
        _B _B3 = _B2.A;
        _B _B4 = _B2.G;
        _B _B5 = _B4.A;
        _B _B6 = _B4.G;
        _B2.G = _B5;
        if (_B5 != null) {
            _B5.F = _B2;
        }
        this.A(_B2, _B4);
        _B4.A = _B2;
        _B2.F = _B4;
        _B2.I = Math.max(_B3 != null ? _B3.I : 0, _B5 != null ? _B5.I : 0) + 1;
        _B4.I = Math.max(_B2.I, _B6 != null ? _B6.I : 0) + 1;
    }

    private void B(_B<K, V> _B2) {
        _B _B3 = _B2.A;
        _B _B4 = _B2.G;
        _B _B5 = _B3.A;
        _B _B6 = _B3.G;
        _B2.A = _B6;
        if (_B6 != null) {
            _B6.F = _B2;
        }
        this.A(_B2, _B3);
        _B3.G = _B2;
        _B2.F = _B3;
        _B2.I = Math.max(_B4 != null ? _B4.I : 0, _B6 != null ? _B6.I : 0) + 1;
        _B3.I = Math.max(_B2.I, _B5 != null ? _B5.I : 0) + 1;
    }

    @Override
    public Set<Map.Entry<K, V>> entrySet() {
        _C _C2 = this.H;
        return _C2 != null ? _C2 : (this.H = new _C());
    }

    @Override
    public Set<K> keySet() {
        _A _A2 = this.E;
        return _A2 != null ? _A2 : (this.E = new _A());
    }

    private Object A() throws ObjectStreamException {
        return new LinkedHashMap(this);
    }

    private void A(ObjectInputStream objectInputStream) throws IOException {
        throw new InvalidObjectException("Deserialization is unsupported");
    }

    final class _A
    extends AbstractSet<K> {
        _A() {
        }

        @Override
        public int size() {
            return A.this.J;
        }

        @Override
        public Iterator<K> iterator() {
            return new _D<K>(){

                @Override
                public K next() {
                    return this.A().H;
                }
            };
        }

        @Override
        public boolean contains(Object object) {
            return A.this.containsKey(object);
        }

        @Override
        public boolean remove(Object object) {
            return A.this.A(object) != null;
        }

        @Override
        public void clear() {
            A.this.clear();
        }
    }

    class _C
    extends AbstractSet<Map.Entry<K, V>> {
        _C() {
        }

        @Override
        public int size() {
            return A.this.J;
        }

        @Override
        public Iterator<Map.Entry<K, V>> iterator() {
            return new _D<Map.Entry<K, V>>(){

                public Map.Entry<K, V> B() {
                    return this.A();
                }
            };
        }

        @Override
        public boolean contains(Object object) {
            return object instanceof Map.Entry && A.this.A((Map.Entry)object) != null;
        }

        @Override
        public boolean remove(Object object) {
            if (!(object instanceof Map.Entry)) {
                return false;
            }
            _B _B2 = A.this.A((Map.Entry)object);
            if (_B2 == null) {
                return false;
            }
            A.this.B(_B2, true);
            return true;
        }

        @Override
        public void clear() {
            A.this.clear();
        }
    }

    private abstract class _D<T>
    implements Iterator<T> {
        _B<K, V> B;
        _B<K, V> D;
        int C;

        _D() {
            this.B = A.this.F.D;
            this.D = null;
            this.C = A.this.G;
        }

        @Override
        public final boolean hasNext() {
            return this.B != A.this.F;
        }

        final _B<K, V> A() {
            _B _B2 = this.B;
            if (_B2 == A.this.F) {
                throw new NoSuchElementException();
            }
            if (A.this.G != this.C) {
                throw new ConcurrentModificationException();
            }
            this.B = _B2.D;
            this.D = _B2;
            return this.D;
        }

        @Override
        public final void remove() {
            if (this.D == null) {
                throw new IllegalStateException();
            }
            A.this.B(this.D, true);
            this.D = null;
            this.C = A.this.G;
        }
    }

    static final class _B<K, V>
    implements Map.Entry<K, V> {
        _B<K, V> F;
        _B<K, V> A;
        _B<K, V> G;
        _B<K, V> D;
        _B<K, V> C;
        final K H;
        final boolean B;
        V E;
        int I;

        _B(boolean bl) {
            this.H = null;
            this.B = bl;
            this.D = this.C = this;
        }

        _B(boolean bl, _B<K, V> _B2, K k, _B<K, V> _B3, _B<K, V> _B4) {
            this.F = _B2;
            this.H = k;
            this.B = bl;
            this.I = 1;
            this.D = _B3;
            this.C = _B4;
            _B4.D = this;
            _B3.C = this;
        }

        @Override
        public K getKey() {
            return this.H;
        }

        @Override
        public V getValue() {
            return this.E;
        }

        @Override
        public V setValue(V v) {
            if (v == null && !this.B) {
                throw new NullPointerException("value == null");
            }
            V v2 = this.E;
            this.E = v;
            return v2;
        }

        @Override
        public boolean equals(Object object) {
            if (object instanceof Map.Entry) {
                Map.Entry entry = (Map.Entry)object;
                return (this.H == null ? entry.getKey() == null : this.H.equals(entry.getKey())) && (this.E == null ? entry.getValue() == null : this.E.equals(entry.getValue()));
            }
            return false;
        }

        @Override
        public int hashCode() {
            return (this.H == null ? 0 : this.H.hashCode()) ^ (this.E == null ? 0 : this.E.hashCode());
        }

        public String toString() {
            return this.H + "=" + this.E;
        }

        public _B<K, V> B() {
            _B<K, V> _B2 = this;
            _B<K, V> _B3 = _B2.A;
            while (_B3 != null) {
                _B2 = _B3;
                _B3 = _B2.A;
            }
            return _B2;
        }

        public _B<K, V> A() {
            _B<K, V> _B2 = this;
            _B<K, V> _B3 = _B2.G;
            while (_B3 != null) {
                _B2 = _B3;
                _B3 = _B2.G;
            }
            return _B2;
        }
    }
}

