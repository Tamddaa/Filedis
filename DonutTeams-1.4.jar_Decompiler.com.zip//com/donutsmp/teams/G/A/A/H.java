/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A;

import com.donutsmp.teams.G.A.A.G;
import java.io.ObjectInputStream;
import java.io.ObjectStreamClass;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public abstract class H {
    public static final H A = H.A();

    public abstract <T> T C(Class<T> var1) throws Exception;

    private static void B(Class<?> clazz) {
        String string = G.A(clazz);
        if (string != null) {
            throw new AssertionError((Object)("UnsafeAllocator is used for non-instantiable type: " + string));
        }
    }

    private static H A() {
        try {
            Class<?> clazz = Class.forName("sun.misc.Unsafe");
            Field field = clazz.getDeclaredField("theUnsafe");
            field.setAccessible(true);
            final Object object = field.get(null);
            final Method method = clazz.getMethod("allocateInstance", Class.class);
            return new H(){

                @Override
                public <T> T C(Class<T> clazz) throws Exception {
                    H.B(clazz);
                    return (T)method.invoke(object, clazz);
                }
            };
        } catch (Exception exception) {
            try {
                Method method = ObjectStreamClass.class.getDeclaredMethod("getConstructorId", Class.class);
                method.setAccessible(true);
                final int n = (Integer)method.invoke(null, Object.class);
                final Method method2 = ObjectStreamClass.class.getDeclaredMethod("newInstance", Class.class, Integer.TYPE);
                method2.setAccessible(true);
                return new H(){

                    @Override
                    public <T> T C(Class<T> clazz) throws Exception {
                        H.B(clazz);
                        return (T)method2.invoke(null, clazz, n);
                    }
                };
            } catch (Exception exception2) {
                try {
                    final Method method = ObjectInputStream.class.getDeclaredMethod("newInstance", Class.class, Class.class);
                    method.setAccessible(true);
                    return new H(){

                        @Override
                        public <T> T C(Class<T> clazz) throws Exception {
                            H.B(clazz);
                            return (T)method.invoke(null, clazz, Object.class);
                        }
                    };
                } catch (Exception exception3) {
                    return new H(){

                        @Override
                        public <T> T C(Class<T> clazz) {
                            throw new UnsupportedOperationException("Cannot allocate " + clazz + ". Usage of JDK sun.misc.Unsafe is enabled, but it could not be used. Make sure your runtime is configured correctly.");
                        }
                    };
                }
            }
        }
    }
}

