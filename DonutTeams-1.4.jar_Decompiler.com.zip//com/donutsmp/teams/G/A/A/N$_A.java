/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A;

public final class N$_A {
    private N$_A() {
        throw new UnsupportedOperationException();
    }

    @Deprecated
    public static <T> T A(T t) {
        if (t == null) {
            throw new NullPointerException();
        }
        return t;
    }

    public static void A(boolean bl) {
        if (!bl) {
            throw new IllegalArgumentException();
        }
    }
}

