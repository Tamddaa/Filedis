/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A.C;

import com.donutsmp.teams.G.A.A.B;
import com.donutsmp.teams.G.A.A.C.L;
import com.donutsmp.teams.G.A.A.E;
import com.donutsmp.teams.G.A.D.C;
import com.donutsmp.teams.G.A.V;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public final class A<T extends Date>
extends V<T> {
    private static final String G = "DefaultDateTypeAdapter";
    private final _A<T> E;
    private final List<DateFormat> F = new ArrayList<DateFormat>();

    private A(_A<T> _A2, String string) {
        this.E = Objects.requireNonNull(_A2);
        this.F.add(new SimpleDateFormat(string, Locale.US));
        if (!Locale.getDefault().equals(Locale.US)) {
            this.F.add(new SimpleDateFormat(string));
        }
    }

    private A(_A<T> _A2, int n) {
        this.E = Objects.requireNonNull(_A2);
        this.F.add(DateFormat.getDateInstance(n, Locale.US));
        if (!Locale.getDefault().equals(Locale.US)) {
            this.F.add(DateFormat.getDateInstance(n));
        }
        if (com.donutsmp.teams.G.A.A.E.B()) {
            this.F.add(B.D(n));
        }
    }

    private A(_A<T> _A2, int n, int n2) {
        this.E = Objects.requireNonNull(_A2);
        this.F.add(DateFormat.getDateTimeInstance(n, n2, Locale.US));
        if (!Locale.getDefault().equals(Locale.US)) {
            this.F.add(DateFormat.getDateTimeInstance(n, n2));
        }
        if (com.donutsmp.teams.G.A.A.E.B()) {
            this.F.add(B.A(n, n2));
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void A(C c, Date date) throws IOException {
        String string;
        if (date == null) {
            c.C();
            return;
        }
        DateFormat dateFormat = this.F.get(0);
        List<DateFormat> list = this.F;
        synchronized (list) {
            string = dateFormat.format(date);
        }
        c.E(string);
    }

    public T D(com.donutsmp.teams.G.A.D.E e) throws IOException {
        if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
            e.S();
            return null;
        }
        Date date = this.E(e);
        return this.E.A(date);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private Date E(com.donutsmp.teams.G.A.D.E e) throws IOException {
        String string = e.Y();
        List<DateFormat> list = this.F;
        synchronized (list) {
            for (DateFormat dateFormat : this.F) {
                try {
                    return dateFormat.parse(string);
                } catch (ParseException parseException) {
                }
            }
        }
        try {
            return com.donutsmp.teams.G.A.A.C.A.A.A(string, new ParsePosition(0));
        } catch (ParseException parseException) {
            throw new com.donutsmp.teams.G.A.A("Failed parsing '" + string + "' as Date; at path " + e.Q(), parseException);
        }
    }

    public String toString() {
        DateFormat dateFormat = this.F.get(0);
        if (dateFormat instanceof SimpleDateFormat) {
            return "DefaultDateTypeAdapter(" + ((SimpleDateFormat)dateFormat).toPattern() + ')';
        }
        return "DefaultDateTypeAdapter(" + dateFormat.getClass().getSimpleName() + ')';
    }

    public static abstract class _A<T extends Date> {
        public static final _A<Date> B = new _A<Date>(Date.class){

            @Override
            protected Date A(Date date) {
                return date;
            }
        };
        private final Class<T> A;

        protected _A(Class<T> clazz) {
            this.A = clazz;
        }

        protected abstract T A(Date var1);

        private com.donutsmp.teams.G.A.B A(A<T> a) {
            return L.B(this.A, a);
        }

        public final com.donutsmp.teams.G.A.B A(String string) {
            return this.A(new A(this, string));
        }

        public final com.donutsmp.teams.G.A.B A(int n) {
            return this.A(new A(this, n));
        }

        public final com.donutsmp.teams.G.A.B A(int n, int n2) {
            return this.A(new A(this, n, n2));
        }

        public final com.donutsmp.teams.G.A.B A() {
            return this.A(new A(this, 2, 2));
        }
    }
}

