/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A.B;

import com.donutsmp.teams.G.A.A.B.A;
import com.donutsmp.teams.G.A.A.B.D;
import com.donutsmp.teams.G.A.A.C.A;
import com.donutsmp.teams.G.A.B;
import java.sql.Timestamp;
import java.util.Date;

public final class C {
    public static final boolean E;
    public static final A._A<? extends Date> F;
    public static final A._A<? extends Date> B;
    public static final B D;
    public static final B C;
    public static final B A;

    private C() {
    }

    static {
        boolean bl;
        try {
            Class.forName("java.sql.Date");
            bl = true;
        } catch (ClassNotFoundException classNotFoundException) {
            bl = false;
        }
        E = bl;
        if (E) {
            F = new A._A<java.sql.Date>(java.sql.Date.class){

                protected java.sql.Date B(Date date) {
                    return new java.sql.Date(date.getTime());
                }
            };
            B = new A._A<Timestamp>(Timestamp.class){

                protected Timestamp C(Date date) {
                    return new Timestamp(date.getTime());
                }
            };
            D = com.donutsmp.teams.G.A.A.B.D.D;
            C = com.donutsmp.teams.G.A.A.B.A.\u00c4;
            A = com.donutsmp.teams.G.A.A.B.B.A;
        } else {
            F = null;
            B = null;
            D = null;
            C = null;
            A = null;
        }
    }
}

