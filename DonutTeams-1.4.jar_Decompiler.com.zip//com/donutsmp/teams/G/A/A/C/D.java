/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A.C;

import com.donutsmp.teams.G.A.A.C.E;
import com.donutsmp.teams.G.A.A.C.I;
import com.donutsmp.teams.G.A.B.A;
import com.donutsmp.teams.G.A.D.C;
import com.donutsmp.teams.G.A.D.E;
import com.donutsmp.teams.G.A.Q;
import com.donutsmp.teams.G.A.V;
import java.io.IOException;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;

final class D<T>
extends V<T> {
    private final Q L;
    private final V<T> N;
    private final Type M;

    D(Q q, V<T> v, Type type) {
        this.L = q;
        this.N = v;
        this.M = type;
    }

    @Override
    public T A(E e) throws IOException {
        return this.N.A(e);
    }

    @Override
    public void A(C c, T t) throws IOException {
        V<Object> v = this.N;
        Type type = D.A(this.M, t);
        if (type != this.M) {
            V<?> v2 = this.L.A(A.C(type));
            v = !(v2 instanceof E._D) ? v2 : (!D.A(this.N) ? this.N : v2);
        }
        v.A(c, t);
    }

    private static boolean A(V<?> v) {
        V v2;
        while (v instanceof I && (v2 = ((I)v).E()) != v) {
            v = v2;
        }
        return v instanceof E._D;
    }

    private static Type A(Type clazz, Object object) {
        if (object != null && (clazz instanceof Class || clazz instanceof TypeVariable)) {
            clazz = object.getClass();
        }
        return clazz;
    }
}

