/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A.B;

import com.donutsmp.teams.G.A.A;
import com.donutsmp.teams.G.A.B;
import com.donutsmp.teams.G.A.D.C;
import com.donutsmp.teams.G.A.D.E;
import com.donutsmp.teams.G.A.Q;
import com.donutsmp.teams.G.A.V;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

final class D
extends V<java.sql.Date> {
    static final B D = new B(){

        @Override
        public <T> V<T> A(Q q, com.donutsmp.teams.G.A.B.A<T> a) {
            return a.C() == java.sql.Date.class ? new D() : null;
        }
    };
    private final DateFormat C = new SimpleDateFormat("MMM d, yyyy");

    private D() {
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public java.sql.Date C(E e) throws IOException {
        if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
            e.S();
            return null;
        }
        String string = e.Y();
        try {
            Date date;
            D d = this;
            synchronized (d) {
                date = this.C.parse(string);
            }
            return new java.sql.Date(date.getTime());
        } catch (ParseException parseException) {
            throw new A("Failed parsing '" + string + "' as SQL Date; at path " + e.Q(), parseException);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void A(C c, java.sql.Date date) throws IOException {
        String string;
        if (date == null) {
            c.C();
            return;
        }
        D d = this;
        synchronized (d) {
            string = this.C.format(date);
        }
        c.E(string);
    }
}

