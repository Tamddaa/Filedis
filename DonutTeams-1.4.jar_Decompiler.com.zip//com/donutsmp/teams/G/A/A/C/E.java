/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A.C;

import com.donutsmp.teams.G.A.A;
import com.donutsmp.teams.G.A.A.C.D;
import com.donutsmp.teams.G.A.A.G;
import com.donutsmp.teams.G.A.A.K;
import com.donutsmp.teams.G.A.A.L;
import com.donutsmp.teams.G.A.A.M;
import com.donutsmp.teams.G.A.A.N$_B;
import com.donutsmp.teams.G.A.A.O;
import com.donutsmp.teams.G.A.B;
import com.donutsmp.teams.G.A.D.C;
import com.donutsmp.teams.G.A.F;
import com.donutsmp.teams.G.A.Q;
import com.donutsmp.teams.G.A.R;
import com.donutsmp.teams.G.A.T;
import com.donutsmp.teams.G.A.V;
import com.donutsmp.teams.G.A.W;
import java.io.IOException;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class E
implements B {
    private final G E;
    private final F G;
    private final K C;
    private final com.donutsmp.teams.G.A.A.C.M D;
    private final List<W> F;

    public E(G g, F f, K k, com.donutsmp.teams.G.A.A.C.M m, List<W> list) {
        this.E = g;
        this.G = f;
        this.C = k;
        this.D = m;
        this.F = list;
    }

    private boolean A(Field field, boolean bl) {
        return !this.C.B(field.getType(), bl) && !this.C.B(field, bl);
    }

    private List<String> A(Field field) {
        com.donutsmp.teams.G.A.C.D d = field.getAnnotation(com.donutsmp.teams.G.A.C.D.class);
        if (d == null) {
            String string = this.G.A(field);
            return Collections.singletonList(string);
        }
        String string = d.A();
        String[] stringArray = d.B();
        if (stringArray.length == 0) {
            return Collections.singletonList(string);
        }
        ArrayList<String> arrayList = new ArrayList<String>(stringArray.length + 1);
        arrayList.add(string);
        Collections.addAll(arrayList, stringArray);
        return arrayList;
    }

    @Override
    public <T> V<T> A(Q q, com.donutsmp.teams.G.A.B.A<T> a) {
        boolean bl;
        Class<T> clazz = a.C();
        if (!Object.class.isAssignableFrom(clazz)) {
            return null;
        }
        W._A _A2 = M.A(this.F, clazz);
        if (_A2 == W._A.D) {
            throw new R("ReflectionAccessFilter does not permit using reflection for " + clazz + ". Register a TypeAdapter for this type or adjust the access filter.");
        }
        boolean bl2 = bl = _A2 == W._A.A;
        if (com.donutsmp.teams.G.A.A.A.A.B(clazz)) {
            _A<T> _A3 = new _A<T>(clazz, this.A(q, a, clazz, bl, true), bl);
            return _A3;
        }
        O<T> o = this.E.A(a);
        return new _B<T>(o, this.A(q, a, clazz, bl, false));
    }

    private static <M extends AccessibleObject> void A(Object object, M m) {
        if (!M.A(m, Modifier.isStatic(((Member)((Object)m)).getModifiers()) ? null : object)) {
            String string = com.donutsmp.teams.G.A.A.A.A.A(m, true);
            throw new R(string + " is not accessible and ReflectionAccessFilter does not permit making it accessible. Register a TypeAdapter for the declaring type, adjust the access filter or increase the visibility of the element and its declaring type.");
        }
    }

    private _C A(final Q q, Field field, final Method method, String string, final com.donutsmp.teams.G.A.B.A<?> a, boolean bl, boolean bl2, final boolean bl3) {
        boolean bl4;
        final boolean bl5 = L.A(a.C());
        int n = field.getModifiers();
        final boolean bl6 = Modifier.isStatic(n) && Modifier.isFinal(n);
        com.donutsmp.teams.G.A.C.A a2 = field.getAnnotation(com.donutsmp.teams.G.A.C.A.class);
        V<?> v = null;
        if (a2 != null) {
            v = this.D.A(this.E, q, a, a2);
        }
        boolean bl7 = bl4 = v != null;
        if (v == null) {
            v = q.A(a);
        }
        final V<?> v2 = v;
        return new _C(string, field, bl, bl2){

            @Override
            void A(C c, Object object) throws IOException, IllegalAccessException {
                Object object2;
                if (!this.B) {
                    return;
                }
                if (bl3) {
                    if (method == null) {
                        com.donutsmp.teams.G.A.A.C.E.A(object, this.C);
                    } else {
                        com.donutsmp.teams.G.A.A.C.E.A(object, method);
                    }
                }
                if (method != null) {
                    try {
                        object2 = method.invoke(object, new Object[0]);
                    } catch (InvocationTargetException invocationTargetException) {
                        String string = com.donutsmp.teams.G.A.A.A.A.A((AccessibleObject)method, false);
                        throw new R("Accessor " + string + " threw exception", invocationTargetException.getCause());
                    }
                } else {
                    object2 = this.C.get(object);
                }
                if (object2 == object) {
                    return;
                }
                c.B(this.A);
                V v = bl4 ? v2 : new D(q, v2, a.A());
                v.A(c, object2);
            }

            @Override
            void A(com.donutsmp.teams.G.A.D.E e, int n, Object[] objectArray) throws IOException, T {
                Object t = v2.A(e);
                if (t == null && bl5) {
                    throw new T("null is not allowed as value for record component '" + this.E + "' of primitive type; at path " + e.J());
                }
                objectArray[n] = t;
            }

            @Override
            void A(com.donutsmp.teams.G.A.D.E e, Object object) throws IOException, IllegalAccessException {
                Object t = v2.A(e);
                if (t != null || !bl5) {
                    if (bl3) {
                        com.donutsmp.teams.G.A.A.C.E.A(object, this.C);
                    } else if (bl6) {
                        String string = com.donutsmp.teams.G.A.A.A.A.A((AccessibleObject)this.C, false);
                        throw new R("Cannot set value of 'static final' " + string);
                    }
                    this.C.set(object, t);
                }
            }
        };
    }

    private Map<String, _C> A(Q q, com.donutsmp.teams.G.A.B.A<?> a, Class<?> clazz, boolean bl, boolean bl2) {
        LinkedHashMap<String, _C> linkedHashMap = new LinkedHashMap<String, _C>();
        if (clazz.isInterface()) {
            return linkedHashMap;
        }
        Class<?> clazz2 = clazz;
        while (clazz != Object.class) {
            Field[] fieldArray = clazz.getDeclaredFields();
            if (clazz != clazz2 && fieldArray.length > 0) {
                W._A _A2 = M.A(this.F, clazz);
                if (_A2 == W._A.D) {
                    throw new R("ReflectionAccessFilter does not permit using reflection for " + clazz + " (supertype of " + clazz2 + "). Register a TypeAdapter for this type or adjust the access filter.");
                }
                bl = _A2 == W._A.A;
            }
            for (Field field : fieldArray) {
                Object object;
                boolean bl3 = this.A(field, true);
                boolean bl4 = this.A(field, false);
                if (!bl3 && !bl4) continue;
                Method method = null;
                if (bl2) {
                    if (Modifier.isStatic(field.getModifiers())) {
                        bl4 = false;
                    } else {
                        method = com.donutsmp.teams.G.A.A.A.A.A(clazz, field);
                        if (!bl) {
                            com.donutsmp.teams.G.A.A.A.A.A(method);
                        }
                        if (method.getAnnotation(com.donutsmp.teams.G.A.C.D.class) != null && field.getAnnotation(com.donutsmp.teams.G.A.C.D.class) == null) {
                            object = com.donutsmp.teams.G.A.A.A.A.A((AccessibleObject)method, false);
                            throw new R("@SerializedName on " + (String)object + " is not supported");
                        }
                    }
                }
                if (!bl && method == null) {
                    com.donutsmp.teams.G.A.A.A.A.A((AccessibleObject)field);
                }
                object = N$_B.A(a.A(), clazz, field.getGenericType());
                List<String> list = this.A(field);
                _C _C2 = null;
                int n = list.size();
                for (int i = 0; i < n; ++i) {
                    String string = list.get(i);
                    if (i != 0) {
                        bl3 = false;
                    }
                    _C _C3 = this.A(q, field, method, string, com.donutsmp.teams.G.A.B.A.C((Type)object), bl3, bl4, bl);
                    _C _C4 = linkedHashMap.put(string, _C3);
                    if (_C2 != null) continue;
                    _C2 = _C4;
                }
                if (_C2 == null) continue;
                throw new IllegalArgumentException("Class " + clazz2.getName() + " declares multiple JSON fields named '" + _C2.A + "'; conflict is caused by fields " + com.donutsmp.teams.G.A.A.A.A.A(_C2.C) + " and " + com.donutsmp.teams.G.A.A.A.A.A(field));
            }
            a = com.donutsmp.teams.G.A.B.A.C(N$_B.A(a.A(), clazz, clazz.getGenericSuperclass()));
            clazz = a.C();
        }
        return linkedHashMap;
    }

    private static final class _A<T>
    extends _D<T, Object[]> {
        static final Map<Class<?>, Object> P = _A.D();
        private final Constructor<T> Q;
        private final Object[] S;
        private final Map<String, Integer> R = new HashMap<String, Integer>();

        _A(Class<T> clazz, Map<String, _C> map, boolean bl) {
            super(map);
            this.Q = com.donutsmp.teams.G.A.A.A.A.C(clazz);
            if (bl) {
                com.donutsmp.teams.G.A.A.C.E.A(null, this.Q);
            } else {
                com.donutsmp.teams.G.A.A.A.A.A(this.Q);
            }
            String[] stringArray = com.donutsmp.teams.G.A.A.A.A.A(clazz);
            for (int i = 0; i < stringArray.length; ++i) {
                this.R.put(stringArray[i], i);
            }
            Class<?>[] classArray = this.Q.getParameterTypes();
            this.S = new Object[classArray.length];
            for (int i = 0; i < classArray.length; ++i) {
                this.S[i] = P.get(classArray[i]);
            }
        }

        private static Map<Class<?>, Object> D() {
            HashMap hashMap = new HashMap();
            hashMap.put(Byte.TYPE, (byte)0);
            hashMap.put(Short.TYPE, (short)0);
            hashMap.put(Integer.TYPE, 0);
            hashMap.put(Long.TYPE, 0L);
            hashMap.put(Float.TYPE, Float.valueOf(0.0f));
            hashMap.put(Double.TYPE, 0.0);
            hashMap.put(Character.TYPE, Character.valueOf('\u0000'));
            hashMap.put(Boolean.TYPE, false);
            return hashMap;
        }

        Object[] C() {
            return (Object[])this.S.clone();
        }

        @Override
        void A(Object[] objectArray, com.donutsmp.teams.G.A.D.E e, _C _C2) throws IOException {
            Integer n = this.R.get(_C2.E);
            if (n == null) {
                throw new IllegalStateException("Could not find the index in the constructor '" + com.donutsmp.teams.G.A.A.A.A.B(this.Q) + "' for field with name '" + _C2.E + "', unable to determine which argument in the constructor the field corresponds to. This is unexpected behavior, as we expect the RecordComponents to have the same names as the fields in the Java class, and that the order of the RecordComponents is the same as the order of the canonical constructor parameters.");
            }
            _C2.A(e, n, objectArray);
        }

        T A(Object[] objectArray) {
            try {
                return this.Q.newInstance(objectArray);
            } catch (IllegalAccessException illegalAccessException) {
                throw com.donutsmp.teams.G.A.A.A.A.A(illegalAccessException);
            } catch (IllegalArgumentException | InstantiationException exception) {
                throw new RuntimeException("Failed to invoke constructor '" + com.donutsmp.teams.G.A.A.A.A.B(this.Q) + "' with args " + Arrays.toString(objectArray), exception);
            } catch (InvocationTargetException invocationTargetException) {
                throw new RuntimeException("Failed to invoke constructor '" + com.donutsmp.teams.G.A.A.A.A.B(this.Q) + "' with args " + Arrays.toString(objectArray), invocationTargetException.getCause());
            }
        }
    }

    private static final class _B<T>
    extends _D<T, T> {
        private final O<T> T;

        _B(O<T> o, Map<String, _C> map) {
            super(map);
            this.T = o;
        }

        @Override
        T B() {
            return this.T.A();
        }

        @Override
        void A(T t, com.donutsmp.teams.G.A.D.E e, _C _C2) throws IllegalAccessException, IOException {
            _C2.A(e, t);
        }

        @Override
        T C(T t) {
            return t;
        }
    }

    public static abstract class _D<T, A>
    extends V<T> {
        final Map<String, _C> O;

        _D(Map<String, _C> map) {
            this.O = map;
        }

        @Override
        public void A(C c, T t) throws IOException {
            if (t == null) {
                c.C();
                return;
            }
            c.F();
            try {
                for (_C _C2 : this.O.values()) {
                    _C2.A(c, t);
                }
            } catch (IllegalAccessException illegalAccessException) {
                throw com.donutsmp.teams.G.A.A.A.A.A(illegalAccessException);
            }
            c.B();
        }

        @Override
        public T A(com.donutsmp.teams.G.A.D.E e) throws IOException {
            if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            A a = this.B();
            try {
                e.V();
                while (e.A()) {
                    String string = e.I();
                    _C _C2 = this.O.get(string);
                    if (_C2 == null || !_C2.D) {
                        e.N();
                        continue;
                    }
                    this.A(a, e, _C2);
                }
            } catch (IllegalStateException illegalStateException) {
                throw new A(illegalStateException);
            } catch (IllegalAccessException illegalAccessException) {
                throw com.donutsmp.teams.G.A.A.A.A.A(illegalAccessException);
            }
            e.O();
            return this.C(a);
        }

        abstract A B();

        abstract void A(A var1, com.donutsmp.teams.G.A.D.E var2, _C var3) throws IllegalAccessException, IOException;

        abstract T C(A var1);
    }

    static abstract class _C {
        final String A;
        final Field C;
        final String E;
        final boolean B;
        final boolean D;

        protected _C(String string, Field field, boolean bl, boolean bl2) {
            this.A = string;
            this.C = field;
            this.E = field.getName();
            this.B = bl;
            this.D = bl2;
        }

        abstract void A(C var1, Object var2) throws IOException, IllegalAccessException;

        abstract void A(com.donutsmp.teams.G.A.D.E var1, int var2, Object[] var3) throws IOException, T;

        abstract void A(com.donutsmp.teams.G.A.D.E var1, Object var2) throws IOException, IllegalAccessException;
    }
}

