/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A.C;

import com.donutsmp.teams.G.A.A.C.H;
import com.donutsmp.teams.G.A.A.G;
import com.donutsmp.teams.G.A.B;
import com.donutsmp.teams.G.A.C.A;
import com.donutsmp.teams.G.A.L;
import com.donutsmp.teams.G.A.N;
import com.donutsmp.teams.G.A.Q;
import com.donutsmp.teams.G.A.V;

public final class M
implements B {
    private final G Y;

    public M(G g) {
        this.Y = g;
    }

    @Override
    public <T> V<T> A(Q q, com.donutsmp.teams.G.A.B.A<T> a) {
        Class<T> clazz = a.C();
        A a2 = clazz.getAnnotation(A.class);
        if (a2 == null) {
            return null;
        }
        return this.A(this.Y, q, a, a2);
    }

    V<?> A(G g, Q q, com.donutsmp.teams.G.A.B.A<?> a, A a2) {
        V<?> v;
        Object obj = g.A(com.donutsmp.teams.G.A.B.A.A(a2.A())).A();
        boolean bl = a2.B();
        if (obj instanceof V) {
            v = (V<?>)obj;
        } else if (obj instanceof B) {
            v = ((B)obj).A(q, a);
        } else if (obj instanceof L || obj instanceof N) {
            L l = obj instanceof L ? (L)obj : null;
            N n = obj instanceof N ? (N)obj : null;
            H h = new H(l, n, q, a, null, bl);
            v = h;
            bl = false;
        } else {
            throw new IllegalArgumentException("Invalid attempt to bind an instance of " + obj.getClass().getName() + " as a @JsonAdapter for " + a.toString() + ". @JsonAdapter value must be a TypeAdapter, TypeAdapterFactory, JsonSerializer or JsonDeserializer.");
        }
        if (v != null && bl) {
            v = v.A();
        }
        return v;
    }
}

