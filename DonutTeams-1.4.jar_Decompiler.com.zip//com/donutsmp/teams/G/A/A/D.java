/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Objects;
import java.util.RandomAccess;

public class D<E>
extends AbstractList<E>
implements RandomAccess {
    private final ArrayList<E> A;

    public D(ArrayList<E> arrayList) {
        this.A = Objects.requireNonNull(arrayList);
    }

    @Override
    public E get(int n) {
        return this.A.get(n);
    }

    @Override
    public int size() {
        return this.A.size();
    }

    private E A(E e) {
        if (e == null) {
            throw new NullPointerException("Element must be non-null");
        }
        return e;
    }

    @Override
    public E set(int n, E e) {
        return this.A.set(n, this.A(e));
    }

    @Override
    public void add(int n, E e) {
        this.A.add(n, this.A(e));
    }

    @Override
    public E remove(int n) {
        return this.A.remove(n);
    }

    @Override
    public void clear() {
        this.A.clear();
    }

    @Override
    public boolean remove(Object object) {
        return this.A.remove(object);
    }

    @Override
    public boolean removeAll(Collection<?> collection) {
        return this.A.removeAll(collection);
    }

    @Override
    public boolean retainAll(Collection<?> collection) {
        return this.A.retainAll(collection);
    }

    @Override
    public boolean contains(Object object) {
        return this.A.contains(object);
    }

    @Override
    public int indexOf(Object object) {
        return this.A.indexOf(object);
    }

    @Override
    public int lastIndexOf(Object object) {
        return this.A.lastIndexOf(object);
    }

    @Override
    public Object[] toArray() {
        return this.A.toArray();
    }

    @Override
    public <T> T[] toArray(T[] TArray) {
        return this.A.toArray(TArray);
    }

    @Override
    public boolean equals(Object object) {
        return this.A.equals(object);
    }

    @Override
    public int hashCode() {
        return this.A.hashCode();
    }
}

