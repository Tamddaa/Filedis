/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A.C;

import com.donutsmp.teams.G.A.A.B;
import com.donutsmp.teams.G.A.A.C.A.A;
import com.donutsmp.teams.G.A.A.E;
import com.donutsmp.teams.G.A.D.C;
import com.donutsmp.teams.G.A.Q;
import com.donutsmp.teams.G.A.V;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class F
extends V<Date> {
    public static final com.donutsmp.teams.G.A.B V = new com.donutsmp.teams.G.A.B(){

        @Override
        public <T> V<T> A(Q q, com.donutsmp.teams.G.A.B.A<T> a) {
            return a.C() == Date.class ? new F() : null;
        }
    };
    private final List<DateFormat> U = new ArrayList<DateFormat>();

    public F() {
        this.U.add(DateFormat.getDateTimeInstance(2, 2, Locale.US));
        if (!Locale.getDefault().equals(Locale.US)) {
            this.U.add(DateFormat.getDateTimeInstance(2, 2));
        }
        if (E.B()) {
            this.U.add(B.A(2, 2));
        }
    }

    public Date H(com.donutsmp.teams.G.A.D.E e) throws IOException {
        if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
            e.S();
            return null;
        }
        return this.I(e);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private Date I(com.donutsmp.teams.G.A.D.E e) throws IOException {
        String string = e.Y();
        List<DateFormat> list = this.U;
        synchronized (list) {
            for (DateFormat dateFormat : this.U) {
                try {
                    return dateFormat.parse(string);
                } catch (ParseException parseException) {
                }
            }
        }
        try {
            return A.A(string, new ParsePosition(0));
        } catch (ParseException parseException) {
            throw new com.donutsmp.teams.G.A.A("Failed parsing '" + string + "' as Date; at path " + e.Q(), parseException);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void B(C c, Date date) throws IOException {
        String string;
        if (date == null) {
            c.C();
            return;
        }
        DateFormat dateFormat = this.U.get(0);
        List<DateFormat> list = this.U;
        synchronized (list) {
            string = dateFormat.format(date);
        }
        c.E(string);
    }
}

