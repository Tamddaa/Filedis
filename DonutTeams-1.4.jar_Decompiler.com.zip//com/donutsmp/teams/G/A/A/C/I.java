/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A.C;

import com.donutsmp.teams.G.A.V;

public abstract class I<T>
extends V<T> {
    public abstract V<T> E();
}

