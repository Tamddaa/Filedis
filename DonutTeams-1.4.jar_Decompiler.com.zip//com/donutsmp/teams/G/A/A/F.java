/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A;

import com.donutsmp.teams.G.A.D.E;
import java.io.IOException;

public abstract class F {
    public static F A;

    public abstract void A(E var1) throws IOException;
}

