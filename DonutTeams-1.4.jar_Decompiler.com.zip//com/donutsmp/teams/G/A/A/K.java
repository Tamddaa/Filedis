/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A;

import com.donutsmp.teams.G.A.B;
import com.donutsmp.teams.G.A.B.A;
import com.donutsmp.teams.G.A.C.C;
import com.donutsmp.teams.G.A.C.E;
import com.donutsmp.teams.G.A.H;
import com.donutsmp.teams.G.A.I;
import com.donutsmp.teams.G.A.Q;
import com.donutsmp.teams.G.A.V;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public final class K
implements B,
Cloneable {
    private static final double e = -1.0;
    public static final K c = new K();
    private double d = -1.0;
    private int f = 136;
    private boolean i = true;
    private boolean b;
    private List<I> h = Collections.emptyList();
    private List<I> g = Collections.emptyList();

    protected K B() {
        try {
            return (K)super.clone();
        } catch (CloneNotSupportedException cloneNotSupportedException) {
            throw new AssertionError((Object)cloneNotSupportedException);
        }
    }

    public K A(double d) {
        K k = this.B();
        k.d = d;
        return k;
    }

    public K A(int ... nArray) {
        K k = this.B();
        k.f = 0;
        for (int n : nArray) {
            k.f |= n;
        }
        return k;
    }

    public K C() {
        K k = this.B();
        k.i = false;
        return k;
    }

    public K A() {
        K k = this.B();
        k.b = true;
        return k;
    }

    public K A(I i, boolean bl, boolean bl2) {
        K k = this.B();
        if (bl) {
            k.h = new ArrayList<I>(this.h);
            k.h.add(i);
        }
        if (bl2) {
            k.g = new ArrayList<I>(this.g);
            k.g.add(i);
        }
        return k;
    }

    @Override
    public <T> V<T> A(final Q q, final A<T> a) {
        boolean bl;
        Class<T> clazz = a.C();
        boolean bl2 = this.A(clazz);
        final boolean bl3 = bl2 || this.A(clazz, true);
        boolean bl4 = bl = bl2 || this.A(clazz, false);
        if (!bl3 && !bl) {
            return null;
        }
        return new V<T>(){
            private V<T> \u00aa;

            @Override
            public T A(com.donutsmp.teams.G.A.D.E e) throws IOException {
                if (bl) {
                    e.N();
                    return null;
                }
                return this.H().A(e);
            }

            @Override
            public void A(com.donutsmp.teams.G.A.D.C c, T t) throws IOException {
                if (bl3) {
                    c.C();
                    return;
                }
                this.H().A(c, t);
            }

            private V<T> H() {
                V v = this.\u00aa;
                return v != null ? v : (this.\u00aa = q.A(K.this, a));
            }
        };
    }

    public boolean B(Field field, boolean bl) {
        Object object;
        if ((this.f & field.getModifiers()) != 0) {
            return true;
        }
        if (this.d != -1.0 && !this.A(field.getAnnotation(com.donutsmp.teams.G.A.C.B.class), field.getAnnotation(C.class))) {
            return true;
        }
        if (field.isSynthetic()) {
            return true;
        }
        if (this.b && ((object = field.getAnnotation(E.class)) == null || (bl ? !object.A() : !object.B()))) {
            return true;
        }
        if (!this.i && this.C(field.getType())) {
            return true;
        }
        if (this.D(field.getType())) {
            return true;
        }
        Object object2 = object = bl ? this.h : this.g;
        if (!object.isEmpty()) {
            H h = new H(field);
            Iterator iterator = object.iterator();
            while (iterator.hasNext()) {
                I i = (I)iterator.next();
                if (!i.A(h)) continue;
                return true;
            }
        }
        return false;
    }

    private boolean A(Class<?> clazz) {
        if (this.d != -1.0 && !this.A(clazz.getAnnotation(com.donutsmp.teams.G.A.C.B.class), clazz.getAnnotation(C.class))) {
            return true;
        }
        if (!this.i && this.C(clazz)) {
            return true;
        }
        return this.D(clazz);
    }

    public boolean B(Class<?> clazz, boolean bl) {
        return this.A(clazz) || this.A(clazz, bl);
    }

    private boolean A(Class<?> clazz, boolean bl) {
        List<I> list = bl ? this.h : this.g;
        for (I i : list) {
            if (!i.A(clazz)) continue;
            return true;
        }
        return false;
    }

    private boolean D(Class<?> clazz) {
        return !Enum.class.isAssignableFrom(clazz) && !this.B(clazz) && (clazz.isAnonymousClass() || clazz.isLocalClass());
    }

    private boolean C(Class<?> clazz) {
        return clazz.isMemberClass() && !this.B(clazz);
    }

    private boolean B(Class<?> clazz) {
        return (clazz.getModifiers() & 8) != 0;
    }

    private boolean A(com.donutsmp.teams.G.A.C.B b, C c) {
        return this.A(b) && this.A(c);
    }

    private boolean A(com.donutsmp.teams.G.A.C.B b) {
        if (b != null) {
            double d = b.A();
            return this.d >= d;
        }
        return true;
    }

    private boolean A(C c) {
        if (c != null) {
            double d = c.A();
            return this.d < d;
        }
        return true;
    }
}

