/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A.C;

import com.donutsmp.teams.G.A.A.C.I;
import com.donutsmp.teams.G.A.A.N$_A;
import com.donutsmp.teams.G.A.B;
import com.donutsmp.teams.G.A.B.A;
import com.donutsmp.teams.G.A.D.C;
import com.donutsmp.teams.G.A.D.E;
import com.donutsmp.teams.G.A.K;
import com.donutsmp.teams.G.A.L;
import com.donutsmp.teams.G.A.N;
import com.donutsmp.teams.G.A.O;
import com.donutsmp.teams.G.A.P;
import com.donutsmp.teams.G.A.Q;
import com.donutsmp.teams.G.A.T;
import com.donutsmp.teams.G.A.V;
import java.io.IOException;
import java.lang.reflect.Type;

public final class H<T>
extends I<T> {
    private final L<T> b;
    private final N<T> c;
    final Q X;
    private final A<T> _;
    private final B Z;
    private final _A Y = new _A();
    private final boolean W;
    private volatile V<T> a;

    public H(L<T> l, N<T> n, Q q, A<T> a, B b, boolean bl) {
        this.b = l;
        this.c = n;
        this.X = q;
        this._ = a;
        this.Z = b;
        this.W = bl;
    }

    public H(L<T> l, N<T> n, Q q, A<T> a, B b) {
        this(l, n, q, a, b, true);
    }

    @Override
    public T A(E e) throws IOException {
        if (this.c == null) {
            return this.F().A(e);
        }
        P p = com.donutsmp.teams.G.A.A.I.A(e);
        if (this.W && p.L()) {
            return null;
        }
        return this.c.A(p, this._.A(), this.Y);
    }

    @Override
    public void A(C c, T t) throws IOException {
        if (this.b == null) {
            this.F().A(c, t);
            return;
        }
        if (this.W && t == null) {
            c.C();
            return;
        }
        P p = this.b.A(t, this._.A(), this.Y);
        com.donutsmp.teams.G.A.A.I.A(p, c);
    }

    private V<T> F() {
        V<T> v = this.a;
        return v != null ? v : (this.a = this.X.A(this.Z, this._));
    }

    @Override
    public V<T> E() {
        return this.b != null ? this : this.F();
    }

    public static B B(A<?> a, Object object) {
        return new _B(object, a, false, null);
    }

    public static B A(A<?> a, Object object) {
        boolean bl = a.A() == a.C();
        return new _B(object, a, bl, null);
    }

    public static B A(Class<?> clazz, Object object) {
        return new _B(object, null, false, clazz);
    }

    private final class _A
    implements O,
    K {
        private _A() {
        }

        @Override
        public P A(Object object) {
            return H.this.X.A(object);
        }

        @Override
        public P A(Object object, Type type) {
            return H.this.X.B(object, type);
        }

        public <R> R A(P p, Type type) throws T {
            return (R)H.this.X.A(p, type);
        }
    }

    private static final class _B
    implements B {
        private final A<?> H;
        private final boolean L;
        private final Class<?> I;
        private final L<?> J;
        private final N<?> K;

        _B(Object object, A<?> a, boolean bl, Class<?> clazz) {
            this.J = object instanceof L ? (L)object : null;
            this.K = object instanceof N ? (N)object : null;
            N$_A.A(this.J != null || this.K != null);
            this.H = a;
            this.L = bl;
            this.I = clazz;
        }

        @Override
        public <T> V<T> A(Q q, A<T> a) {
            boolean bl = this.H != null ? this.H.equals(a) || this.L && this.H.A() == a.C() : this.I.isAssignableFrom(a.C());
            return bl ? new H(this.J, this.K, q, a, this) : null;
        }
    }
}

