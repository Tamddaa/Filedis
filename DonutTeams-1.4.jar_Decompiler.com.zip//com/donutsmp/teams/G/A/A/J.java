/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A;

import java.io.IOException;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.ObjectStreamException;
import java.math.BigDecimal;

public final class J
extends Number {
    private final String A;

    public J(String string) {
        this.A = string;
    }

    @Override
    public int intValue() {
        try {
            return Integer.parseInt(this.A);
        } catch (NumberFormatException numberFormatException) {
            try {
                return (int)Long.parseLong(this.A);
            } catch (NumberFormatException numberFormatException2) {
                return new BigDecimal(this.A).intValue();
            }
        }
    }

    @Override
    public long longValue() {
        try {
            return Long.parseLong(this.A);
        } catch (NumberFormatException numberFormatException) {
            return new BigDecimal(this.A).longValue();
        }
    }

    @Override
    public float floatValue() {
        return Float.parseFloat(this.A);
    }

    @Override
    public double doubleValue() {
        return Double.parseDouble(this.A);
    }

    public String toString() {
        return this.A;
    }

    private Object A() throws ObjectStreamException {
        return new BigDecimal(this.A);
    }

    private void A(ObjectInputStream objectInputStream) throws IOException {
        throw new InvalidObjectException("Deserialization is unsupported");
    }

    public int hashCode() {
        return this.A.hashCode();
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object instanceof J) {
            J j = (J)object;
            return this.A == j.A || this.A.equals(j.A);
        }
        return false;
    }
}

