/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A;

public final class C {
    public static final String A = "2.10.1";

    private C() {
    }
}

