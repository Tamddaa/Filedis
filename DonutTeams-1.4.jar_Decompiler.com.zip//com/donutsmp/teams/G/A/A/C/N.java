/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A.C;

import com.donutsmp.teams.G.A.A;
import com.donutsmp.teams.G.A.A.C.D;
import com.donutsmp.teams.G.A.A.C.L;
import com.donutsmp.teams.G.A.A.F;
import com.donutsmp.teams.G.A.A.I;
import com.donutsmp.teams.G.A.A.N$_B;
import com.donutsmp.teams.G.A.A.O;
import com.donutsmp.teams.G.A.B;
import com.donutsmp.teams.G.A.D.C;
import com.donutsmp.teams.G.A.D.E;
import com.donutsmp.teams.G.A.G;
import com.donutsmp.teams.G.A.P;
import com.donutsmp.teams.G.A.Q;
import com.donutsmp.teams.G.A.V;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Map;

public final class N
implements B {
    private final com.donutsmp.teams.G.A.A.G _;
    final boolean Z;

    public N(com.donutsmp.teams.G.A.A.G g, boolean bl) {
        this._ = g;
        this.Z = bl;
    }

    @Override
    public <T> V<T> A(Q q, com.donutsmp.teams.G.A.B.A<T> a) {
        Type type = a.A();
        Class<T> clazz = a.C();
        if (!Map.class.isAssignableFrom(clazz)) {
            return null;
        }
        Type[] typeArray = N$_B.A(type, clazz);
        V<?> v = this.A(q, typeArray[0]);
        V<?> v2 = q.A(com.donutsmp.teams.G.A.B.A.C(typeArray[1]));
        O<T> o = this._.A(a);
        _A _A2 = new _A(q, typeArray[0], v, typeArray[1], v2, o);
        return _A2;
    }

    private V<?> A(Q q, Type type) {
        return type == Boolean.TYPE || type == Boolean.class ? L.E : q.A(com.donutsmp.teams.G.A.B.A.C(type));
    }

    private final class _A<K, V>
    extends V<Map<K, V>> {
        private final V<K> u;
        private final V<V> t;
        private final O<? extends Map<K, V>> v;

        public _A(Q q, Type type, V<K> v, Type type2, V<V> v2, O<? extends Map<K, V>> o) {
            this.u = new D<K>(q, v, type);
            this.t = new D<V>(q, v2, type2);
            this.v = o;
        }

        public Map<K, V> l(E e) throws IOException {
            com.donutsmp.teams.G.A.D.A a = e.G();
            if (a == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            Map<K, V> map = this.v.A();
            if (a == com.donutsmp.teams.G.A.D.A.F) {
                e.H();
                while (e.A()) {
                    e.H();
                    K k = this.u.A(e);
                    V v = this.t.A(e);
                    V v2 = map.put(k, v);
                    if (v2 != null) {
                        throw new A("duplicate key: " + k);
                    }
                    e._();
                }
                e._();
            } else {
                e.V();
                while (e.A()) {
                    V v;
                    F.A.A(e);
                    K k = this.u.A(e);
                    V v3 = map.put(k, v = this.t.A(e));
                    if (v3 == null) continue;
                    throw new A("duplicate key: " + k);
                }
                e.O();
            }
            return map;
        }

        @Override
        public void A(C c, Map<K, V> map) throws IOException {
            P p;
            if (map == null) {
                c.C();
                return;
            }
            if (!N.this.Z) {
                c.F();
                for (Map.Entry<K, V> entry : map.entrySet()) {
                    c.B(String.valueOf(entry.getKey()));
                    this.t.A(c, entry.getValue());
                }
                c.B();
                return;
            }
            boolean bl = false;
            ArrayList<P> arrayList = new ArrayList<P>(map.size());
            ArrayList<V> arrayList2 = new ArrayList<V>(map.size());
            for (Map.Entry<K, V> entry : map.entrySet()) {
                p = this.u.A(entry.getKey());
                arrayList.add(p);
                arrayList2.add(entry.getValue());
                bl |= p.J() || p.K();
            }
            if (bl) {
                c.D();
                int n = arrayList.size();
                for (int i = 0; i < n; ++i) {
                    c.D();
                    I.A((P)arrayList.get(i), c);
                    this.t.A(c, arrayList2.get(i));
                    c.H();
                }
                c.H();
            } else {
                c.F();
                int n = arrayList.size();
                for (int i = 0; i < n; ++i) {
                    p = (P)arrayList.get(i);
                    c.B(this.B(p));
                    this.t.A(c, arrayList2.get(i));
                }
                c.B();
            }
        }

        @Override
        private String B(P p) {
            if (p.C()) {
                G g = p.E();
                if (g.i()) {
                    return String.valueOf(g.D());
                }
                if (g.g()) {
                    return Boolean.toString(g.S());
                }
                if (g.h()) {
                    return g.M();
                }
                throw new AssertionError();
            }
            if (p.L()) {
                return "null";
            }
            throw new AssertionError();
        }
    }
}

