/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A.B;

import com.donutsmp.teams.G.A.B;
import com.donutsmp.teams.G.A.D.C;
import com.donutsmp.teams.G.A.D.E;
import com.donutsmp.teams.G.A.Q;
import com.donutsmp.teams.G.A.V;
import java.io.IOException;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

final class A
extends V<Time> {
    static final B \u00c4 = new B(){

        @Override
        public <T> V<T> A(Q q, com.donutsmp.teams.G.A.B.A<T> a) {
            return a.C() == Time.class ? new A() : null;
        }
    };
    private final DateFormat \u00c3 = new SimpleDateFormat("hh:mm:ss a");

    private A() {
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public Time r(E e) throws IOException {
        if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
            e.S();
            return null;
        }
        String string = e.Y();
        try {
            A a = this;
            synchronized (a) {
                Date date = this.\u00c3.parse(string);
                return new Time(date.getTime());
            }
        } catch (ParseException parseException) {
            throw new com.donutsmp.teams.G.A.A("Failed parsing '" + string + "' as SQL Time; at path " + e.Q(), parseException);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void A(C c, Time time) throws IOException {
        String string;
        if (time == null) {
            c.C();
            return;
        }
        A a = this;
        synchronized (a) {
            string = this.\u00c3.format(time);
        }
        c.E(string);
    }
}

