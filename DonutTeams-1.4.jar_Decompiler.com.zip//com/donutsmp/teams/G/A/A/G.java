/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A;

import com.donutsmp.teams.G.A.A.A;
import com.donutsmp.teams.G.A.A.H;
import com.donutsmp.teams.G.A.A.M;
import com.donutsmp.teams.G.A.A.O;
import com.donutsmp.teams.G.A.R;
import com.donutsmp.teams.G.A.W;
import com.donutsmp.teams.G.A._;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentNavigableMap;
import java.util.concurrent.ConcurrentSkipListMap;

public final class G {
    private final Map<Type, _<?>> B;
    private final boolean A;
    private final List<W> C;

    public G(Map<Type, _<?>> map, boolean bl, List<W> list) {
        this.B = map;
        this.A = bl;
        this.C = list;
    }

    static String A(Class<?> clazz) {
        int n = clazz.getModifiers();
        if (Modifier.isInterface(n)) {
            return "Interfaces can't be instantiated! Register an InstanceCreator or a TypeAdapter for this type. Interface name: " + clazz.getName();
        }
        if (Modifier.isAbstract(n)) {
            return "Abstract classes can't be instantiated! Register an InstanceCreator or a TypeAdapter for this type. Class name: " + clazz.getName();
        }
        return null;
    }

    public <T> O<T> A(com.donutsmp.teams.G.A.B.A<T> a) {
        final Type type = a.A();
        Class<T> clazz = a.C();
        final _<?> _2 = this.B.get(type);
        if (_2 != null) {
            return new O<T>(){

                @Override
                public T A() {
                    return _2.A(type);
                }
            };
        }
        final _<?> _3 = this.B.get(clazz);
        if (_3 != null) {
            return new O<T>(){

                @Override
                public T A() {
                    return _3.A(type);
                }
            };
        }
        O<T> o = G.A(type, clazz);
        if (o != null) {
            return o;
        }
        W._A _A2 = M.A(this.C, clazz);
        O<T> o2 = G.A(clazz, _A2);
        if (o2 != null) {
            return o2;
        }
        O<T> o3 = G.B(type, clazz);
        if (o3 != null) {
            return o3;
        }
        final String string = G.A(clazz);
        if (string != null) {
            return new O<T>(){

                @Override
                public T A() {
                    throw new R(string);
                }
            };
        }
        if (_A2 == W._A.C) {
            return this.B(clazz);
        }
        final String string2 = "Unable to create instance of " + clazz + "; ReflectionAccessFilter does not permit using reflection or Unsafe. Register an InstanceCreator or a TypeAdapter for this type or adjust the access filter to allow using reflection.";
        return new O<T>(){

            @Override
            public T A() {
                throw new R(string2);
            }
        };
    }

    private static <T> O<T> A(final Type type, Class<? super T> clazz) {
        if (EnumSet.class.isAssignableFrom(clazz)) {
            return new O<T>(){

                @Override
                public T A() {
                    if (type instanceof ParameterizedType) {
                        Type type2 = ((ParameterizedType)type).getActualTypeArguments()[0];
                        if (type2 instanceof Class) {
                            EnumSet enumSet = EnumSet.noneOf((Class)type2);
                            return enumSet;
                        }
                        throw new R("Invalid EnumSet type: " + type.toString());
                    }
                    throw new R("Invalid EnumSet type: " + type.toString());
                }
            };
        }
        if (clazz == EnumMap.class) {
            return new O<T>(){

                @Override
                public T A() {
                    if (type instanceof ParameterizedType) {
                        Type type2 = ((ParameterizedType)type).getActualTypeArguments()[0];
                        if (type2 instanceof Class) {
                            EnumMap enumMap = new EnumMap((Class)type2);
                            return enumMap;
                        }
                        throw new R("Invalid EnumMap type: " + type.toString());
                    }
                    throw new R("Invalid EnumMap type: " + type.toString());
                }
            };
        }
        return null;
    }

    private static <T> O<T> A(Class<? super T> clazz, W._A _A2) {
        String string;
        boolean bl;
        Constructor<T> constructor;
        if (Modifier.isAbstract(clazz.getModifiers())) {
            return null;
        }
        try {
            constructor = clazz.getDeclaredConstructor(new Class[0]);
        } catch (NoSuchMethodException noSuchMethodException) {
            return null;
        }
        boolean bl2 = bl = _A2 == W._A.C || M.A(constructor, null) && (_A2 != W._A.D || Modifier.isPublic(constructor.getModifiers()));
        if (!bl) {
            final String string2 = "Unable to invoke no-args constructor of " + clazz + "; constructor is not accessible and ReflectionAccessFilter does not permit making it accessible. Register an InstanceCreator or a TypeAdapter for this type, change the visibility of the constructor or adjust the access filter.";
            return new O<T>(){

                @Override
                public T A() {
                    throw new R(string2);
                }
            };
        }
        if (_A2 == W._A.C && (string = com.donutsmp.teams.G.A.A.A.A.A(constructor)) != null) {
            return new O<T>(){

                @Override
                public T A() {
                    throw new R(string);
                }
            };
        }
        return new O<T>(){

            @Override
            public T A() {
                try {
                    Object t = constructor.newInstance(new Object[0]);
                    return t;
                } catch (InstantiationException instantiationException) {
                    throw new RuntimeException("Failed to invoke constructor '" + com.donutsmp.teams.G.A.A.A.A.B(constructor) + "' with no args", instantiationException);
                } catch (InvocationTargetException invocationTargetException) {
                    throw new RuntimeException("Failed to invoke constructor '" + com.donutsmp.teams.G.A.A.A.A.B(constructor) + "' with no args", invocationTargetException.getCause());
                } catch (IllegalAccessException illegalAccessException) {
                    throw com.donutsmp.teams.G.A.A.A.A.A(illegalAccessException);
                }
            }
        };
    }

    private static <T> O<T> B(Type type, Class<? super T> clazz) {
        if (Collection.class.isAssignableFrom(clazz)) {
            if (SortedSet.class.isAssignableFrom(clazz)) {
                return new O<T>(){

                    @Override
                    public T A() {
                        return new TreeSet();
                    }
                };
            }
            if (Set.class.isAssignableFrom(clazz)) {
                return new O<T>(){

                    @Override
                    public T A() {
                        return new LinkedHashSet();
                    }
                };
            }
            if (Queue.class.isAssignableFrom(clazz)) {
                return new O<T>(){

                    @Override
                    public T A() {
                        return new ArrayDeque();
                    }
                };
            }
            return new O<T>(){

                @Override
                public T A() {
                    return new ArrayList();
                }
            };
        }
        if (Map.class.isAssignableFrom(clazz)) {
            if (ConcurrentNavigableMap.class.isAssignableFrom(clazz)) {
                return new O<T>(){

                    @Override
                    public T A() {
                        return new ConcurrentSkipListMap();
                    }
                };
            }
            if (ConcurrentMap.class.isAssignableFrom(clazz)) {
                return new O<T>(){

                    @Override
                    public T A() {
                        return new ConcurrentHashMap();
                    }
                };
            }
            if (SortedMap.class.isAssignableFrom(clazz)) {
                return new O<T>(){

                    @Override
                    public T A() {
                        return new TreeMap();
                    }
                };
            }
            if (type instanceof ParameterizedType && !String.class.isAssignableFrom(com.donutsmp.teams.G.A.B.A.C(((ParameterizedType)type).getActualTypeArguments()[0]).C())) {
                return new O<T>(){

                    @Override
                    public T A() {
                        return new LinkedHashMap();
                    }
                };
            }
            return new O<T>(){

                @Override
                public T A() {
                    return new A();
                }
            };
        }
        return null;
    }

    private <T> O<T> B(final Class<? super T> clazz) {
        if (this.A) {
            return new O<T>(){

                @Override
                public T A() {
                    try {
                        Object t = H.A.C(clazz);
                        return t;
                    } catch (Exception exception) {
                        throw new RuntimeException("Unable to create instance of " + clazz + ". Registering an InstanceCreator or a TypeAdapter for this type, or adding a no-args constructor may fix this problem.", exception);
                    }
                }
            };
        }
        final String string = "Unable to create instance of " + clazz + "; usage of JDK Unsafe is disabled. Registering an InstanceCreator or a TypeAdapter for this type, adding a no-args constructor, or enabling usage of JDK Unsafe may fix this problem.";
        return new O<T>(){

            @Override
            public T A() {
                throw new R(string);
            }
        };
    }

    public String toString() {
        return this.B.toString();
    }
}

