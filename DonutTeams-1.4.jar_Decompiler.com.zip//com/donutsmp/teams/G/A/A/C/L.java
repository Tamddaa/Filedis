/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A.C;

import com.donutsmp.teams.G.A.A;
import com.donutsmp.teams.G.A.A.C.J;
import com.donutsmp.teams.G.A.B;
import com.donutsmp.teams.G.A.C.D;
import com.donutsmp.teams.G.A.D.C;
import com.donutsmp.teams.G.A.D.E;
import com.donutsmp.teams.G.A.G;
import com.donutsmp.teams.G.A.P;
import com.donutsmp.teams.G.A.Q;
import com.donutsmp.teams.G.A.R;
import com.donutsmp.teams.G.A.S;
import com.donutsmp.teams.G.A.U;
import com.donutsmp.teams.G.A.V;
import com.donutsmp.teams.G.A.X;
import java.io.IOException;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Calendar;
import java.util.Currency;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicIntegerArray;

public final class L {
    public static final V<Class> T = new V<Class>(){

        @Override
        public void A(C c, Class clazz) throws IOException {
            throw new UnsupportedOperationException("Attempted to serialize java.lang.Class: " + clazz.getName() + ". Forgot to register a type adapter?");
        }

        public Class h(E e) throws IOException {
            throw new UnsupportedOperationException("Attempted to deserialize a java.lang.Class. Forgot to register a type adapter?");
        }
    }.A();
    public static final B Q = com.donutsmp.teams.G.A.A.C.L.B(Class.class, T);
    public static final V<BitSet> p = new V<BitSet>(){

        public BitSet f(E e) throws IOException {
            BitSet bitSet = new BitSet();
            e.H();
            int n = 0;
            com.donutsmp.teams.G.A.D.A a = e.G();
            while (a != com.donutsmp.teams.G.A.D.A.A) {
                boolean bl;
                switch (a) {
                    case B: 
                    case G: {
                        int n2 = e.Z();
                        if (n2 == 0) {
                            bl = false;
                            break;
                        }
                        if (n2 == 1) {
                            bl = true;
                            break;
                        }
                        throw new A("Invalid bitset value " + n2 + ", expected 0 or 1; at path " + e.Q());
                    }
                    case C: {
                        bl = e.C();
                        break;
                    }
                    default: {
                        throw new A("Invalid bitset value type: " + (Object)((Object)a) + "; at path " + e.J());
                    }
                }
                if (bl) {
                    bitSet.set(n);
                }
                ++n;
                a = e.G();
            }
            e._();
            return bitSet;
        }

        @Override
        public void A(C c, BitSet bitSet) throws IOException {
            c.D();
            int n = bitSet.length();
            for (int i = 0; i < n; ++i) {
                int n2 = bitSet.get(i) ? 1 : 0;
                c.A((long)n2);
            }
            c.H();
        }
    }.A();
    public static final B Y = com.donutsmp.teams.G.A.A.C.L.B(BitSet.class, p);
    public static final V<Boolean> Z = new V<Boolean>(){

        public Boolean d(E e) throws IOException {
            com.donutsmp.teams.G.A.D.A a = e.G();
            if (a == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            if (a == com.donutsmp.teams.G.A.D.A.G) {
                return Boolean.parseBoolean(e.Y());
            }
            return e.C();
        }

        public void B(C c, Boolean bl) throws IOException {
            c.A(bl);
        }
    };
    public static final V<Boolean> E = new V<Boolean>(){

        public Boolean b(E e) throws IOException {
            if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            return Boolean.valueOf(e.Y());
        }

        @Override
        public void A(C c, Boolean bl) throws IOException {
            c.E(bl == null ? "null" : bl.toString());
        }
    };
    public static final B e = com.donutsmp.teams.G.A.A.C.L.B(Boolean.TYPE, Boolean.class, Z);
    public static final V<Number> f = new V<Number>(){

        public Number _(E e) throws IOException {
            int n;
            if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            try {
                n = e.Z();
            } catch (NumberFormatException numberFormatException) {
                throw new A(numberFormatException);
            }
            if (n > 255 || n < -128) {
                throw new A("Lossy conversion from " + n + " to byte; at path " + e.Q());
            }
            return (byte)n;
        }

        public void D(C c, Number number) throws IOException {
            if (number == null) {
                c.C();
            } else {
                c.A((long)number.byteValue());
            }
        }
    };
    public static final B h = com.donutsmp.teams.G.A.A.C.L.B(Byte.TYPE, Byte.class, f);
    public static final V<Number> A = new V<Number>(){

        public Number Y(E e) throws IOException {
            int n;
            if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            try {
                n = e.Z();
            } catch (NumberFormatException numberFormatException) {
                throw new A(numberFormatException);
            }
            if (n > 65535 || n < Short.MIN_VALUE) {
                throw new A("Lossy conversion from " + n + " to short; at path " + e.Q());
            }
            return (short)n;
        }

        public void C(C c, Number number) throws IOException {
            if (number == null) {
                c.C();
            } else {
                c.A((long)number.shortValue());
            }
        }
    };
    public static final B i = com.donutsmp.teams.G.A.A.C.L.B(Short.TYPE, Short.class, A);
    public static final V<Number> K = new V<Number>(){

        public Number W(E e) throws IOException {
            if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            try {
                return e.Z();
            } catch (NumberFormatException numberFormatException) {
                throw new A(numberFormatException);
            }
        }

        public void B(C c, Number number) throws IOException {
            if (number == null) {
                c.C();
            } else {
                c.A((long)number.intValue());
            }
        }
    };
    public static final B P = com.donutsmp.teams.G.A.A.C.L.B(Integer.TYPE, Integer.class, K);
    public static final V<AtomicInteger> j = new V<AtomicInteger>(){

        public AtomicInteger U(E e) throws IOException {
            try {
                return new AtomicInteger(e.Z());
            } catch (NumberFormatException numberFormatException) {
                throw new A(numberFormatException);
            }
        }

        @Override
        public void A(C c, AtomicInteger atomicInteger) throws IOException {
            c.A((long)atomicInteger.get());
        }
    }.A();
    public static final B X = com.donutsmp.teams.G.A.A.C.L.B(AtomicInteger.class, j);
    public static final V<AtomicBoolean> C = new V<AtomicBoolean>(){

        public AtomicBoolean T(E e) throws IOException {
            return new AtomicBoolean(e.C());
        }

        @Override
        public void A(C c, AtomicBoolean atomicBoolean) throws IOException {
            c.A(atomicBoolean.get());
        }
    }.A();
    public static final B l = com.donutsmp.teams.G.A.A.C.L.B(AtomicBoolean.class, C);
    public static final V<AtomicIntegerArray> M = new V<AtomicIntegerArray>(){

        public AtomicIntegerArray k(E e) throws IOException {
            int n;
            ArrayList<Integer> arrayList = new ArrayList<Integer>();
            e.H();
            while (e.A()) {
                try {
                    n = e.Z();
                    arrayList.add(n);
                } catch (NumberFormatException numberFormatException) {
                    throw new A(numberFormatException);
                }
            }
            e._();
            n = arrayList.size();
            AtomicIntegerArray atomicIntegerArray = new AtomicIntegerArray(n);
            for (int i = 0; i < n; ++i) {
                atomicIntegerArray.set(i, (Integer)arrayList.get(i));
            }
            return atomicIntegerArray;
        }

        @Override
        public void A(C c, AtomicIntegerArray atomicIntegerArray) throws IOException {
            c.D();
            int n = atomicIntegerArray.length();
            for (int i = 0; i < n; ++i) {
                c.A((long)atomicIntegerArray.get(i));
            }
            c.H();
        }
    }.A();
    public static final B F = com.donutsmp.teams.G.A.A.C.L.B(AtomicIntegerArray.class, M);
    public static final V<Number> q = new V<Number>(){

        public Number j(E e) throws IOException {
            if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            try {
                return e.B();
            } catch (NumberFormatException numberFormatException) {
                throw new A(numberFormatException);
            }
        }

        public void G(C c, Number number) throws IOException {
            if (number == null) {
                c.C();
            } else {
                c.A(number.longValue());
            }
        }
    };
    public static final V<Number> k = new V<Number>(){

        public Number i(E e) throws IOException {
            if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            return Float.valueOf((float)e.U());
        }

        public void F(C c, Number number) throws IOException {
            if (number == null) {
                c.C();
            } else {
                Number number2 = number instanceof Float ? (Number)number : (Number)Float.valueOf(number.floatValue());
                c.A(number2);
            }
        }
    };
    public static final V<Number> J = new V<Number>(){

        public Number g(E e) throws IOException {
            if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            return e.U();
        }

        public void E(C c, Number number) throws IOException {
            if (number == null) {
                c.C();
            } else {
                c.A(number.doubleValue());
            }
        }
    };
    public static final V<Character> N = new V<Character>(){

        public Character e(E e) throws IOException {
            if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            String string = e.Y();
            if (string.length() != 1) {
                throw new A("Expecting character, got: " + string + "; at " + e.Q());
            }
            return Character.valueOf(string.charAt(0));
        }

        @Override
        public void A(C c, Character c2) throws IOException {
            c.E(c2 == null ? null : String.valueOf(c2));
        }
    };
    public static final B c = com.donutsmp.teams.G.A.A.C.L.B(Character.TYPE, Character.class, N);
    public static final V<String> r = new V<String>(){

        public String c(E e) throws IOException {
            com.donutsmp.teams.G.A.D.A a = e.G();
            if (a == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            if (a == com.donutsmp.teams.G.A.D.A.C) {
                return Boolean.toString(e.C());
            }
            return e.Y();
        }

        @Override
        public void A(C c, String string) throws IOException {
            c.E(string);
        }
    };
    public static final V<BigDecimal> G = new V<BigDecimal>(){

        public BigDecimal a(E e) throws IOException {
            if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            String string = e.Y();
            try {
                return new BigDecimal(string);
            } catch (NumberFormatException numberFormatException) {
                throw new A("Failed parsing '" + string + "' as BigDecimal; at path " + e.Q(), numberFormatException);
            }
        }

        @Override
        public void A(C c, BigDecimal bigDecimal) throws IOException {
            c.A(bigDecimal);
        }
    };
    public static final V<BigInteger> o = new V<BigInteger>(){

        public BigInteger Z(E e) throws IOException {
            if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            String string = e.Y();
            try {
                return new BigInteger(string);
            } catch (NumberFormatException numberFormatException) {
                throw new A("Failed parsing '" + string + "' as BigInteger; at path " + e.Q(), numberFormatException);
            }
        }

        @Override
        public void A(C c, BigInteger bigInteger) throws IOException {
            c.A(bigInteger);
        }
    };
    public static final V<com.donutsmp.teams.G.A.A.J> U = new V<com.donutsmp.teams.G.A.A.J>(){

        public com.donutsmp.teams.G.A.A.J X(E e) throws IOException {
            if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            return new com.donutsmp.teams.G.A.A.J(e.Y());
        }

        @Override
        public void A(C c, com.donutsmp.teams.G.A.A.J j) throws IOException {
            c.A(j);
        }
    };
    public static final B S = com.donutsmp.teams.G.A.A.C.L.B(String.class, r);
    public static final V<StringBuilder> R = new V<StringBuilder>(){

        public StringBuilder V(E e) throws IOException {
            if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            return new StringBuilder(e.Y());
        }

        @Override
        public void A(C c, StringBuilder stringBuilder) throws IOException {
            c.E(stringBuilder == null ? null : stringBuilder.toString());
        }
    };
    public static final B t = com.donutsmp.teams.G.A.A.C.L.B(StringBuilder.class, R);
    public static final V<StringBuffer> V = new V<StringBuffer>(){

        public StringBuffer R(E e) throws IOException {
            if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            return new StringBuffer(e.Y());
        }

        @Override
        public void A(C c, StringBuffer stringBuffer) throws IOException {
            c.E(stringBuffer == null ? null : stringBuffer.toString());
        }
    };
    public static final B L = com.donutsmp.teams.G.A.A.C.L.B(StringBuffer.class, V);
    public static final V<URL> b = new V<URL>(){

        public URL Q(E e) throws IOException {
            if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            String string = e.Y();
            return "null".equals(string) ? null : new URL(string);
        }

        @Override
        public void A(C c, URL uRL) throws IOException {
            c.E(uRL == null ? null : uRL.toExternalForm());
        }
    };
    public static final B w = com.donutsmp.teams.G.A.A.C.L.B(URL.class, b);
    public static final V<URI> d = new V<URI>(){

        public URI P(E e) throws IOException {
            if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            try {
                String string = e.Y();
                return "null".equals(string) ? null : new URI(string);
            } catch (URISyntaxException uRISyntaxException) {
                throw new R(uRISyntaxException);
            }
        }

        @Override
        public void A(C c, URI uRI) throws IOException {
            c.E(uRI == null ? null : uRI.toASCIIString());
        }
    };
    public static final B g = com.donutsmp.teams.G.A.A.C.L.B(URI.class, d);
    public static final V<InetAddress> O = new V<InetAddress>(){

        public InetAddress O(E e) throws IOException {
            if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            return InetAddress.getByName(e.Y());
        }

        @Override
        public void A(C c, InetAddress inetAddress) throws IOException {
            c.E(inetAddress == null ? null : inetAddress.getHostAddress());
        }
    };
    public static final B v = com.donutsmp.teams.G.A.A.C.L.A(InetAddress.class, O);
    public static final V<UUID> _ = new V<UUID>(){

        public UUID N(E e) throws IOException {
            if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            String string = e.Y();
            try {
                return UUID.fromString(string);
            } catch (IllegalArgumentException illegalArgumentException) {
                throw new A("Failed parsing '" + string + "' as UUID; at path " + e.Q(), illegalArgumentException);
            }
        }

        @Override
        public void A(C c, UUID uUID) throws IOException {
            c.E(uUID == null ? null : uUID.toString());
        }
    };
    public static final B W = com.donutsmp.teams.G.A.A.C.L.B(UUID.class, _);
    public static final V<Currency> n = new V<Currency>(){

        public Currency M(E e) throws IOException {
            String string = e.Y();
            try {
                return Currency.getInstance(string);
            } catch (IllegalArgumentException illegalArgumentException) {
                throw new A("Failed parsing '" + string + "' as Currency; at path " + e.Q(), illegalArgumentException);
            }
        }

        @Override
        public void A(C c, Currency currency) throws IOException {
            c.E(currency.getCurrencyCode());
        }
    }.A();
    public static final B I = com.donutsmp.teams.G.A.A.C.L.B(Currency.class, n);
    public static final V<Calendar> m = new V<Calendar>(){
        private static final String m = "year";
        private static final String l = "month";
        private static final String j = "dayOfMonth";
        private static final String h = "hourOfDay";
        private static final String k = "minute";
        private static final String i = "second";

        public Calendar L(E e) throws IOException {
            if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            e.V();
            int n = 0;
            int n2 = 0;
            int n3 = 0;
            int n4 = 0;
            int n5 = 0;
            int n6 = 0;
            while (e.G() != com.donutsmp.teams.G.A.D.A.I) {
                String string = e.I();
                int n7 = e.Z();
                if (m.equals(string)) {
                    n = n7;
                    continue;
                }
                if (l.equals(string)) {
                    n2 = n7;
                    continue;
                }
                if (j.equals(string)) {
                    n3 = n7;
                    continue;
                }
                if (h.equals(string)) {
                    n4 = n7;
                    continue;
                }
                if (k.equals(string)) {
                    n5 = n7;
                    continue;
                }
                if (!i.equals(string)) continue;
                n6 = n7;
            }
            e.O();
            return new GregorianCalendar(n, n2, n3, n4, n5, n6);
        }

        @Override
        public void A(C c, Calendar calendar) throws IOException {
            if (calendar == null) {
                c.C();
                return;
            }
            c.F();
            c.B(m);
            c.A((long)calendar.get(1));
            c.B(l);
            c.A((long)calendar.get(2));
            c.B(j);
            c.A((long)calendar.get(5));
            c.B(h);
            c.A((long)calendar.get(11));
            c.B(k);
            c.A((long)calendar.get(12));
            c.B(i);
            c.A((long)calendar.get(13));
            c.B();
        }
    };
    public static final B a = com.donutsmp.teams.G.A.A.C.L.A(Calendar.class, GregorianCalendar.class, m);
    public static final V<Locale> B = new V<Locale>(){

        public Locale K(E e) throws IOException {
            if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            String string = e.Y();
            StringTokenizer stringTokenizer = new StringTokenizer(string, "_");
            String string2 = null;
            String string3 = null;
            String string4 = null;
            if (stringTokenizer.hasMoreElements()) {
                string2 = stringTokenizer.nextToken();
            }
            if (stringTokenizer.hasMoreElements()) {
                string3 = stringTokenizer.nextToken();
            }
            if (stringTokenizer.hasMoreElements()) {
                string4 = stringTokenizer.nextToken();
            }
            if (string3 == null && string4 == null) {
                return new Locale(string2);
            }
            if (string4 == null) {
                return new Locale(string2, string3);
            }
            return new Locale(string2, string3, string4);
        }

        @Override
        public void A(C c, Locale locale) throws IOException {
            c.E(locale == null ? null : locale.toString());
        }
    };
    public static final B s = com.donutsmp.teams.G.A.A.C.L.B(Locale.class, B);
    public static final V<P> u = new V<P>(){

        private P B(E e, com.donutsmp.teams.G.A.D.A a) throws IOException {
            switch (a) {
                case F: {
                    e.H();
                    return new X();
                }
                case J: {
                    e.V();
                    return new S();
                }
            }
            return null;
        }

        private P A(E e, com.donutsmp.teams.G.A.D.A a) throws IOException {
            switch (a) {
                case G: {
                    return new G(e.Y());
                }
                case B: {
                    String string = e.Y();
                    return new G(new com.donutsmp.teams.G.A.A.J(string));
                }
                case C: {
                    return new G(e.C());
                }
                case E: {
                    e.S();
                    return com.donutsmp.teams.G.A.U.B;
                }
            }
            throw new IllegalStateException("Unexpected token: " + (Object)((Object)a));
        }

        public P J(E e) throws IOException {
            if (e instanceof J) {
                return ((J)e).d();
            }
            com.donutsmp.teams.G.A.D.A a = e.G();
            P p = this.B(e, a);
            if (p == null) {
                return this.A(e, a);
            }
            ArrayDeque<P> arrayDeque = new ArrayDeque<P>();
            while (true) {
                if (e.A()) {
                    P p2;
                    boolean bl;
                    String string = null;
                    if (p instanceof S) {
                        string = e.I();
                    }
                    boolean bl2 = bl = (p2 = this.B(e, a = e.G())) != null;
                    if (p2 == null) {
                        p2 = this.A(e, a);
                    }
                    if (p instanceof X) {
                        ((X)p).C(p2);
                    } else {
                        ((S)p).A(string, p2);
                    }
                    if (!bl) continue;
                    arrayDeque.addLast(p);
                    p = p2;
                    continue;
                }
                if (p instanceof X) {
                    e._();
                } else {
                    e.O();
                }
                if (arrayDeque.isEmpty()) {
                    return p;
                }
                p = (P)arrayDeque.removeLast();
            }
        }

        @Override
        public void A(C c, P p) throws IOException {
            if (p == null || p.L()) {
                c.C();
            } else if (p.C()) {
                G g = p.E();
                if (g.i()) {
                    c.A(g.D());
                } else if (g.g()) {
                    c.A(g.S());
                } else {
                    c.E(g.M());
                }
            } else if (p.J()) {
                c.D();
                for (P p2 : p.T()) {
                    this.A(c, p2);
                }
                c.H();
            } else if (p.K()) {
                c.F();
                for (Map.Entry<String, P> entry : p.P().Z()) {
                    c.B(entry.getKey());
                    this.A(c, entry.getValue());
                }
                c.B();
            } else {
                throw new IllegalArgumentException("Couldn't write " + p.getClass());
            }
        }
    };
    public static final B D = com.donutsmp.teams.G.A.A.C.L.A(P.class, u);
    public static final B H = new B(){

        @Override
        public <T> V<T> A(Q q, com.donutsmp.teams.G.A.B.A<T> a) {
            Class<T> clazz = a.C();
            if (!Enum.class.isAssignableFrom(clazz) || clazz == Enum.class) {
                return null;
            }
            if (!clazz.isEnum()) {
                clazz = clazz.getSuperclass();
            }
            _A<T> _A2 = new _A<T>(clazz);
            return _A2;
        }
    };

    private L() {
        throw new UnsupportedOperationException();
    }

    public static <TT> B A(final com.donutsmp.teams.G.A.B.A<TT> a, final V<TT> v) {
        return new B(){

            @Override
            public <T> V<T> A(Q q, com.donutsmp.teams.G.A.B.A<T> a2) {
                return a2.equals(a) ? v : null;
            }
        };
    }

    public static <TT> B B(final Class<TT> clazz, final V<TT> v) {
        return new B(){

            @Override
            public <T> V<T> A(Q q, com.donutsmp.teams.G.A.B.A<T> a) {
                return a.C() == clazz ? v : null;
            }

            public String toString() {
                return "Factory[type=" + clazz.getName() + ",adapter=" + v + "]";
            }
        };
    }

    public static <TT> B B(final Class<TT> clazz, final Class<TT> clazz2, final V<? super TT> v) {
        return new B(){

            @Override
            public <T> V<T> A(Q q, com.donutsmp.teams.G.A.B.A<T> a) {
                Class<T> clazz3 = a.C();
                return clazz3 == clazz || clazz3 == clazz2 ? v : null;
            }

            public String toString() {
                return "Factory[type=" + clazz2.getName() + "+" + clazz.getName() + ",adapter=" + v + "]";
            }
        };
    }

    public static <TT> B A(final Class<TT> clazz, final Class<? extends TT> clazz2, final V<? super TT> v) {
        return new B(){

            @Override
            public <T> V<T> A(Q q, com.donutsmp.teams.G.A.B.A<T> a) {
                Class<T> clazz3 = a.C();
                return clazz3 == clazz || clazz3 == clazz2 ? v : null;
            }

            public String toString() {
                return "Factory[type=" + clazz.getName() + "+" + clazz2.getName() + ",adapter=" + v + "]";
            }
        };
    }

    public static <T1> B A(final Class<T1> clazz, final V<T1> v) {
        return new B(){

            public <T2> V<T2> A(Q q, com.donutsmp.teams.G.A.B.A<T2> a) {
                final Class<T2> clazz2 = a.C();
                if (!clazz.isAssignableFrom(clazz2)) {
                    return null;
                }
                return new V<T1>(){

                    @Override
                    public void A(C c, T1 T1) throws IOException {
                        v.A(c, T1);
                    }

                    @Override
                    public T1 A(E e) throws IOException {
                        Object t = v.A(e);
                        if (t != null && !clazz2.isInstance(t)) {
                            throw new A("Expected a " + clazz2.getName() + " but was " + t.getClass().getName() + "; at path " + e.Q());
                        }
                        return t;
                    }
                };
            }

            public String toString() {
                return "Factory[typeHierarchy=" + clazz.getName() + ",adapter=" + v + "]";
            }
        };
    }

    private static final class _A<T extends Enum<T>>
    extends V<T> {
        private final Map<String, T> p = new HashMap<String, T>();
        private final Map<String, T> n = new HashMap<String, T>();
        private final Map<T, String> o = new HashMap<T, String>();

        public _A(final Class<T> clazz) {
            try {
                Field[] fieldArray;
                for (Field field : fieldArray = AccessController.doPrivileged(new PrivilegedAction<Field[]>(){

                    public Field[] A() {
                        AccessibleObject[] accessibleObjectArray = clazz.getDeclaredFields();
                        ArrayList<Field> arrayList = new ArrayList<Field>(accessibleObjectArray.length);
                        for (Field field : accessibleObjectArray) {
                            if (!field.isEnumConstant()) continue;
                            arrayList.add(field);
                        }
                        AccessibleObject[] accessibleObjectArray2 = arrayList.toArray(new Field[0]);
                        AccessibleObject.setAccessible(accessibleObjectArray2, true);
                        return accessibleObjectArray2;
                    }
                })) {
                    Enum enum_ = (Enum)field.get(null);
                    String string = enum_.name();
                    String string2 = enum_.toString();
                    D d = field.getAnnotation(D.class);
                    if (d != null) {
                        string = d.A();
                        for (String string3 : d.B()) {
                            this.p.put(string3, enum_);
                        }
                    }
                    this.p.put(string, enum_);
                    this.n.put(string2, enum_);
                    this.o.put(enum_, string);
                }
            } catch (IllegalAccessException illegalAccessException) {
                throw new AssertionError((Object)illegalAccessException);
            }
        }

        public T S(E e) throws IOException {
            if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            String string = e.Y();
            Enum enum_ = (Enum)this.p.get(string);
            return (T)(enum_ == null ? (Enum)this.n.get(string) : enum_);
        }

        @Override
        public void A(C c, T t) throws IOException {
            c.E(t == null ? null : this.o.get(t));
        }
    }
}

