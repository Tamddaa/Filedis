/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A.C;

import com.donutsmp.teams.G.A.A.C.D;
import com.donutsmp.teams.G.A.A.G;
import com.donutsmp.teams.G.A.A.N$_B;
import com.donutsmp.teams.G.A.A.O;
import com.donutsmp.teams.G.A.D.A;
import com.donutsmp.teams.G.A.D.C;
import com.donutsmp.teams.G.A.D.E;
import com.donutsmp.teams.G.A.Q;
import com.donutsmp.teams.G.A.V;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Collection;

public final class B
implements com.donutsmp.teams.G.A.B {
    private final G A;

    public B(G g) {
        this.A = g;
    }

    @Override
    public <T> V<T> A(Q q, com.donutsmp.teams.G.A.B.A<T> a) {
        Type type = a.A();
        Class<T> clazz = a.C();
        if (!Collection.class.isAssignableFrom(clazz)) {
            return null;
        }
        Type type2 = N$_B.B(type, clazz);
        V<?> v = q.A(com.donutsmp.teams.G.A.B.A.C(type2));
        O<T> o = this.A.A(a);
        _A _A2 = new _A(q, type2, v, o);
        return _A2;
    }

    private static final class _A<E>
    extends V<Collection<E>> {
        private final V<E> I;
        private final O<? extends Collection<E>> H;

        public _A(Q q, Type type, V<E> v, O<? extends Collection<E>> o) {
            this.I = new D<E>(q, v, type);
            this.H = o;
        }

        public Collection<E> F(E e) throws IOException {
            if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                e.S();
                return null;
            }
            Collection<E> collection = this.H.A();
            e.H();
            while (e.A()) {
                E e2 = this.I.A(e);
                collection.add(e2);
            }
            e._();
            return collection;
        }

        @Override
        public void A(C c, Collection<E> collection) throws IOException {
            if (collection == null) {
                c.C();
                return;
            }
            c.D();
            for (E e : collection) {
                this.I.A(c, e);
            }
            c.H();
        }
    }
}

