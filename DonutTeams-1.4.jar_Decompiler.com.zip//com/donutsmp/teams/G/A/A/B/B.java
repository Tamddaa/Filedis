/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A.B;

import com.donutsmp.teams.G.A.B.A;
import com.donutsmp.teams.G.A.D.C;
import com.donutsmp.teams.G.A.D.E;
import com.donutsmp.teams.G.A.Q;
import com.donutsmp.teams.G.A.V;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;

class B
extends V<Timestamp> {
    static final com.donutsmp.teams.G.A.B A = new com.donutsmp.teams.G.A.B(){

        @Override
        public <T> V<T> A(Q q, A<T> a) {
            if (a.C() == Timestamp.class) {
                V<Date> v = q.A(Date.class);
                return new B(v);
            }
            return null;
        }
    };
    private final V<Date> B;

    private B(V<Date> v) {
        this.B = v;
    }

    public Timestamp B(E e) throws IOException {
        Date date = this.B.A(e);
        return date != null ? new Timestamp(date.getTime()) : null;
    }

    @Override
    public void A(C c, Timestamp timestamp) throws IOException {
        this.B.A(c, (Date)timestamp);
    }
}

