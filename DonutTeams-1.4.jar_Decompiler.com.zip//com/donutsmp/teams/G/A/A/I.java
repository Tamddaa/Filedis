/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A;

import com.donutsmp.teams.G.A.A;
import com.donutsmp.teams.G.A.A.C.L;
import com.donutsmp.teams.G.A.D.C;
import com.donutsmp.teams.G.A.D.D;
import com.donutsmp.teams.G.A.D.E;
import com.donutsmp.teams.G.A.P;
import com.donutsmp.teams.G.A.R;
import com.donutsmp.teams.G.A.T;
import com.donutsmp.teams.G.A.U;
import java.io.EOFException;
import java.io.IOException;
import java.io.Writer;
import java.util.Objects;

public final class I {
    private I() {
        throw new UnsupportedOperationException();
    }

    public static P A(E e) throws T {
        boolean bl = true;
        try {
            e.G();
            bl = false;
            return L.u.A(e);
        } catch (EOFException eOFException) {
            if (bl) {
                return U.B;
            }
            throw new A(eOFException);
        } catch (D d) {
            throw new A(d);
        } catch (IOException iOException) {
            throw new R(iOException);
        } catch (NumberFormatException numberFormatException) {
            throw new A(numberFormatException);
        }
    }

    public static void A(P p, C c) throws IOException {
        L.u.A(c, p);
    }

    public static Writer A(Appendable appendable) {
        return appendable instanceof Writer ? (Writer)appendable : new _A(appendable);
    }

    private static final class com.donutsmp.teams.G.A.A.I$_A
    extends Writer {
        private final Appendable B;
        private final _A A = new _A();

        com.donutsmp.teams.G.A.A.I$_A(Appendable appendable) {
            this.B = appendable;
        }

        @Override
        public void write(char[] cArray, int n, int n2) throws IOException {
            this.A.A(cArray);
            this.B.append(this.A, n, n + n2);
        }

        @Override
        public void flush() {
        }

        @Override
        public void close() {
        }

        @Override
        public void write(int n) throws IOException {
            this.B.append((char)n);
        }

        @Override
        public void write(String string, int n, int n2) throws IOException {
            Objects.requireNonNull(string);
            this.B.append(string, n, n + n2);
        }

        @Override
        public Writer append(CharSequence charSequence) throws IOException {
            this.B.append(charSequence);
            return this;
        }

        @Override
        public Writer append(CharSequence charSequence, int n, int n2) throws IOException {
            this.B.append(charSequence, n, n2);
            return this;
        }

        private static class _A
        implements CharSequence {
            private char[] A;
            private String B;

            private _A() {
            }

            void A(char[] cArray) {
                this.A = cArray;
                this.B = null;
            }

            @Override
            public int length() {
                return this.A.length;
            }

            @Override
            public char charAt(int n) {
                return this.A[n];
            }

            @Override
            public CharSequence subSequence(int n, int n2) {
                return new String(this.A, n, n2 - n);
            }

            @Override
            public String toString() {
                if (this.B == null) {
                    this.B = new String(this.A);
                }
                return this.B;
            }
        }
    }
}

