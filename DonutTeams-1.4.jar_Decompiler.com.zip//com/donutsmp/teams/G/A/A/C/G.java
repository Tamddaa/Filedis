/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A.C;

import com.donutsmp.teams.G.A.D.C;
import com.donutsmp.teams.G.A.P;
import com.donutsmp.teams.G.A.S;
import com.donutsmp.teams.G.A.U;
import com.donutsmp.teams.G.A.X;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public final class G
extends C {
    private static final Writer P = new Writer(){

        @Override
        public void write(char[] cArray, int n, int n2) {
            throw new AssertionError();
        }

        @Override
        public void flush() {
            throw new AssertionError();
        }

        @Override
        public void close() {
            throw new AssertionError();
        }
    };
    private static final com.donutsmp.teams.G.A.G N = new com.donutsmp.teams.G.A.G("closed");
    private final List<P> M = new ArrayList<P>();
    private String O;
    private P Q = U.B;

    public G() {
        super(P);
    }

    public P O() {
        if (!this.M.isEmpty()) {
            throw new IllegalStateException("Expected one JSON element but was " + this.M);
        }
        return this.Q;
    }

    private P N() {
        return this.M.get(this.M.size() - 1);
    }

    private void A(P p) {
        if (this.O != null) {
            if (!p.L() || this.E()) {
                S s = (S)this.N();
                s.A(this.O, p);
            }
            this.O = null;
        } else if (this.M.isEmpty()) {
            this.Q = p;
        } else {
            P p2 = this.N();
            if (p2 instanceof X) {
                ((X)p2).C(p);
            } else {
                throw new IllegalStateException();
            }
        }
    }

    @Override
    public C D() throws IOException {
        X x = new X();
        this.A(x);
        this.M.add(x);
        return this;
    }

    @Override
    public C H() throws IOException {
        if (this.M.isEmpty() || this.O != null) {
            throw new IllegalStateException();
        }
        P p = this.N();
        if (p instanceof X) {
            this.M.remove(this.M.size() - 1);
            return this;
        }
        throw new IllegalStateException();
    }

    @Override
    public C F() throws IOException {
        S s = new S();
        this.A(s);
        this.M.add(s);
        return this;
    }

    @Override
    public C B() throws IOException {
        if (this.M.isEmpty() || this.O != null) {
            throw new IllegalStateException();
        }
        P p = this.N();
        if (p instanceof S) {
            this.M.remove(this.M.size() - 1);
            return this;
        }
        throw new IllegalStateException();
    }

    @Override
    public C B(String string) throws IOException {
        Objects.requireNonNull(string, "name == null");
        if (this.M.isEmpty() || this.O != null) {
            throw new IllegalStateException();
        }
        P p = this.N();
        if (p instanceof S) {
            this.O = string;
            return this;
        }
        throw new IllegalStateException();
    }

    @Override
    public C E(String string) throws IOException {
        if (string == null) {
            return this.C();
        }
        this.A(new com.donutsmp.teams.G.A.G(string));
        return this;
    }

    @Override
    public C D(String string) throws IOException {
        throw new UnsupportedOperationException();
    }

    @Override
    public C C() throws IOException {
        this.A(U.B);
        return this;
    }

    @Override
    public C A(boolean bl) throws IOException {
        this.A(new com.donutsmp.teams.G.A.G(bl));
        return this;
    }

    @Override
    public C A(Boolean bl) throws IOException {
        if (bl == null) {
            return this.C();
        }
        this.A(new com.donutsmp.teams.G.A.G(bl));
        return this;
    }

    @Override
    public C A(float f) throws IOException {
        if (!this.G() && (Float.isNaN(f) || Float.isInfinite(f))) {
            throw new IllegalArgumentException("JSON forbids NaN and infinities: " + f);
        }
        this.A(new com.donutsmp.teams.G.A.G(Float.valueOf(f)));
        return this;
    }

    @Override
    public C A(double d) throws IOException {
        if (!this.G() && (Double.isNaN(d) || Double.isInfinite(d))) {
            throw new IllegalArgumentException("JSON forbids NaN and infinities: " + d);
        }
        this.A(new com.donutsmp.teams.G.A.G(d));
        return this;
    }

    @Override
    public C A(long l) throws IOException {
        this.A(new com.donutsmp.teams.G.A.G(l));
        return this;
    }

    @Override
    public C A(Number number) throws IOException {
        double d;
        if (number == null) {
            return this.C();
        }
        if (!this.G() && (Double.isNaN(d = number.doubleValue()) || Double.isInfinite(d))) {
            throw new IllegalArgumentException("JSON forbids NaN and infinities: " + number);
        }
        this.A(new com.donutsmp.teams.G.A.G(number));
        return this;
    }

    @Override
    public void flush() throws IOException {
    }

    @Override
    public void close() throws IOException {
        if (!this.M.isEmpty()) {
            throw new IOException("Incomplete document");
        }
        this.M.add(N);
    }
}

