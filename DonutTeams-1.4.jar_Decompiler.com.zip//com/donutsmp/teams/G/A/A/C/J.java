/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A.C;

import com.donutsmp.teams.G.A.D.A;
import com.donutsmp.teams.G.A.D.D;
import com.donutsmp.teams.G.A.D.E;
import com.donutsmp.teams.G.A.G;
import com.donutsmp.teams.G.A.P;
import com.donutsmp.teams.G.A.S;
import com.donutsmp.teams.G.A.U;
import com.donutsmp.teams.G.A.X;
import java.io.IOException;
import java.io.Reader;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;

public final class J
extends E {
    private static final Reader r = new Reader(){

        @Override
        public int read(char[] cArray, int n, int n2) {
            throw new AssertionError();
        }

        @Override
        public void close() {
            throw new AssertionError();
        }
    };
    private static final Object t = new Object();
    private Object[] q = new Object[32];
    private int s = 0;
    private String[] u = new String[32];
    private int[] v = new int[32];

    public J(P p) {
        super(r);
        this.A(p);
    }

    @Override
    public void H() throws IOException {
        this.A(A.F);
        X x = (X)this.a();
        this.A(x.iterator());
        this.v[this.s - 1] = 0;
    }

    @Override
    public void _() throws IOException {
        this.A(A.A);
        this.c();
        this.c();
        if (this.s > 0) {
            int n = this.s - 1;
            this.v[n] = this.v[n] + 1;
        }
    }

    @Override
    public void V() throws IOException {
        this.A(A.J);
        S s = (S)this.a();
        this.A(s.Z().iterator());
    }

    @Override
    public void O() throws IOException {
        this.A(A.I);
        this.u[this.s - 1] = null;
        this.c();
        this.c();
        if (this.s > 0) {
            int n = this.s - 1;
            this.v[n] = this.v[n] + 1;
        }
    }

    @Override
    public boolean A() throws IOException {
        A a = this.G();
        return a != A.I && a != A.A && a != A.H;
    }

    @Override
    public A G() throws IOException {
        if (this.s == 0) {
            return A.H;
        }
        Object object = this.a();
        if (object instanceof Iterator) {
            boolean bl = this.q[this.s - 2] instanceof S;
            Iterator iterator = (Iterator)object;
            if (iterator.hasNext()) {
                if (bl) {
                    return A.K;
                }
                this.A(iterator.next());
                return this.G();
            }
            return bl ? A.I : A.A;
        }
        if (object instanceof S) {
            return A.J;
        }
        if (object instanceof X) {
            return A.F;
        }
        if (object instanceof G) {
            G g = (G)object;
            if (g.h()) {
                return A.G;
            }
            if (g.g()) {
                return A.C;
            }
            if (g.i()) {
                return A.B;
            }
            throw new AssertionError();
        }
        if (object instanceof U) {
            return A.E;
        }
        if (object == t) {
            throw new IllegalStateException("JsonReader is closed");
        }
        throw new D("Custom JsonElement subclass " + object.getClass().getName() + " is not supported");
    }

    private Object a() {
        return this.q[this.s - 1];
    }

    private Object c() {
        Object object = this.q[--this.s];
        this.q[this.s] = null;
        return object;
    }

    private void A(A a) throws IOException {
        if (this.G() != a) {
            throw new IllegalStateException("Expected " + (Object)((Object)a) + " but was " + (Object)((Object)this.G()) + this.e());
        }
    }

    private String E(boolean bl) throws IOException {
        this.A(A.K);
        Iterator iterator = (Iterator)this.a();
        Map.Entry entry = (Map.Entry)iterator.next();
        String string = (String)entry.getKey();
        this.u[this.s - 1] = bl ? "<skipped>" : string;
        this.A(entry.getValue());
        return string;
    }

    @Override
    public String I() throws IOException {
        return this.E(false);
    }

    @Override
    public String Y() throws IOException {
        A a = this.G();
        if (a != A.G && a != A.B) {
            throw new IllegalStateException("Expected " + (Object)((Object)A.G) + " but was " + (Object)((Object)a) + this.e());
        }
        String string = ((G)this.c()).M();
        if (this.s > 0) {
            int n = this.s - 1;
            this.v[n] = this.v[n] + 1;
        }
        return string;
    }

    @Override
    public boolean C() throws IOException {
        this.A(A.C);
        boolean bl = ((G)this.c()).S();
        if (this.s > 0) {
            int n = this.s - 1;
            this.v[n] = this.v[n] + 1;
        }
        return bl;
    }

    @Override
    public void S() throws IOException {
        this.A(A.E);
        this.c();
        if (this.s > 0) {
            int n = this.s - 1;
            this.v[n] = this.v[n] + 1;
        }
    }

    @Override
    public double U() throws IOException {
        A a = this.G();
        if (a != A.B && a != A.G) {
            throw new IllegalStateException("Expected " + (Object)((Object)A.B) + " but was " + (Object)((Object)a) + this.e());
        }
        double d = ((G)this.a()).H();
        if (!this.F() && (Double.isNaN(d) || Double.isInfinite(d))) {
            throw new D("JSON forbids NaN and infinities: " + d);
        }
        this.c();
        if (this.s > 0) {
            int n = this.s - 1;
            this.v[n] = this.v[n] + 1;
        }
        return d;
    }

    @Override
    public long B() throws IOException {
        A a = this.G();
        if (a != A.B && a != A.G) {
            throw new IllegalStateException("Expected " + (Object)((Object)A.B) + " but was " + (Object)((Object)a) + this.e());
        }
        long l = ((G)this.a()).F();
        this.c();
        if (this.s > 0) {
            int n = this.s - 1;
            this.v[n] = this.v[n] + 1;
        }
        return l;
    }

    @Override
    public int Z() throws IOException {
        A a = this.G();
        if (a != A.B && a != A.G) {
            throw new IllegalStateException("Expected " + (Object)((Object)A.B) + " but was " + (Object)((Object)a) + this.e());
        }
        int n = ((G)this.a()).U();
        this.c();
        if (this.s > 0) {
            int n2 = this.s - 1;
            this.v[n2] = this.v[n2] + 1;
        }
        return n;
    }

    P d() throws IOException {
        A a = this.G();
        if (a == A.K || a == A.A || a == A.I || a == A.H) {
            throw new IllegalStateException("Unexpected " + (Object)((Object)a) + " when reading a JsonElement.");
        }
        P p = (P)this.a();
        this.N();
        return p;
    }

    @Override
    public void close() throws IOException {
        this.q = new Object[]{t};
        this.s = 1;
    }

    @Override
    public void N() throws IOException {
        A a = this.G();
        switch (a) {
            case K: {
                String string = this.E(true);
                break;
            }
            case A: {
                this._();
                break;
            }
            case I: {
                this.O();
                break;
            }
            case H: {
                break;
            }
            default: {
                this.c();
                if (this.s <= 0) break;
                int n = this.s - 1;
                this.v[n] = this.v[n] + 1;
            }
        }
    }

    @Override
    public String toString() {
        return this.getClass().getSimpleName() + this.e();
    }

    public void b() throws IOException {
        this.A(A.K);
        Iterator iterator = (Iterator)this.a();
        Map.Entry entry = (Map.Entry)iterator.next();
        this.A(entry.getValue());
        this.A(new G((String)entry.getKey()));
    }

    private void A(Object object) {
        if (this.s == this.q.length) {
            int n = this.s * 2;
            this.q = Arrays.copyOf(this.q, n);
            this.v = Arrays.copyOf(this.v, n);
            this.u = Arrays.copyOf(this.u, n);
        }
        this.q[this.s++] = object;
    }

    private String D(boolean bl) {
        StringBuilder stringBuilder = new StringBuilder().append('$');
        for (int i = 0; i < this.s; ++i) {
            if (this.q[i] instanceof X) {
                if (++i >= this.s || !(this.q[i] instanceof Iterator)) continue;
                int n = this.v[i];
                if (bl && n > 0 && (i == this.s - 1 || i == this.s - 2)) {
                    --n;
                }
                stringBuilder.append('[').append(n).append(']');
                continue;
            }
            if (!(this.q[i] instanceof S) || ++i >= this.s || !(this.q[i] instanceof Iterator)) continue;
            stringBuilder.append('.');
            if (this.u[i] == null) continue;
            stringBuilder.append(this.u[i]);
        }
        return stringBuilder.toString();
    }

    @Override
    public String Q() {
        return this.D(true);
    }

    @Override
    public String J() {
        return this.D(false);
    }

    private String e() {
        return " at path " + this.J();
    }
}

