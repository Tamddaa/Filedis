/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A.A;

import com.donutsmp.teams.G.A.R;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class A {
    private static final _C A;

    private A() {
    }

    public static void A(AccessibleObject accessibleObject) throws R {
        try {
            accessibleObject.setAccessible(true);
        } catch (Exception exception) {
            String string = com.donutsmp.teams.G.A.A.A.A.A(accessibleObject, false);
            throw new R("Failed making " + string + " accessible; either increase its visibility or write a custom TypeAdapter for its declaring type.", exception);
        }
    }

    public static String A(AccessibleObject accessibleObject, boolean bl) {
        String string;
        if (accessibleObject instanceof Field) {
            string = "field '" + com.donutsmp.teams.G.A.A.A.A.A((Field)accessibleObject) + "'";
        } else if (accessibleObject instanceof Method) {
            Method method = (Method)accessibleObject;
            StringBuilder stringBuilder = new StringBuilder(method.getName());
            com.donutsmp.teams.G.A.A.A.A.A((AccessibleObject)method, stringBuilder);
            String string2 = stringBuilder.toString();
            string = "method '" + method.getDeclaringClass().getName() + "#" + string2 + "'";
        } else {
            string = accessibleObject instanceof Constructor ? "constructor '" + com.donutsmp.teams.G.A.A.A.A.B((Constructor)accessibleObject) + "'" : "<unknown AccessibleObject> " + accessibleObject.toString();
        }
        if (bl && Character.isLowerCase(string.charAt(0))) {
            string = Character.toUpperCase(string.charAt(0)) + string.substring(1);
        }
        return string;
    }

    public static String A(Field field) {
        return field.getDeclaringClass().getName() + "#" + field.getName();
    }

    public static String B(Constructor<?> constructor) {
        StringBuilder stringBuilder = new StringBuilder(constructor.getDeclaringClass().getName());
        com.donutsmp.teams.G.A.A.A.A.A(constructor, stringBuilder);
        return stringBuilder.toString();
    }

    private static void A(AccessibleObject accessibleObject, StringBuilder stringBuilder) {
        stringBuilder.append('(');
        Class<?>[] classArray = accessibleObject instanceof Method ? ((Method)accessibleObject).getParameterTypes() : ((Constructor)accessibleObject).getParameterTypes();
        for (int i = 0; i < classArray.length; ++i) {
            if (i > 0) {
                stringBuilder.append(", ");
            }
            stringBuilder.append(classArray[i].getSimpleName());
        }
        stringBuilder.append(')');
    }

    public static String A(Constructor<?> constructor) {
        try {
            constructor.setAccessible(true);
            return null;
        } catch (Exception exception) {
            return "Failed making constructor '" + com.donutsmp.teams.G.A.A.A.A.B(constructor) + "' accessible; either increase its visibility or write a custom InstanceCreator or TypeAdapter for its declaring type: " + exception.getMessage();
        }
    }

    public static boolean B(Class<?> clazz) {
        return A.C(clazz);
    }

    public static String[] A(Class<?> clazz) {
        return A.A(clazz);
    }

    public static Method A(Class<?> clazz, Field field) {
        return A.A(clazz, field);
    }

    public static <T> Constructor<T> C(Class<T> clazz) {
        return A.B(clazz);
    }

    public static RuntimeException A(IllegalAccessException illegalAccessException) {
        throw new RuntimeException("Unexpected IllegalAccessException occurred (Gson 2.10.1). Certain ReflectionAccessFilter features require Java >= 9 to work correctly. If you are not using ReflectionAccessFilter, report this to the Gson maintainers.", illegalAccessException);
    }

    private static RuntimeException B(ReflectiveOperationException reflectiveOperationException) {
        throw new RuntimeException("Unexpected ReflectiveOperationException occurred (Gson 2.10.1). To support Java records, reflection is utilized to read out information about records. All these invocations happens after it is established that records exist in the JVM. This exception is unexpected behavior.", reflectiveOperationException);
    }

    static {
        _C _C2;
        try {
            _C2 = new _A();
        } catch (NoSuchMethodException noSuchMethodException) {
            _C2 = new _B();
        }
        A = _C2;
    }

    private static class _B
    extends _C {
        private _B() {
        }

        @Override
        boolean C(Class<?> clazz) {
            return false;
        }

        @Override
        String[] A(Class<?> clazz) {
            throw new UnsupportedOperationException("Records are not supported on this JVM, this method should not be called");
        }

        @Override
        <T> Constructor<T> B(Class<T> clazz) {
            throw new UnsupportedOperationException("Records are not supported on this JVM, this method should not be called");
        }

        @Override
        public Method A(Class<?> clazz, Field field) {
            throw new UnsupportedOperationException("Records are not supported on this JVM, this method should not be called");
        }
    }

    private static class _A
    extends _C {
        private final Method D = Class.class.getMethod("isRecord", new Class[0]);
        private final Method A = Class.class.getMethod("getRecordComponents", new Class[0]);
        private final Method B;
        private final Method C;

        private _A() throws NoSuchMethodException {
            Class<?> clazz = this.A.getReturnType().getComponentType();
            this.B = clazz.getMethod("getName", new Class[0]);
            this.C = clazz.getMethod("getType", new Class[0]);
        }

        @Override
        boolean C(Class<?> clazz) {
            try {
                return (Boolean)this.D.invoke(clazz, new Object[0]);
            } catch (ReflectiveOperationException reflectiveOperationException) {
                throw com.donutsmp.teams.G.A.A.A.A.B(reflectiveOperationException);
            }
        }

        @Override
        String[] A(Class<?> clazz) {
            try {
                Object[] objectArray = (Object[])this.A.invoke(clazz, new Object[0]);
                String[] stringArray = new String[objectArray.length];
                for (int i = 0; i < objectArray.length; ++i) {
                    stringArray[i] = (String)this.B.invoke(objectArray[i], new Object[0]);
                }
                return stringArray;
            } catch (ReflectiveOperationException reflectiveOperationException) {
                throw com.donutsmp.teams.G.A.A.A.A.B(reflectiveOperationException);
            }
        }

        @Override
        public <T> Constructor<T> B(Class<T> clazz) {
            try {
                Object[] objectArray = (Object[])this.A.invoke(clazz, new Object[0]);
                Class[] classArray = new Class[objectArray.length];
                for (int i = 0; i < objectArray.length; ++i) {
                    classArray[i] = (Class)this.C.invoke(objectArray[i], new Object[0]);
                }
                return clazz.getDeclaredConstructor(classArray);
            } catch (ReflectiveOperationException reflectiveOperationException) {
                throw com.donutsmp.teams.G.A.A.A.A.B(reflectiveOperationException);
            }
        }

        @Override
        public Method A(Class<?> clazz, Field field) {
            try {
                return clazz.getMethod(field.getName(), new Class[0]);
            } catch (ReflectiveOperationException reflectiveOperationException) {
                throw com.donutsmp.teams.G.A.A.A.A.B(reflectiveOperationException);
            }
        }
    }

    private static abstract class _C {
        private _C() {
        }

        abstract boolean C(Class<?> var1);

        abstract String[] A(Class<?> var1);

        abstract <T> Constructor<T> B(Class<T> var1);

        public abstract Method A(Class<?> var1, Field var2);
    }
}

