/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A;

import com.donutsmp.teams.G.A.A.N$_A;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Properties;

public final class N$_B {
    static final Type[] A = new Type[0];

    private N$_B() {
        throw new UnsupportedOperationException();
    }

    public static ParameterizedType A(Type type, Type type2, Type ... typeArray) {
        return new _C(type, type2, typeArray);
    }

    public static GenericArrayType C(Type type) {
        return new _B(type);
    }

    public static WildcardType B(Type type) {
        Type[] typeArray = type instanceof WildcardType ? ((WildcardType)type).getUpperBounds() : new Type[]{type};
        return new _A(typeArray, A);
    }

    public static WildcardType D(Type type) {
        Type[] typeArray = type instanceof WildcardType ? ((WildcardType)type).getLowerBounds() : new Type[]{type};
        return new _A(new Type[]{Object.class}, typeArray);
    }

    public static Type H(Type type) {
        if (type instanceof Class) {
            Class clazz = (Class)type;
            return clazz.isArray() ? new _B(N$_B.H(clazz.getComponentType())) : clazz;
        }
        if (type instanceof ParameterizedType) {
            ParameterizedType parameterizedType = (ParameterizedType)type;
            return new _C(parameterizedType.getOwnerType(), parameterizedType.getRawType(), parameterizedType.getActualTypeArguments());
        }
        if (type instanceof GenericArrayType) {
            GenericArrayType genericArrayType = (GenericArrayType)type;
            return new _B(genericArrayType.getGenericComponentType());
        }
        if (type instanceof WildcardType) {
            WildcardType wildcardType = (WildcardType)type;
            return new _A(wildcardType.getUpperBounds(), wildcardType.getLowerBounds());
        }
        return type;
    }

    public static Class<?> G(Type type) {
        if (type instanceof Class) {
            return (Class)type;
        }
        if (type instanceof ParameterizedType) {
            ParameterizedType parameterizedType = (ParameterizedType)type;
            Type type2 = parameterizedType.getRawType();
            N$_A.A(type2 instanceof Class);
            return (Class)type2;
        }
        if (type instanceof GenericArrayType) {
            Type type3 = ((GenericArrayType)type).getGenericComponentType();
            return Array.newInstance(N$_B.G(type3), 0).getClass();
        }
        if (type instanceof TypeVariable) {
            return Object.class;
        }
        if (type instanceof WildcardType) {
            Type[] typeArray = ((WildcardType)type).getUpperBounds();
            assert (typeArray.length == 1);
            return N$_B.G(typeArray[0]);
        }
        String string = type == null ? "null" : type.getClass().getName();
        throw new IllegalArgumentException("Expected a Class, ParameterizedType, or GenericArrayType, but <" + type + "> is of type " + string);
    }

    private static boolean A(Object object, Object object2) {
        return Objects.equals(object, object2);
    }

    public static boolean A(Type type, Type type2) {
        if (type == type2) {
            return true;
        }
        if (type instanceof Class) {
            return type.equals(type2);
        }
        if (type instanceof ParameterizedType) {
            if (!(type2 instanceof ParameterizedType)) {
                return false;
            }
            ParameterizedType parameterizedType = (ParameterizedType)type;
            ParameterizedType parameterizedType2 = (ParameterizedType)type2;
            return N$_B.A((Object)parameterizedType.getOwnerType(), (Object)parameterizedType2.getOwnerType()) && parameterizedType.getRawType().equals(parameterizedType2.getRawType()) && Arrays.equals(parameterizedType.getActualTypeArguments(), parameterizedType2.getActualTypeArguments());
        }
        if (type instanceof GenericArrayType) {
            if (!(type2 instanceof GenericArrayType)) {
                return false;
            }
            GenericArrayType genericArrayType = (GenericArrayType)type;
            GenericArrayType genericArrayType2 = (GenericArrayType)type2;
            return N$_B.A(genericArrayType.getGenericComponentType(), genericArrayType2.getGenericComponentType());
        }
        if (type instanceof WildcardType) {
            if (!(type2 instanceof WildcardType)) {
                return false;
            }
            WildcardType wildcardType = (WildcardType)type;
            WildcardType wildcardType2 = (WildcardType)type2;
            return Arrays.equals(wildcardType.getUpperBounds(), wildcardType2.getUpperBounds()) && Arrays.equals(wildcardType.getLowerBounds(), wildcardType2.getLowerBounds());
        }
        if (type instanceof TypeVariable) {
            if (!(type2 instanceof TypeVariable)) {
                return false;
            }
            TypeVariable typeVariable = (TypeVariable)type;
            TypeVariable typeVariable2 = (TypeVariable)type2;
            return typeVariable.getGenericDeclaration() == typeVariable2.getGenericDeclaration() && typeVariable.getName().equals(typeVariable2.getName());
        }
        return false;
    }

    public static String E(Type type) {
        return type instanceof Class ? ((Class)type).getName() : type.toString();
    }

    private static Type A(Type type, Class<?> object, Class<?> clazz) {
        Object object2;
        if (clazz == object) {
            return type;
        }
        if (clazz.isInterface()) {
            object2 = ((Class)object).getInterfaces();
            int n = ((Class<?>[])object2).length;
            for (int i = 0; i < n; ++i) {
                if (object2[i] == clazz) {
                    return ((Class)object).getGenericInterfaces()[i];
                }
                if (!clazz.isAssignableFrom(object2[i])) continue;
                return N$_B.A(((Class)object).getGenericInterfaces()[i], object2[i], clazz);
            }
        }
        if (!((Class)object).isInterface()) {
            while (object != Object.class) {
                object2 = ((Class)object).getSuperclass();
                if (object2 == clazz) {
                    return ((Class)object).getGenericSuperclass();
                }
                if (clazz.isAssignableFrom((Class<?>)object2)) {
                    return N$_B.A(((Class)object).getGenericSuperclass(), object2, clazz);
                }
                object = object2;
            }
        }
        return clazz;
    }

    private static Type B(Type type, Class<?> clazz, Class<?> clazz2) {
        if (type instanceof WildcardType) {
            Type[] typeArray = ((WildcardType)type).getUpperBounds();
            assert (typeArray.length == 1);
            type = typeArray[0];
        }
        N$_A.A(clazz2.isAssignableFrom(clazz));
        return N$_B.A(type, clazz, N$_B.A(type, clazz, clazz2));
    }

    public static Type A(Type type) {
        return type instanceof GenericArrayType ? ((GenericArrayType)type).getGenericComponentType() : ((Class)type).getComponentType();
    }

    public static Type B(Type type, Class<?> clazz) {
        Type type2 = N$_B.B(type, clazz, Collection.class);
        if (type2 instanceof ParameterizedType) {
            return ((ParameterizedType)type2).getActualTypeArguments()[0];
        }
        return Object.class;
    }

    public static Type[] A(Type type, Class<?> clazz) {
        if (type == Properties.class) {
            return new Type[]{String.class, String.class};
        }
        Type type2 = N$_B.B(type, clazz, Map.class);
        if (type2 instanceof ParameterizedType) {
            ParameterizedType parameterizedType = (ParameterizedType)type2;
            return parameterizedType.getActualTypeArguments();
        }
        return new Type[]{Object.class, Object.class};
    }

    public static Type A(Type type, Class<?> clazz, Type type2) {
        return N$_B.A(type, clazz, type2, new HashMap());
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private static Type A(Type var0, Class<?> var1_1, Type var2_2, Map<TypeVariable<?>, Type> var3_3) {
        block8: {
            block12: {
                block11: {
                    block10: {
                        block9: {
                            var4_4 = null;
                            while (var2_2 /* !! */  instanceof TypeVariable) {
                                var5_5 = (TypeVariable)var2_2 /* !! */ ;
                                var6_6 /* !! */  = var3_3.get(var5_5);
                                if (var6_6 /* !! */  != null) {
                                    return var6_6 /* !! */  == Void.TYPE ? var2_2 /* !! */  : var6_6 /* !! */ ;
                                }
                                var3_3.put((TypeVariable<?>)var5_5, Void.TYPE);
                                if (var4_4 == null) {
                                    var4_4 = var5_5;
                                }
                                if ((var2_2 /* !! */  = N$_B.A(var0, var1_1, var5_5)) != var5_5) continue;
                                break block8;
                            }
                            if (!(var2_2 /* !! */  instanceof Class) || !((Class)var2_2 /* !! */ ).isArray()) break block9;
                            var5_5 = var2_2 /* !! */ ;
                            var6_6 /* !! */  = var5_5.getComponentType();
                            var2_2 /* !! */  = N$_B.A((Object)var6_6 /* !! */ , (Object)(var7_7 = N$_B.A(var0, var1_1, var6_6 /* !! */ , var3_3))) != false ? var5_5 : N$_B.C(var7_7);
                            break block8;
                        }
                        if (!(var2_2 /* !! */  instanceof GenericArrayType)) break block10;
                        var5_5 = (GenericArrayType)var2_2 /* !! */ ;
                        var6_6 /* !! */  = var5_5.getGenericComponentType();
                        var2_2 /* !! */  = N$_B.A((Object)var6_6 /* !! */ , (Object)(var7_8 = N$_B.A(var0, var1_1, var6_6 /* !! */ , var3_3))) != false ? var5_5 : N$_B.C(var7_8);
                        break block8;
                    }
                    if (!(var2_2 /* !! */  instanceof ParameterizedType)) break block11;
                    var5_5 = (ParameterizedType)var2_2 /* !! */ ;
                    var6_6 /* !! */  = var5_5.getOwnerType();
                    var7_9 = N$_B.A(var0, var1_1, var6_6 /* !! */ , var3_3);
                    var8_11 = N$_B.A((Object)var7_9, (Object)var6_6 /* !! */ ) == false;
                    var9_14 = var5_5.getActualTypeArguments();
                    var11_16 = var9_14.length;
                    for (var10_15 = 0; var10_15 < var11_16; ++var10_15) {
                        var12_17 = N$_B.A(var0, var1_1, var9_14[var10_15], var3_3);
                        if (N$_B.A((Object)var12_17, (Object)var9_14[var10_15])) continue;
                        if (!var8_11) {
                            var9_14 = (Type[])var9_14.clone();
                            var8_11 = true;
                        }
                        var9_14[var10_15] = var12_17;
                    }
                    var2_2 /* !! */  = var8_11 != false ? N$_B.A(var7_9, var5_5.getRawType(), var9_14) : var5_5;
                    break block8;
                }
                if (!(var2_2 /* !! */  instanceof WildcardType)) break block8;
                var5_5 = (WildcardType)var2_2 /* !! */ ;
                var6_6 /* !! */  = var5_5.getLowerBounds();
                var7_10 = var5_5.getUpperBounds();
                if (var6_6 /* !! */ .length != 1) break block12;
                var8_12 = N$_B.A(var0, var1_1, var6_6 /* !! */ [0], var3_3);
                if (var8_12 == var6_6 /* !! */ [0]) ** GOTO lbl-1000
                var2_2 /* !! */  = N$_B.D(var8_12);
                break block8;
            }
            if (var7_10.length == 1 && (var8_13 = N$_B.A(var0, var1_1, var7_10[0], var3_3)) != var7_10[0]) {
                var2_2 /* !! */  = N$_B.B(var8_13);
            } else lbl-1000:
            // 2 sources

            {
                var2_2 /* !! */  = var5_5;
            }
        }
        if (var4_4 != null) {
            var3_3.put((TypeVariable<?>)var4_4, var2_2 /* !! */ );
        }
        return var2_2 /* !! */ ;
    }

    private static Type A(Type type, Class<?> clazz, TypeVariable<?> typeVariable) {
        Class<?> clazz2 = N$_B.A(typeVariable);
        if (clazz2 == null) {
            return typeVariable;
        }
        Type type2 = N$_B.A(type, clazz, clazz2);
        if (type2 instanceof ParameterizedType) {
            int n = N$_B.A(clazz2.getTypeParameters(), typeVariable);
            return ((ParameterizedType)type2).getActualTypeArguments()[n];
        }
        return typeVariable;
    }

    private static int A(Object[] objectArray, Object object) {
        int n = objectArray.length;
        for (int i = 0; i < n; ++i) {
            if (!object.equals(objectArray[i])) continue;
            return i;
        }
        throw new NoSuchElementException();
    }

    private static Class<?> A(TypeVariable<?> typeVariable) {
        Object obj = typeVariable.getGenericDeclaration();
        return obj instanceof Class ? (Class)obj : null;
    }

    static void F(Type type) {
        N$_A.A(!(type instanceof Class) || !((Class)type).isPrimitive());
    }

    private static final class _A
    implements WildcardType,
    Serializable {
        private final Type A;
        private final Type B;
        private static final long C = 0L;

        public _A(Type[] typeArray, Type[] typeArray2) {
            N$_A.A(typeArray2.length <= 1);
            N$_A.A(typeArray.length == 1);
            if (typeArray2.length == 1) {
                Objects.requireNonNull(typeArray2[0]);
                N$_B.F(typeArray2[0]);
                N$_A.A(typeArray[0] == Object.class);
                this.B = N$_B.H(typeArray2[0]);
                this.A = Object.class;
            } else {
                Objects.requireNonNull(typeArray[0]);
                N$_B.F(typeArray[0]);
                this.B = null;
                this.A = N$_B.H(typeArray[0]);
            }
        }

        @Override
        public Type[] getUpperBounds() {
            return new Type[]{this.A};
        }

        @Override
        public Type[] getLowerBounds() {
            Type[] typeArray;
            if (this.B != null) {
                Type[] typeArray2 = new Type[1];
                typeArray = typeArray2;
                typeArray2[0] = this.B;
            } else {
                typeArray = A;
            }
            return typeArray;
        }

        public boolean equals(Object object) {
            return object instanceof WildcardType && N$_B.A((Type)this, (WildcardType)object);
        }

        public int hashCode() {
            return (this.B != null ? 31 + this.B.hashCode() : 1) ^ 31 + this.A.hashCode();
        }

        public String toString() {
            if (this.B != null) {
                return "? super " + N$_B.E(this.B);
            }
            if (this.A == Object.class) {
                return "?";
            }
            return "? extends " + N$_B.E(this.A);
        }
    }

    private static final class _B
    implements GenericArrayType,
    Serializable {
        private final Type A;
        private static final long B = 0L;

        public _B(Type type) {
            Objects.requireNonNull(type);
            this.A = N$_B.H(type);
        }

        @Override
        public Type getGenericComponentType() {
            return this.A;
        }

        public boolean equals(Object object) {
            return object instanceof GenericArrayType && N$_B.A((Type)this, (GenericArrayType)object);
        }

        public int hashCode() {
            return this.A.hashCode();
        }

        public String toString() {
            return N$_B.E(this.A) + "[]";
        }
    }

    private static final class _C
    implements ParameterizedType,
    Serializable {
        private final Type C;
        private final Type B;
        private final Type[] A;
        private static final long D = 0L;

        public _C(Type type, Type type2, Type ... typeArray) {
            int n;
            Objects.requireNonNull(type2);
            if (type2 instanceof Class) {
                Class clazz = (Class)type2;
                n = Modifier.isStatic(clazz.getModifiers()) || clazz.getEnclosingClass() == null ? 1 : 0;
                N$_A.A(type != null || n != 0);
            }
            this.C = type == null ? null : N$_B.H(type);
            this.B = N$_B.H(type2);
            this.A = (Type[])typeArray.clone();
            n = this.A.length;
            for (int i = 0; i < n; ++i) {
                Objects.requireNonNull(this.A[i]);
                N$_B.F(this.A[i]);
                this.A[i] = N$_B.H(this.A[i]);
            }
        }

        @Override
        public Type[] getActualTypeArguments() {
            return (Type[])this.A.clone();
        }

        @Override
        public Type getRawType() {
            return this.B;
        }

        @Override
        public Type getOwnerType() {
            return this.C;
        }

        public boolean equals(Object object) {
            return object instanceof ParameterizedType && N$_B.A((Type)this, (ParameterizedType)object);
        }

        private static int A(Object object) {
            return object != null ? object.hashCode() : 0;
        }

        public int hashCode() {
            return Arrays.hashCode(this.A) ^ this.B.hashCode() ^ _C.A(this.C);
        }

        public String toString() {
            int n = this.A.length;
            if (n == 0) {
                return N$_B.E(this.B);
            }
            StringBuilder stringBuilder = new StringBuilder(30 * (n + 1));
            stringBuilder.append(N$_B.E(this.B)).append("<").append(N$_B.E(this.A[0]));
            for (int i = 1; i < n; ++i) {
                stringBuilder.append(", ").append(N$_B.E(this.A[i]));
            }
            return stringBuilder.append(">").toString();
        }
    }
}

