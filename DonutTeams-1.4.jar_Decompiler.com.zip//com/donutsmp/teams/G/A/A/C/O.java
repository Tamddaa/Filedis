/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A.C;

import com.donutsmp.teams.G.A.A.A;
import com.donutsmp.teams.G.A.B;
import com.donutsmp.teams.G.A.D.C;
import com.donutsmp.teams.G.A.E;
import com.donutsmp.teams.G.A.M;
import com.donutsmp.teams.G.A.Q;
import com.donutsmp.teams.G.A.V;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class O
extends V<Object> {
    private static final B w = O.C(M.A);
    private final Q x;
    private final E y;

    private O(Q q, E e) {
        this.x = q;
        this.y = e;
    }

    private static B C(final E e) {
        return new B(){

            @Override
            public <T> V<T> A(Q q, com.donutsmp.teams.G.A.B.A<T> a) {
                if (a.C() == Object.class) {
                    return new O(q, e);
                }
                return null;
            }
        };
    }

    public static B D(E e) {
        if (e == M.A) {
            return w;
        }
        return O.C(e);
    }

    private Object C(com.donutsmp.teams.G.A.D.E e, com.donutsmp.teams.G.A.D.A a) throws IOException {
        switch (a) {
            case F: {
                e.H();
                return new ArrayList();
            }
            case J: {
                e.V();
                return new A();
            }
        }
        return null;
    }

    private Object D(com.donutsmp.teams.G.A.D.E e, com.donutsmp.teams.G.A.D.A a) throws IOException {
        switch (a) {
            case G: {
                return e.Y();
            }
            case B: {
                return this.y.A(e);
            }
            case C: {
                return e.C();
            }
            case E: {
                e.S();
                return null;
            }
        }
        throw new IllegalStateException("Unexpected token: " + (Object)((Object)a));
    }

    @Override
    public Object A(com.donutsmp.teams.G.A.D.E e) throws IOException {
        com.donutsmp.teams.G.A.D.A a = e.G();
        Object object = this.C(e, a);
        if (object == null) {
            return this.D(e, a);
        }
        ArrayDeque<Object> arrayDeque = new ArrayDeque<Object>();
        while (true) {
            if (e.A()) {
                Object object2;
                Object object3;
                boolean bl;
                String string = null;
                if (object instanceof Map) {
                    string = e.I();
                }
                boolean bl2 = bl = (object3 = this.C(e, a = e.G())) != null;
                if (object3 == null) {
                    object3 = this.D(e, a);
                }
                if (object instanceof List) {
                    object2 = (List)object;
                    object2.add(object3);
                } else {
                    object2 = (Map)object;
                    object2.put(string, object3);
                }
                if (!bl) continue;
                arrayDeque.addLast(object);
                object = object3;
                continue;
            }
            if (object instanceof List) {
                e._();
            } else {
                e.O();
            }
            if (arrayDeque.isEmpty()) {
                return object;
            }
            object = arrayDeque.removeLast();
        }
    }

    @Override
    public void A(C c, Object object) throws IOException {
        if (object == null) {
            c.C();
            return;
        }
        V<?> v = this.x.A(object.getClass());
        if (v instanceof O) {
            c.F();
            c.B();
            return;
        }
        v.A(c, object);
    }
}

