/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A.C;

import com.donutsmp.teams.G.A.A.C.D;
import com.donutsmp.teams.G.A.A.N$_B;
import com.donutsmp.teams.G.A.B;
import com.donutsmp.teams.G.A.D.A;
import com.donutsmp.teams.G.A.D.C;
import com.donutsmp.teams.G.A.D.E;
import com.donutsmp.teams.G.A.Q;
import com.donutsmp.teams.G.A.V;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Type;
import java.util.ArrayList;

public final class K<E>
extends V<Object> {
    public static final B g = new B(){

        @Override
        public <T> V<T> A(Q q, com.donutsmp.teams.G.A.B.A<T> a) {
            Type type = a.A();
            if (!(type instanceof GenericArrayType || type instanceof Class && ((Class)type).isArray())) {
                return null;
            }
            Type type2 = N$_B.A(type);
            V<?> v = q.A(com.donutsmp.teams.G.A.B.A.C(type2));
            K k = new K(q, v, N$_B.G(type2));
            return k;
        }
    };
    private final Class<E> f;
    private final V<E> e;

    public K(Q q, V<E> v, Class<E> clazz) {
        this.e = new D<E>(q, v, clazz);
        this.f = clazz;
    }

    @Override
    public Object A(E e) throws IOException {
        if (e.G() == A.E) {
            e.S();
            return null;
        }
        ArrayList<E> arrayList = new ArrayList<E>();
        e.H();
        while (e.A()) {
            E e2 = this.e.A(e);
            arrayList.add(e2);
        }
        e._();
        int n = arrayList.size();
        if (this.f.isPrimitive()) {
            Object object = Array.newInstance(this.f, n);
            for (int i = 0; i < n; ++i) {
                Array.set(object, i, arrayList.get(i));
            }
            return object;
        }
        Object[] objectArray = (Object[])Array.newInstance(this.f, n);
        return arrayList.toArray(objectArray);
    }

    @Override
    public void A(C c, Object object) throws IOException {
        if (object == null) {
            c.C();
            return;
        }
        c.D();
        int n = Array.getLength(object);
        for (int i = 0; i < n; ++i) {
            Object object2 = Array.get(object, i);
            this.e.A(c, object2);
        }
        c.H();
    }
}

