/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.A;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class B {
    public static DateFormat D(int n) {
        return new SimpleDateFormat(B.B(n), Locale.US);
    }

    public static DateFormat A(int n, int n2) {
        String string = B.A(n) + " " + B.C(n2);
        return new SimpleDateFormat(string, Locale.US);
    }

    private static String B(int n) {
        switch (n) {
            case 3: {
                return "M/d/yy";
            }
            case 2: {
                return "MMM d, y";
            }
            case 1: {
                return "MMMM d, y";
            }
            case 0: {
                return "EEEE, MMMM d, y";
            }
        }
        throw new IllegalArgumentException("Unknown DateFormat style: " + n);
    }

    private static String A(int n) {
        switch (n) {
            case 3: {
                return "M/d/yy";
            }
            case 2: {
                return "MMM d, yyyy";
            }
            case 1: {
                return "MMMM d, yyyy";
            }
            case 0: {
                return "EEEE, MMMM d, yyyy";
            }
        }
        throw new IllegalArgumentException("Unknown DateFormat style: " + n);
    }

    private static String C(int n) {
        switch (n) {
            case 3: {
                return "h:mm a";
            }
            case 2: {
                return "h:mm:ss a";
            }
            case 0: 
            case 1: {
                return "h:mm:ss a z";
            }
        }
        throw new IllegalArgumentException("Unknown DateFormat style: " + n);
    }
}

