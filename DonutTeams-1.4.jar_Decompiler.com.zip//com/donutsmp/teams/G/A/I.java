/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import com.donutsmp.teams.G.A.H;

public interface I {
    public boolean A(H var1);

    public boolean A(Class<?> var1);
}

