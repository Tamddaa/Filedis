/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import java.lang.reflect.Field;

public interface F {
    public String A(Field var1);
}

