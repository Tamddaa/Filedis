/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import com.donutsmp.teams.G.A.A.J;
import com.donutsmp.teams.G.A.D.D;
import com.donutsmp.teams.G.A.E;
import com.donutsmp.teams.G.A.T;
import java.io.IOException;
import java.math.BigDecimal;

public enum M implements E
{
    A{

        public Double C(com.donutsmp.teams.G.A.D.E e) throws IOException {
            return e.U();
        }
    }
    ,
    B{

        @Override
        public Number A(com.donutsmp.teams.G.A.D.E e) throws IOException {
            return new J(e.Y());
        }
    }
    ,
    E{

        @Override
        public Number A(com.donutsmp.teams.G.A.D.E e) throws IOException, T {
            String string = e.Y();
            try {
                return Long.parseLong(string);
            } catch (NumberFormatException numberFormatException) {
                try {
                    Double d = Double.valueOf(string);
                    if ((d.isInfinite() || d.isNaN()) && !e.F()) {
                        throw new D("JSON forbids NaN and infinities: " + d + "; at path " + e.Q());
                    }
                    return d;
                } catch (NumberFormatException numberFormatException2) {
                    throw new T("Cannot parse " + string + "; at path " + e.Q(), numberFormatException2);
                }
            }
        }
    }
    ,
    D{

        public BigDecimal B(com.donutsmp.teams.G.A.D.E e) throws IOException {
            String string = e.Y();
            try {
                return new BigDecimal(string);
            } catch (NumberFormatException numberFormatException) {
                throw new T("Cannot parse " + string + "; at path " + e.Q(), numberFormatException);
            }
        }
    };

}

