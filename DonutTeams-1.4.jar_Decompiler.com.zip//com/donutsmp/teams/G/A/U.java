/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import com.donutsmp.teams.G.A.P;

public final class U
extends P {
    public static final U B = new U();

    @Deprecated
    public U() {
    }

    public U a() {
        return B;
    }

    public int hashCode() {
        return U.class.hashCode();
    }

    public boolean equals(Object object) {
        return object instanceof U;
    }
}

