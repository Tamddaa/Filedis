/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.D;

import com.donutsmp.teams.G.A.A.C.J;
import com.donutsmp.teams.G.A.A.F;
import com.donutsmp.teams.G.A.D.A;
import com.donutsmp.teams.G.A.D.D;
import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;
import java.util.Arrays;
import java.util.Objects;

public class E
implements Closeable {
    private static final long H = -922337203685477580L;
    private static final int T = 0;
    private static final int P = 1;
    private static final int G = 2;
    private static final int J = 3;
    private static final int W = 4;
    private static final int I = 5;
    private static final int A = 6;
    private static final int L = 7;
    private static final int j = 8;
    private static final int X = 9;
    private static final int c = 10;
    private static final int g = 11;
    private static final int f = 12;
    private static final int U = 13;
    private static final int E = 14;
    private static final int e = 15;
    private static final int V = 16;
    private static final int C = 17;
    private static final int M = 0;
    private static final int K = 1;
    private static final int h = 2;
    private static final int k = 3;
    private static final int l = 4;
    private static final int _ = 5;
    private static final int B = 6;
    private static final int o = 7;
    private final Reader Y;
    private boolean b = false;
    static final int i = 1024;
    private final char[] O = new char[1024];
    private int a = 0;
    private int N = 0;
    private int S = 0;
    private int m = 0;
    int F = 0;
    private long Z;
    private int R;
    private String n;
    private int[] Q = new int[32];
    private int D = 0;
    private String[] p;
    private int[] d;

    public E(Reader reader) {
        this.Q[this.D++] = 6;
        this.p = new String[32];
        this.d = new int[32];
        this.Y = Objects.requireNonNull(reader, "in == null");
    }

    public final void B(boolean bl) {
        this.b = bl;
    }

    public final boolean F() {
        return this.b;
    }

    public void H() throws IOException {
        int n = this.F;
        if (n == 0) {
            n = this.E();
        }
        if (n != 3) {
            throw new IllegalStateException("Expected BEGIN_ARRAY but was " + (Object)((Object)this.G()) + this.M());
        }
        this.A(1);
        this.d[this.D - 1] = 0;
        this.F = 0;
    }

    public void _() throws IOException {
        int n = this.F;
        if (n == 0) {
            n = this.E();
        }
        if (n == 4) {
            --this.D;
        } else {
            throw new IllegalStateException("Expected END_ARRAY but was " + (Object)((Object)this.G()) + this.M());
        }
        int n2 = this.D - 1;
        this.d[n2] = this.d[n2] + 1;
        this.F = 0;
    }

    public void V() throws IOException {
        int n = this.F;
        if (n == 0) {
            n = this.E();
        }
        if (n != 1) {
            throw new IllegalStateException("Expected BEGIN_OBJECT but was " + (Object)((Object)this.G()) + this.M());
        }
        this.A(3);
        this.F = 0;
    }

    public void O() throws IOException {
        int n = this.F;
        if (n == 0) {
            n = this.E();
        }
        if (n == 2) {
            --this.D;
        } else {
            throw new IllegalStateException("Expected END_OBJECT but was " + (Object)((Object)this.G()) + this.M());
        }
        this.p[this.D] = null;
        int n2 = this.D - 1;
        this.d[n2] = this.d[n2] + 1;
        this.F = 0;
    }

    public boolean A() throws IOException {
        int n = this.F;
        if (n == 0) {
            n = this.E();
        }
        return n != 2 && n != 4 && n != 17;
    }

    public A G() throws IOException {
        int n = this.F;
        if (n == 0) {
            n = this.E();
        }
        switch (n) {
            case 1: {
                return com.donutsmp.teams.G.A.D.A.J;
            }
            case 2: {
                return com.donutsmp.teams.G.A.D.A.I;
            }
            case 3: {
                return com.donutsmp.teams.G.A.D.A.F;
            }
            case 4: {
                return com.donutsmp.teams.G.A.D.A.A;
            }
            case 12: 
            case 13: 
            case 14: {
                return com.donutsmp.teams.G.A.D.A.K;
            }
            case 5: 
            case 6: {
                return com.donutsmp.teams.G.A.D.A.C;
            }
            case 7: {
                return com.donutsmp.teams.G.A.D.A.E;
            }
            case 8: 
            case 9: 
            case 10: 
            case 11: {
                return com.donutsmp.teams.G.A.D.A.G;
            }
            case 15: 
            case 16: {
                return com.donutsmp.teams.G.A.D.A.B;
            }
            case 17: {
                return com.donutsmp.teams.G.A.D.A.H;
            }
        }
        throw new AssertionError();
    }

    int E() throws IOException {
        int n;
        int n2;
        block45: {
            block47: {
                block46: {
                    block44: {
                        n2 = this.Q[this.D - 1];
                        if (n2 != 1) break block44;
                        this.Q[this.D - 1] = 2;
                        break block45;
                    }
                    if (n2 != 2) break block46;
                    n = this.C(true);
                    switch (n) {
                        case 93: {
                            this.F = 4;
                            return 4;
                        }
                        case 59: {
                            this.T();
                        }
                        case 44: {
                            break;
                        }
                        default: {
                            throw this.A("Unterminated array");
                        }
                    }
                    break block45;
                }
                if (n2 == 3 || n2 == 5) {
                    int n3;
                    this.Q[this.D - 1] = 4;
                    if (n2 == 5) {
                        n3 = this.C(true);
                        switch (n3) {
                            case 125: {
                                this.F = 2;
                                return 2;
                            }
                            case 59: {
                                this.T();
                            }
                            case 44: {
                                break;
                            }
                            default: {
                                throw this.A("Unterminated object");
                            }
                        }
                    }
                    n3 = this.C(true);
                    switch (n3) {
                        case 34: {
                            this.F = 13;
                            return 13;
                        }
                        case 39: {
                            this.T();
                            this.F = 12;
                            return 12;
                        }
                        case 125: {
                            if (n2 != 5) {
                                this.F = 2;
                                return 2;
                            }
                            throw this.A("Expected name");
                        }
                    }
                    this.T();
                    --this.a;
                    if (this.A((char)n3)) {
                        this.F = 14;
                        return 14;
                    }
                    throw this.A("Expected name");
                }
                if (n2 != 4) break block47;
                this.Q[this.D - 1] = 5;
                n = this.C(true);
                switch (n) {
                    case 58: {
                        break;
                    }
                    case 61: {
                        this.T();
                        if ((this.a < this.N || this.B(1)) && this.O[this.a] == '>') {
                            ++this.a;
                            break;
                        }
                        break block45;
                    }
                    default: {
                        throw this.A("Expected ':'");
                    }
                }
                break block45;
            }
            if (n2 == 6) {
                if (this.b) {
                    this.R();
                }
                this.Q[this.D - 1] = 7;
            } else if (n2 == 7) {
                n = this.C(false);
                if (n == -1) {
                    this.F = 17;
                    return 17;
                }
                this.T();
                --this.a;
            } else if (n2 == 8) {
                throw new IllegalStateException("JsonReader is closed");
            }
        }
        n = this.C(true);
        switch (n) {
            case 93: {
                if (n2 == 1) {
                    this.F = 4;
                    return 4;
                }
            }
            case 44: 
            case 59: {
                if (n2 == 1 || n2 == 2) {
                    this.T();
                    --this.a;
                    this.F = 7;
                    return 7;
                }
                throw this.A("Unexpected value");
            }
            case 39: {
                this.T();
                this.F = 8;
                return 8;
            }
            case 34: {
                this.F = 9;
                return 9;
            }
            case 91: {
                this.F = 3;
                return 3;
            }
            case 123: {
                this.F = 1;
                return 1;
            }
        }
        --this.a;
        int n4 = this.L();
        if (n4 != 0) {
            return n4;
        }
        n4 = this.W();
        if (n4 != 0) {
            return n4;
        }
        if (!this.A(this.O[this.a])) {
            throw this.A("Expected value");
        }
        this.T();
        this.F = 10;
        return 10;
    }

    private int L() throws IOException {
        int n;
        String string;
        String string2;
        char c = this.O[this.a];
        if (c == 't' || c == 'T') {
            string2 = "true";
            string = "TRUE";
            n = 5;
        } else if (c == 'f' || c == 'F') {
            string2 = "false";
            string = "FALSE";
            n = 6;
        } else if (c == 'n' || c == 'N') {
            string2 = "null";
            string = "NULL";
            n = 7;
        } else {
            return 0;
        }
        int n2 = string2.length();
        for (int i = 1; i < n2; ++i) {
            if (this.a + i >= this.N && !this.B(i + 1)) {
                return 0;
            }
            c = this.O[this.a + i];
            if (c == string2.charAt(i) || c == string.charAt(i)) continue;
            return 0;
        }
        if ((this.a + n2 < this.N || this.B(n2 + 1)) && this.A(this.O[this.a + n2])) {
            return 0;
        }
        this.a += n2;
        this.F = n;
        return this.F;
    }

    private int W() throws IOException {
        char[] cArray = this.O;
        int n = this.a;
        int n2 = this.N;
        long l = 0L;
        boolean bl = false;
        boolean bl2 = true;
        int n3 = 0;
        int n4 = 0;
        block6: while (true) {
            if (n + n4 == n2) {
                if (n4 == cArray.length) {
                    return 0;
                }
                if (!this.B(n4 + 1)) break;
                n = this.a;
                n2 = this.N;
            }
            char c = cArray[n + n4];
            switch (c) {
                case '-': {
                    if (n3 == 0) {
                        bl = true;
                        n3 = 1;
                        break;
                    }
                    if (n3 == 5) {
                        n3 = 6;
                        break;
                    }
                    return 0;
                }
                case '+': {
                    if (n3 == 5) {
                        n3 = 6;
                        break;
                    }
                    return 0;
                }
                case 'E': 
                case 'e': {
                    if (n3 == 2 || n3 == 4) {
                        n3 = 5;
                        break;
                    }
                    return 0;
                }
                case '.': {
                    if (n3 == 2) {
                        n3 = 3;
                        break;
                    }
                    return 0;
                }
                default: {
                    if (c < '0' || c > '9') {
                        if (!this.A(c)) break block6;
                        return 0;
                    }
                    if (n3 == 1 || n3 == 0) {
                        l = -(c - 48);
                        n3 = 2;
                        break;
                    }
                    if (n3 == 2) {
                        if (l == 0L) {
                            return 0;
                        }
                        long l2 = l * 10L - (long)(c - 48);
                        bl2 &= l > -922337203685477580L || l == -922337203685477580L && l2 < l;
                        l = l2;
                        break;
                    }
                    if (n3 == 3) {
                        n3 = 4;
                        break;
                    }
                    if (n3 != 5 && n3 != 6) break;
                    n3 = 7;
                }
            }
            ++n4;
        }
        if (!(n3 != 2 || !bl2 || l == Long.MIN_VALUE && !bl || l == 0L && bl)) {
            this.Z = bl ? l : -l;
            this.a += n4;
            this.F = 15;
            return 15;
        }
        if (n3 == 2 || n3 == 4 || n3 == 7) {
            this.R = n4;
            this.F = 16;
            return 16;
        }
        return 0;
    }

    private boolean A(char c) throws IOException {
        switch (c) {
            case '#': 
            case '/': 
            case ';': 
            case '=': 
            case '\\': {
                this.T();
            }
            case '\t': 
            case '\n': 
            case '\f': 
            case '\r': 
            case ' ': 
            case ',': 
            case ':': 
            case '[': 
            case ']': 
            case '{': 
            case '}': {
                return false;
            }
        }
        return true;
    }

    public String I() throws IOException {
        String string;
        int n = this.F;
        if (n == 0) {
            n = this.E();
        }
        if (n == 14) {
            string = this.K();
        } else if (n == 12) {
            string = this.B('\'');
        } else if (n == 13) {
            string = this.B('\"');
        } else {
            throw new IllegalStateException("Expected a name but was " + (Object)((Object)this.G()) + this.M());
        }
        this.F = 0;
        this.p[this.D - 1] = string;
        return string;
    }

    public String Y() throws IOException {
        String string;
        int n = this.F;
        if (n == 0) {
            n = this.E();
        }
        if (n == 10) {
            string = this.K();
        } else if (n == 8) {
            string = this.B('\'');
        } else if (n == 9) {
            string = this.B('\"');
        } else if (n == 11) {
            string = this.n;
            this.n = null;
        } else if (n == 15) {
            string = Long.toString(this.Z);
        } else if (n == 16) {
            string = new String(this.O, this.a, this.R);
            this.a += this.R;
        } else {
            throw new IllegalStateException("Expected a string but was " + (Object)((Object)this.G()) + this.M());
        }
        this.F = 0;
        int n2 = this.D - 1;
        this.d[n2] = this.d[n2] + 1;
        return string;
    }

    public boolean C() throws IOException {
        int n = this.F;
        if (n == 0) {
            n = this.E();
        }
        if (n == 5) {
            this.F = 0;
            int n2 = this.D - 1;
            this.d[n2] = this.d[n2] + 1;
            return true;
        }
        if (n == 6) {
            this.F = 0;
            int n3 = this.D - 1;
            this.d[n3] = this.d[n3] + 1;
            return false;
        }
        throw new IllegalStateException("Expected a boolean but was " + (Object)((Object)this.G()) + this.M());
    }

    public void S() throws IOException {
        int n = this.F;
        if (n == 0) {
            n = this.E();
        }
        if (n != 7) {
            throw new IllegalStateException("Expected null but was " + (Object)((Object)this.G()) + this.M());
        }
        this.F = 0;
        int n2 = this.D - 1;
        this.d[n2] = this.d[n2] + 1;
    }

    public double U() throws IOException {
        int n = this.F;
        if (n == 0) {
            n = this.E();
        }
        if (n == 15) {
            this.F = 0;
            int n2 = this.D - 1;
            this.d[n2] = this.d[n2] + 1;
            return this.Z;
        }
        if (n == 16) {
            this.n = new String(this.O, this.a, this.R);
            this.a += this.R;
        } else if (n == 8 || n == 9) {
            this.n = this.B(n == 8 ? (char)'\'' : '\"');
        } else if (n == 10) {
            this.n = this.K();
        } else if (n != 11) {
            throw new IllegalStateException("Expected a double but was " + (Object)((Object)this.G()) + this.M());
        }
        this.F = 11;
        double d = Double.parseDouble(this.n);
        if (!this.b && (Double.isNaN(d) || Double.isInfinite(d))) {
            throw new D("JSON forbids NaN and infinities: " + d + this.M());
        }
        this.n = null;
        this.F = 0;
        int n3 = this.D - 1;
        this.d[n3] = this.d[n3] + 1;
        return d;
    }

    public long B() throws IOException {
        int n = this.F;
        if (n == 0) {
            n = this.E();
        }
        if (n == 15) {
            this.F = 0;
            int n2 = this.D - 1;
            this.d[n2] = this.d[n2] + 1;
            return this.Z;
        }
        if (n == 16) {
            this.n = new String(this.O, this.a, this.R);
            this.a += this.R;
        } else if (n == 8 || n == 9 || n == 10) {
            this.n = n == 10 ? this.K() : this.B(n == 8 ? (char)'\'' : '\"');
            try {
                long l = Long.parseLong(this.n);
                this.F = 0;
                int n3 = this.D - 1;
                this.d[n3] = this.d[n3] + 1;
                return l;
            } catch (NumberFormatException numberFormatException) {}
        } else {
            throw new IllegalStateException("Expected a long but was " + (Object)((Object)this.G()) + this.M());
        }
        this.F = 11;
        double d = Double.parseDouble(this.n);
        long l = (long)d;
        if ((double)l != d) {
            throw new NumberFormatException("Expected a long but was " + this.n + this.M());
        }
        this.n = null;
        this.F = 0;
        int n4 = this.D - 1;
        this.d[n4] = this.d[n4] + 1;
        return l;
    }

    private String B(char c) throws IOException {
        char[] cArray = this.O;
        StringBuilder stringBuilder = null;
        do {
            int n;
            int n2 = this.a;
            int n3 = this.N;
            int n4 = n2;
            while (n2 < n3) {
                int n5;
                if ((n = cArray[n2++]) == c) {
                    this.a = n2;
                    n5 = n2 - n4 - 1;
                    if (stringBuilder == null) {
                        return new String(cArray, n4, n5);
                    }
                    stringBuilder.append(cArray, n4, n5);
                    return stringBuilder.toString();
                }
                if (n == 92) {
                    this.a = n2;
                    n5 = n2 - n4 - 1;
                    if (stringBuilder == null) {
                        int n6 = (n5 + 1) * 2;
                        stringBuilder = new StringBuilder(Math.max(n6, 16));
                    }
                    stringBuilder.append(cArray, n4, n5);
                    stringBuilder.append(this.D());
                    n2 = this.a;
                    n3 = this.N;
                    n4 = n2;
                    continue;
                }
                if (n != 10) continue;
                ++this.S;
                this.m = n2;
            }
            if (stringBuilder == null) {
                n = (n2 - n4) * 2;
                stringBuilder = new StringBuilder(Math.max(n, 16));
            }
            stringBuilder.append(cArray, n4, n2 - n4);
            this.a = n2;
        } while (this.B(1));
        throw this.A("Unterminated string");
    }

    private String K() throws IOException {
        StringBuilder stringBuilder = null;
        int n = 0;
        block4: while (true) {
            if (this.a + n < this.N) {
                switch (this.O[this.a + n]) {
                    case '#': 
                    case '/': 
                    case ';': 
                    case '=': 
                    case '\\': {
                        this.T();
                    }
                    case '\t': 
                    case '\n': 
                    case '\f': 
                    case '\r': 
                    case ' ': 
                    case ',': 
                    case ':': 
                    case '[': 
                    case ']': 
                    case '{': 
                    case '}': {
                        break block4;
                    }
                    default: {
                        ++n;
                        break;
                    }
                }
                continue;
            }
            if (n < this.O.length) {
                if (!this.B(n + 1)) break;
                continue;
            }
            if (stringBuilder == null) {
                stringBuilder = new StringBuilder(Math.max(n, 16));
            }
            stringBuilder.append(this.O, this.a, n);
            this.a += n;
            n = 0;
            if (!this.B(1)) break;
        }
        String string = null == stringBuilder ? new String(this.O, this.a, n) : stringBuilder.append(this.O, this.a, n).toString();
        this.a += n;
        return string;
    }

    private void C(char c) throws IOException {
        char[] cArray = this.O;
        do {
            int n = this.a;
            int n2 = this.N;
            while (n < n2) {
                char c2;
                if ((c2 = cArray[n++]) == c) {
                    this.a = n;
                    return;
                }
                if (c2 == '\\') {
                    this.a = n;
                    this.D();
                    n = this.a;
                    n2 = this.N;
                    continue;
                }
                if (c2 != '\n') continue;
                ++this.S;
                this.m = n;
            }
            this.a = n;
        } while (this.B(1));
        throw this.A("Unterminated string");
    }

    private void X() throws IOException {
        do {
            int n = 0;
            while (this.a + n < this.N) {
                switch (this.O[this.a + n]) {
                    case '#': 
                    case '/': 
                    case ';': 
                    case '=': 
                    case '\\': {
                        this.T();
                    }
                    case '\t': 
                    case '\n': 
                    case '\f': 
                    case '\r': 
                    case ' ': 
                    case ',': 
                    case ':': 
                    case '[': 
                    case ']': 
                    case '{': 
                    case '}': {
                        this.a += n;
                        return;
                    }
                }
                ++n;
            }
            this.a += n;
        } while (this.B(1));
    }

    public int Z() throws IOException {
        int n = this.F;
        if (n == 0) {
            n = this.E();
        }
        if (n == 15) {
            int n2 = (int)this.Z;
            if (this.Z != (long)n2) {
                throw new NumberFormatException("Expected an int but was " + this.Z + this.M());
            }
            this.F = 0;
            int n3 = this.D - 1;
            this.d[n3] = this.d[n3] + 1;
            return n2;
        }
        if (n == 16) {
            this.n = new String(this.O, this.a, this.R);
            this.a += this.R;
        } else if (n == 8 || n == 9 || n == 10) {
            this.n = n == 10 ? this.K() : this.B(n == 8 ? (char)'\'' : '\"');
            try {
                int n4 = Integer.parseInt(this.n);
                this.F = 0;
                int n5 = this.D - 1;
                this.d[n5] = this.d[n5] + 1;
                return n4;
            } catch (NumberFormatException numberFormatException) {}
        } else {
            throw new IllegalStateException("Expected an int but was " + (Object)((Object)this.G()) + this.M());
        }
        this.F = 11;
        double d = Double.parseDouble(this.n);
        int n6 = (int)d;
        if ((double)n6 != d) {
            throw new NumberFormatException("Expected an int but was " + this.n + this.M());
        }
        this.n = null;
        this.F = 0;
        int n7 = this.D - 1;
        this.d[n7] = this.d[n7] + 1;
        return n6;
    }

    @Override
    public void close() throws IOException {
        this.F = 0;
        this.Q[0] = 8;
        this.D = 1;
        this.Y.close();
    }

    public void N() throws IOException {
        int n = 0;
        do {
            int n2;
            if ((n2 = this.F) == 0) {
                n2 = this.E();
            }
            switch (n2) {
                case 3: {
                    this.A(1);
                    ++n;
                    break;
                }
                case 1: {
                    this.A(3);
                    ++n;
                    break;
                }
                case 4: {
                    --this.D;
                    --n;
                    break;
                }
                case 2: {
                    if (n == 0) {
                        this.p[this.D - 1] = null;
                    }
                    --this.D;
                    --n;
                    break;
                }
                case 10: {
                    this.X();
                    break;
                }
                case 8: {
                    this.C('\'');
                    break;
                }
                case 9: {
                    this.C('\"');
                    break;
                }
                case 14: {
                    this.X();
                    if (n != 0) break;
                    this.p[this.D - 1] = "<skipped>";
                    break;
                }
                case 12: {
                    this.C('\'');
                    if (n != 0) break;
                    this.p[this.D - 1] = "<skipped>";
                    break;
                }
                case 13: {
                    this.C('\"');
                    if (n != 0) break;
                    this.p[this.D - 1] = "<skipped>";
                    break;
                }
                case 16: {
                    this.a += this.R;
                    break;
                }
                case 17: {
                    return;
                }
            }
            this.F = 0;
        } while (n > 0);
        int n3 = this.D - 1;
        this.d[n3] = this.d[n3] + 1;
    }

    private void A(int n) {
        if (this.D == this.Q.length) {
            int n2 = this.D * 2;
            this.Q = Arrays.copyOf(this.Q, n2);
            this.d = Arrays.copyOf(this.d, n2);
            this.p = Arrays.copyOf(this.p, n2);
        }
        this.Q[this.D++] = n;
    }

    private boolean B(int n) throws IOException {
        int n2;
        char[] cArray = this.O;
        this.m -= this.a;
        if (this.N != this.a) {
            this.N -= this.a;
            System.arraycopy(cArray, this.a, cArray, 0, this.N);
        } else {
            this.N = 0;
        }
        this.a = 0;
        while ((n2 = this.Y.read(cArray, this.N, cArray.length - this.N)) != -1) {
            this.N += n2;
            if (this.S == 0 && this.m == 0 && this.N > 0 && cArray[0] == '\ufeff') {
                ++this.a;
                ++this.m;
                ++n;
            }
            if (this.N < n) continue;
            return true;
        }
        return false;
    }

    private int C(boolean bl) throws IOException {
        block12: {
            char c;
            char[] cArray = this.O;
            int n = this.a;
            int n2 = this.N;
            block4: while (true) {
                if (n == n2) {
                    this.a = n;
                    if (!this.B(1)) break block12;
                    n = this.a;
                    n2 = this.N;
                }
                if ((c = cArray[n++]) == '\n') {
                    ++this.S;
                    this.m = n;
                    continue;
                }
                if (c == ' ' || c == '\r' || c == '\t') continue;
                if (c == '/') {
                    char c2;
                    this.a = n;
                    if (n == n2) {
                        --this.a;
                        c2 = (char)(this.B(2) ? 1 : 0);
                        ++this.a;
                        if (c2 == '\u0000') {
                            return c;
                        }
                    }
                    this.T();
                    c2 = cArray[this.a];
                    switch (c2) {
                        case '*': {
                            ++this.a;
                            if (!this.B("*/")) {
                                throw this.A("Unterminated comment");
                            }
                            n = this.a + 2;
                            n2 = this.N;
                            continue block4;
                        }
                        case '/': {
                            ++this.a;
                            this.P();
                            n = this.a;
                            n2 = this.N;
                            continue block4;
                        }
                    }
                    return c;
                }
                if (c != '#') break;
                this.a = n;
                this.T();
                this.P();
                n = this.a;
                n2 = this.N;
            }
            this.a = n;
            return c;
        }
        if (bl) {
            throw new EOFException("End of input" + this.M());
        }
        return -1;
    }

    private void T() throws IOException {
        if (!this.b) {
            throw this.A("Use JsonReader.setLenient(true) to accept malformed JSON");
        }
    }

    private void P() throws IOException {
        while (this.a < this.N || this.B(1)) {
            char c;
            if ((c = this.O[this.a++]) == '\n') {
                ++this.S;
                this.m = this.a;
                break;
            }
            if (c != '\r') continue;
            break;
        }
    }

    private boolean B(String string) throws IOException {
        int n = string.length();
        while (this.a + n <= this.N || this.B(n)) {
            block5: {
                if (this.O[this.a] == '\n') {
                    ++this.S;
                    this.m = this.a + 1;
                } else {
                    for (int i = 0; i < n; ++i) {
                        if (this.O[this.a + i] == string.charAt(i)) {
                            continue;
                        }
                        break block5;
                    }
                    return true;
                }
            }
            ++this.a;
        }
        return false;
    }

    public String toString() {
        return this.getClass().getSimpleName() + this.M();
    }

    String M() {
        int n = this.S + 1;
        int n2 = this.a - this.m + 1;
        return " at line " + n + " column " + n2 + " path " + this.J();
    }

    private String A(boolean bl) {
        StringBuilder stringBuilder = new StringBuilder().append('$');
        block4: for (int i = 0; i < this.D; ++i) {
            switch (this.Q[i]) {
                case 1: 
                case 2: {
                    int n = this.d[i];
                    if (bl && n > 0 && i == this.D - 1) {
                        --n;
                    }
                    stringBuilder.append('[').append(n).append(']');
                    continue block4;
                }
                case 3: 
                case 4: 
                case 5: {
                    stringBuilder.append('.');
                    if (this.p[i] == null) continue block4;
                    stringBuilder.append(this.p[i]);
                    continue block4;
                }
            }
        }
        return stringBuilder.toString();
    }

    public String Q() {
        return this.A(true);
    }

    public String J() {
        return this.A(false);
    }

    private char D() throws IOException {
        if (this.a == this.N && !this.B(1)) {
            throw this.A("Unterminated escape sequence");
        }
        char c = this.O[this.a++];
        switch (c) {
            case 'u': {
                int n;
                if (this.a + 4 > this.N && !this.B(4)) {
                    throw this.A("Unterminated escape sequence");
                }
                char c2 = '\u0000';
                int n2 = n + 4;
                for (n = this.a; n < n2; ++n) {
                    char c3 = this.O[n];
                    c2 = (char)(c2 << 4);
                    if (c3 >= '0' && c3 <= '9') {
                        c2 = (char)(c2 + (c3 - 48));
                        continue;
                    }
                    if (c3 >= 'a' && c3 <= 'f') {
                        c2 = (char)(c2 + (c3 - 97 + 10));
                        continue;
                    }
                    if (c3 >= 'A' && c3 <= 'F') {
                        c2 = (char)(c2 + (c3 - 65 + 10));
                        continue;
                    }
                    throw new NumberFormatException("\\u" + new String(this.O, this.a, 4));
                }
                this.a += 4;
                return c2;
            }
            case 't': {
                return '\t';
            }
            case 'b': {
                return '\b';
            }
            case 'n': {
                return '\n';
            }
            case 'r': {
                return '\r';
            }
            case 'f': {
                return '\f';
            }
            case '\n': {
                ++this.S;
                this.m = this.a;
            }
            case '\"': 
            case '\'': 
            case '/': 
            case '\\': {
                return c;
            }
        }
        throw this.A("Invalid escape sequence");
    }

    private IOException A(String string) throws IOException {
        throw new D(string + this.M());
    }

    private void R() throws IOException {
        this.C(true);
        --this.a;
        if (this.a + 5 > this.N && !this.B(5)) {
            return;
        }
        char[] cArray = this.O;
        int n = this.a;
        if (cArray[n] != ')' || cArray[n + 1] != ']' || cArray[n + 2] != '}' || cArray[n + 3] != '\'' || cArray[n + 4] != '\n') {
            return;
        }
        this.a += 5;
    }

    static {
        com.donutsmp.teams.G.A.A.F.A = new F(){

            @Override
            public void A(E e) throws IOException {
                if (e instanceof J) {
                    ((J)e).b();
                    return;
                }
                int n = e.F;
                if (n == 0) {
                    n = e.E();
                }
                if (n == 13) {
                    e.F = 9;
                } else if (n == 12) {
                    e.F = 8;
                } else if (n == 14) {
                    e.F = 10;
                } else {
                    throw new IllegalStateException("Expected a name but was " + (Object)((Object)e.G()) + e.M());
                }
            }
        };
    }
}

