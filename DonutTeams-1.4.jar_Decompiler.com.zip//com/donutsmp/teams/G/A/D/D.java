/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.D;

import java.io.IOException;

public final class D
extends IOException {
    private static final long A = 1L;

    public D(String string) {
        super(string);
    }

    public D(String string, Throwable throwable) {
        super(string, throwable);
    }

    public D(Throwable throwable) {
        super(throwable);
    }
}

