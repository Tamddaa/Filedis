/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.D;

public enum A {
    F,
    A,
    J,
    I,
    K,
    G,
    B,
    C,
    E,
    H;

}

