/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.D;

final class B {
    static final int B = 1;
    static final int C = 2;
    static final int D = 3;
    static final int F = 4;
    static final int A = 5;
    static final int H = 6;
    static final int E = 7;
    static final int G = 8;

    B() {
    }
}

