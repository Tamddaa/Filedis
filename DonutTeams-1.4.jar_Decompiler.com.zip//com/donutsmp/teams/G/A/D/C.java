/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.D;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.io.Writer;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Pattern;

public class C
implements Closeable,
Flushable {
    private static final Pattern E = Pattern.compile("-?(?:0|[1-9][0-9]*)(?:\\.[0-9]+)?(?:[eE][-+]?[0-9]+)?");
    private static final String[] H = new String[128];
    private static final String[] F;
    private final Writer C;
    private int[] I = new int[32];
    private int L = 0;
    private String A;
    private String D;
    private boolean B;
    private boolean J;
    private String K;
    private boolean G;

    public C(Writer writer) {
        this.B(6);
        this.D = ":";
        this.G = true;
        this.C = Objects.requireNonNull(writer, "out == null");
    }

    public final void C(String string) {
        if (string.length() == 0) {
            this.A = null;
            this.D = ":";
        } else {
            this.A = string;
            this.D = ": ";
        }
    }

    public final void C(boolean bl) {
        this.B = bl;
    }

    public boolean G() {
        return this.B;
    }

    public final void B(boolean bl) {
        this.J = bl;
    }

    public final boolean L() {
        return this.J;
    }

    public final void D(boolean bl) {
        this.G = bl;
    }

    public final boolean E() {
        return this.G;
    }

    public C D() throws IOException {
        this.J();
        return this.A(1, '[');
    }

    public C H() throws IOException {
        return this.A(1, 2, ']');
    }

    public C F() throws IOException {
        this.J();
        return this.A(3, '{');
    }

    public C B() throws IOException {
        return this.A(3, 5, '}');
    }

    private C A(int n, char c) throws IOException {
        this.I();
        this.B(n);
        this.C.write(c);
        return this;
    }

    private C A(int n, int n2, char c) throws IOException {
        int n3 = this.K();
        if (n3 != n2 && n3 != n) {
            throw new IllegalStateException("Nesting problem.");
        }
        if (this.K != null) {
            throw new IllegalStateException("Dangling name: " + this.K);
        }
        --this.L;
        if (n3 == n2) {
            this.A();
        }
        this.C.write(c);
        return this;
    }

    private void B(int n) {
        if (this.L == this.I.length) {
            this.I = Arrays.copyOf(this.I, this.L * 2);
        }
        this.I[this.L++] = n;
    }

    private int K() {
        if (this.L == 0) {
            throw new IllegalStateException("JsonWriter is closed.");
        }
        return this.I[this.L - 1];
    }

    private void A(int n) {
        this.I[this.L - 1] = n;
    }

    public C B(String string) throws IOException {
        Objects.requireNonNull(string, "name == null");
        if (this.K != null) {
            throw new IllegalStateException();
        }
        if (this.L == 0) {
            throw new IllegalStateException("JsonWriter is closed.");
        }
        this.K = string;
        return this;
    }

    private void J() throws IOException {
        if (this.K != null) {
            this.M();
            this.A(this.K);
            this.K = null;
        }
    }

    public C E(String string) throws IOException {
        if (string == null) {
            return this.C();
        }
        this.J();
        this.I();
        this.A(string);
        return this;
    }

    public C D(String string) throws IOException {
        if (string == null) {
            return this.C();
        }
        this.J();
        this.I();
        this.C.append(string);
        return this;
    }

    public C C() throws IOException {
        if (this.K != null) {
            if (this.G) {
                this.J();
            } else {
                this.K = null;
                return this;
            }
        }
        this.I();
        this.C.write("null");
        return this;
    }

    public C A(boolean bl) throws IOException {
        this.J();
        this.I();
        this.C.write(bl ? "true" : "false");
        return this;
    }

    public C A(Boolean bl) throws IOException {
        if (bl == null) {
            return this.C();
        }
        this.J();
        this.I();
        this.C.write(bl != false ? "true" : "false");
        return this;
    }

    public C A(float f) throws IOException {
        this.J();
        if (!this.B && (Float.isNaN(f) || Float.isInfinite(f))) {
            throw new IllegalArgumentException("Numeric values must be finite, but was " + f);
        }
        this.I();
        this.C.append(Float.toString(f));
        return this;
    }

    public C A(double d) throws IOException {
        this.J();
        if (!this.B && (Double.isNaN(d) || Double.isInfinite(d))) {
            throw new IllegalArgumentException("Numeric values must be finite, but was " + d);
        }
        this.I();
        this.C.append(Double.toString(d));
        return this;
    }

    public C A(long l) throws IOException {
        this.J();
        this.I();
        this.C.write(Long.toString(l));
        return this;
    }

    private static boolean A(Class<? extends Number> clazz) {
        return clazz == Integer.class || clazz == Long.class || clazz == Double.class || clazz == Float.class || clazz == Byte.class || clazz == Short.class || clazz == BigDecimal.class || clazz == BigInteger.class || clazz == AtomicInteger.class || clazz == AtomicLong.class;
    }

    public C A(Number number) throws IOException {
        if (number == null) {
            return this.C();
        }
        this.J();
        String string = number.toString();
        if (string.equals("-Infinity") || string.equals("Infinity") || string.equals("NaN")) {
            if (!this.B) {
                throw new IllegalArgumentException("Numeric values must be finite, but was " + string);
            }
        } else {
            Class<?> clazz = number.getClass();
            if (!com.donutsmp.teams.G.A.D.C.A(clazz) && !E.matcher(string).matches()) {
                throw new IllegalArgumentException("String created by " + clazz + " is not a valid JSON number: " + string);
            }
        }
        this.I();
        this.C.append(string);
        return this;
    }

    @Override
    public void flush() throws IOException {
        if (this.L == 0) {
            throw new IllegalStateException("JsonWriter is closed.");
        }
        this.C.flush();
    }

    @Override
    public void close() throws IOException {
        this.C.close();
        int n = this.L;
        if (n > 1 || n == 1 && this.I[n - 1] != 7) {
            throw new IOException("Incomplete document");
        }
        this.L = 0;
    }

    private void A(String string) throws IOException {
        String[] stringArray = this.J ? F : H;
        this.C.write(34);
        int n = 0;
        int n2 = string.length();
        for (int i = 0; i < n2; ++i) {
            String string2;
            char c = string.charAt(i);
            if (c < '\u0080') {
                string2 = stringArray[c];
                if (string2 == null) {
                    continue;
                }
            } else if (c == '\u2028') {
                string2 = "\\u2028";
            } else {
                if (c != '\u2029') continue;
                string2 = "\\u2029";
            }
            if (n < i) {
                this.C.write(string, n, i - n);
            }
            this.C.write(string2);
            n = i + 1;
        }
        if (n < n2) {
            this.C.write(string, n, n2 - n);
        }
        this.C.write(34);
    }

    private void A() throws IOException {
        if (this.A == null) {
            return;
        }
        this.C.write(10);
        int n = this.L;
        for (int i = 1; i < n; ++i) {
            this.C.write(this.A);
        }
    }

    private void M() throws IOException {
        int n = this.K();
        if (n == 5) {
            this.C.write(44);
        } else if (n != 3) {
            throw new IllegalStateException("Nesting problem.");
        }
        this.A();
        this.A(4);
    }

    private void I() throws IOException {
        switch (this.K()) {
            case 7: {
                if (!this.B) {
                    throw new IllegalStateException("JSON must have only one top-level value.");
                }
            }
            case 6: {
                this.A(7);
                break;
            }
            case 1: {
                this.A(2);
                this.A();
                break;
            }
            case 2: {
                this.C.append(',');
                this.A();
                break;
            }
            case 4: {
                this.C.append(this.D);
                this.A(5);
                break;
            }
            default: {
                throw new IllegalStateException("Nesting problem.");
            }
        }
    }

    static {
        for (int i = 0; i <= 31; ++i) {
            com.donutsmp.teams.G.A.D.C.H[i] = String.format("\\u%04x", i);
        }
        com.donutsmp.teams.G.A.D.C.H[34] = "\\\"";
        com.donutsmp.teams.G.A.D.C.H[92] = "\\\\";
        com.donutsmp.teams.G.A.D.C.H[9] = "\\t";
        com.donutsmp.teams.G.A.D.C.H[8] = "\\b";
        com.donutsmp.teams.G.A.D.C.H[10] = "\\n";
        com.donutsmp.teams.G.A.D.C.H[13] = "\\r";
        com.donutsmp.teams.G.A.D.C.H[12] = "\\f";
        F = (String[])H.clone();
        com.donutsmp.teams.G.A.D.C.F[60] = "\\u003c";
        com.donutsmp.teams.G.A.D.C.F[62] = "\\u003e";
        com.donutsmp.teams.G.A.D.C.F[38] = "\\u0026";
        com.donutsmp.teams.G.A.D.C.F[61] = "\\u003d";
        com.donutsmp.teams.G.A.D.C.F[39] = "\\u0027";
    }
}

