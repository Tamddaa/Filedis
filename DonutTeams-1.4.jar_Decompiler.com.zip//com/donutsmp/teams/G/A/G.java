/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import com.donutsmp.teams.G.A.A.J;
import com.donutsmp.teams.G.A.P;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Objects;

public final class G
extends P {
    private final Object D;

    public G(Boolean bl) {
        this.D = Objects.requireNonNull(bl);
    }

    public G(Number number) {
        this.D = Objects.requireNonNull(number);
    }

    public G(String string) {
        this.D = Objects.requireNonNull(string);
    }

    public G(Character c) {
        this.D = Objects.requireNonNull(c).toString();
    }

    public G j() {
        return this;
    }

    public boolean g() {
        return this.D instanceof Boolean;
    }

    @Override
    public boolean S() {
        if (this.g()) {
            return (Boolean)this.D;
        }
        return Boolean.parseBoolean(this.M());
    }

    public boolean i() {
        return this.D instanceof Number;
    }

    @Override
    public Number D() {
        if (this.D instanceof Number) {
            return (Number)this.D;
        }
        if (this.D instanceof String) {
            return new J((String)this.D);
        }
        throw new UnsupportedOperationException("Primitive is neither a number nor a string");
    }

    public boolean h() {
        return this.D instanceof String;
    }

    @Override
    public String M() {
        if (this.D instanceof String) {
            return (String)this.D;
        }
        if (this.i()) {
            return this.D().toString();
        }
        if (this.g()) {
            return ((Boolean)this.D).toString();
        }
        throw new AssertionError((Object)("Unexpected value type: " + this.D.getClass()));
    }

    @Override
    public double H() {
        return this.i() ? this.D().doubleValue() : Double.parseDouble(this.M());
    }

    @Override
    public BigDecimal O() {
        return this.D instanceof BigDecimal ? (BigDecimal)this.D : new BigDecimal(this.M());
    }

    @Override
    public BigInteger I() {
        return this.D instanceof BigInteger ? (BigInteger)this.D : new BigInteger(this.M());
    }

    @Override
    public float B() {
        return this.i() ? this.D().floatValue() : Float.parseFloat(this.M());
    }

    @Override
    public long F() {
        return this.i() ? this.D().longValue() : Long.parseLong(this.M());
    }

    @Override
    public short A() {
        return this.i() ? this.D().shortValue() : Short.parseShort(this.M());
    }

    @Override
    public int U() {
        return this.i() ? this.D().intValue() : Integer.parseInt(this.M());
    }

    @Override
    public byte R() {
        return this.i() ? this.D().byteValue() : Byte.parseByte(this.M());
    }

    @Override
    @Deprecated
    public char Q() {
        String string = this.M();
        if (string.isEmpty()) {
            throw new UnsupportedOperationException("String value is empty");
        }
        return string.charAt(0);
    }

    public int hashCode() {
        if (this.D == null) {
            return 31;
        }
        if (G.A(this)) {
            long l = this.D().longValue();
            return (int)(l ^ l >>> 32);
        }
        if (this.D instanceof Number) {
            long l = Double.doubleToLongBits(this.D().doubleValue());
            return (int)(l ^ l >>> 32);
        }
        return this.D.hashCode();
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || this.getClass() != object.getClass()) {
            return false;
        }
        G g = (G)object;
        if (this.D == null) {
            return g.D == null;
        }
        if (G.A(this) && G.A(g)) {
            return this.D().longValue() == g.D().longValue();
        }
        if (this.D instanceof Number && g.D instanceof Number) {
            double d;
            double d2 = this.D().doubleValue();
            return d2 == (d = g.D().doubleValue()) || Double.isNaN(d2) && Double.isNaN(d);
        }
        return this.D.equals(g.D);
    }

    private static boolean A(G g) {
        if (g.D instanceof Number) {
            Number number = (Number)g.D;
            return number instanceof BigInteger || number instanceof Long || number instanceof Integer || number instanceof Short || number instanceof Byte;
        }
        return false;
    }
}

