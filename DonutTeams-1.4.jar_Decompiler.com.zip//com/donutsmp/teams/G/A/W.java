/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import com.donutsmp.teams.G.A.A.M;

public interface W {
    public static final W B = new W(){

        @Override
        public _A A(Class<?> clazz) {
            return M.A(clazz) ? _A.A : _A.E;
        }
    };
    public static final W C = new W(){

        @Override
        public _A A(Class<?> clazz) {
            return M.A(clazz) ? _A.D : _A.E;
        }
    };
    public static final W A = new W(){

        @Override
        public _A A(Class<?> clazz) {
            return M.B(clazz) ? _A.D : _A.E;
        }
    };
    public static final W D = new W(){

        @Override
        public _A A(Class<?> clazz) {
            return M.C(clazz) ? _A.D : _A.E;
        }
    };

    public _A A(Class<?> var1);

    public static enum _A {
        C,
        E,
        A,
        D;

    }
}

