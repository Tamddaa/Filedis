/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import com.donutsmp.teams.G.A.A.C.A;
import com.donutsmp.teams.G.A.A.C.H;
import com.donutsmp.teams.G.A.A.K;
import com.donutsmp.teams.G.A.A.N$_A;
import com.donutsmp.teams.G.A.B;
import com.donutsmp.teams.G.A.B.A;
import com.donutsmp.teams.G.A.E;
import com.donutsmp.teams.G.A.F;
import com.donutsmp.teams.G.A.I;
import com.donutsmp.teams.G.A.J;
import com.donutsmp.teams.G.A.L;
import com.donutsmp.teams.G.A.N;
import com.donutsmp.teams.G.A.Q;
import com.donutsmp.teams.G.A.V;
import com.donutsmp.teams.G.A.W;
import com.donutsmp.teams.G.A.Z;
import com.donutsmp.teams.G.A._;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public final class C {
    private K H = com.donutsmp.teams.G.A.A.K.c;
    private Z R = Z.A;
    private F N = com.donutsmp.teams.G.A.J.A;
    private final Map<Type, _<?>> E = new HashMap();
    private final List<B> M = new ArrayList<B>();
    private final List<B> G = new ArrayList<B>();
    private boolean B = false;
    private String D = com.donutsmp.teams.G.A.Q.I;
    private int S = 2;
    private int O = 2;
    private boolean K = false;
    private boolean T = false;
    private boolean L = true;
    private boolean F = false;
    private boolean C = false;
    private boolean I = false;
    private boolean P = true;
    private E J = com.donutsmp.teams.G.A.Q.G;
    private E A = com.donutsmp.teams.G.A.Q.T;
    private final LinkedList<W> Q = new LinkedList();

    public C() {
    }

    C(Q q) {
        this.H = q.C;
        this.N = q.h;
        this.E.putAll(q.g);
        this.B = q.Z;
        this.K = q.B;
        this.C = q.d;
        this.L = q.a;
        this.F = q.X;
        this.I = q._;
        this.T = q.E;
        this.R = q.F;
        this.D = q.O;
        this.S = q.L;
        this.O = q.c;
        this.M.addAll(q.S);
        this.G.addAll(q.W);
        this.P = q.N;
        this.J = q.H;
        this.A = q.i;
        this.Q.addAll(q.k);
    }

    public C A(double d) {
        if (Double.isNaN(d) || d < 0.0) {
            throw new IllegalArgumentException("Invalid version: " + d);
        }
        this.H = this.H.A(d);
        return this;
    }

    public C A(int ... nArray) {
        Objects.requireNonNull(nArray);
        this.H = this.H.A(nArray);
        return this;
    }

    public C C() {
        this.C = true;
        return this;
    }

    public C D() {
        this.H = this.H.A();
        return this;
    }

    public C I() {
        this.B = true;
        return this;
    }

    public C G() {
        this.K = true;
        return this;
    }

    public C E() {
        this.H = this.H.C();
        return this;
    }

    public C A(Z z) {
        this.R = Objects.requireNonNull(z);
        return this;
    }

    public C A(J j) {
        return this.A((F)j);
    }

    public C A(F f) {
        this.N = Objects.requireNonNull(f);
        return this;
    }

    public C B(E e) {
        this.J = Objects.requireNonNull(e);
        return this;
    }

    public C A(E e) {
        this.A = Objects.requireNonNull(e);
        return this;
    }

    public C A(I ... iArray) {
        Objects.requireNonNull(iArray);
        for (I i : iArray) {
            this.H = this.H.A(i, true, true);
        }
        return this;
    }

    public C B(I i) {
        Objects.requireNonNull(i);
        this.H = this.H.A(i, true, false);
        return this;
    }

    public C A(I i) {
        Objects.requireNonNull(i);
        this.H = this.H.A(i, false, true);
        return this;
    }

    public C A() {
        this.F = true;
        return this;
    }

    public C K() {
        this.I = true;
        return this;
    }

    public C B() {
        this.L = false;
        return this;
    }

    public C A(String string) {
        this.D = string;
        return this;
    }

    public C A(int n) {
        this.S = n;
        this.D = null;
        return this;
    }

    public C A(int n, int n2) {
        this.S = n;
        this.O = n2;
        this.D = null;
        return this;
    }

    public C A(Type type, Object object) {
        Object object2;
        Objects.requireNonNull(type);
        N$_A.A(object instanceof L || object instanceof N || object instanceof _ || object instanceof V);
        if (object instanceof _) {
            this.E.put(type, (_)object);
        }
        if (object instanceof L || object instanceof N) {
            object2 = com.donutsmp.teams.G.A.B.A.C(type);
            this.M.add(com.donutsmp.teams.G.A.A.C.H.A(object2, object));
        }
        if (object instanceof V) {
            object2 = com.donutsmp.teams.G.A.A.C.L.A(com.donutsmp.teams.G.A.B.A.C(type), (V)object);
            this.M.add((B)object2);
        }
        return this;
    }

    public C A(B b) {
        Objects.requireNonNull(b);
        this.M.add(b);
        return this;
    }

    public C A(Class<?> clazz, Object object) {
        Objects.requireNonNull(clazz);
        N$_A.A(object instanceof L || object instanceof N || object instanceof V);
        if (object instanceof N || object instanceof L) {
            this.G.add(com.donutsmp.teams.G.A.A.C.H.A(clazz, object));
        }
        if (object instanceof V) {
            B b = com.donutsmp.teams.G.A.A.C.L.A(clazz, (V)object);
            this.M.add(b);
        }
        return this;
    }

    public C J() {
        this.T = true;
        return this;
    }

    public C H() {
        this.P = false;
        return this;
    }

    public C A(W w) {
        Objects.requireNonNull(w);
        this.Q.addFirst(w);
        return this;
    }

    public Q F() {
        ArrayList<B> arrayList = new ArrayList<B>(this.M.size() + this.G.size() + 3);
        arrayList.addAll(this.M);
        Collections.reverse(arrayList);
        ArrayList<B> arrayList2 = new ArrayList<B>(this.G);
        Collections.reverse(arrayList2);
        arrayList.addAll(arrayList2);
        this.A(this.D, this.S, this.O, arrayList);
        return new Q(this.H, this.N, new HashMap(this.E), this.B, this.K, this.C, this.L, this.F, this.I, this.T, this.P, this.R, this.D, this.S, this.O, new ArrayList<B>(this.M), new ArrayList<B>(this.G), arrayList, this.J, this.A, new ArrayList<W>(this.Q));
    }

    private void A(String string, int n, int n2, List<B> list) {
        B b;
        boolean bl = com.donutsmp.teams.G.A.A.B.C.E;
        B b2 = null;
        B b3 = null;
        if (string != null && !string.trim().isEmpty()) {
            b = A._A.B.A(string);
            if (bl) {
                b2 = com.donutsmp.teams.G.A.A.B.C.B.A(string);
                b3 = com.donutsmp.teams.G.A.A.B.C.F.A(string);
            }
        } else if (n != 2 && n2 != 2) {
            b = A._A.B.A(n, n2);
            if (bl) {
                b2 = com.donutsmp.teams.G.A.A.B.C.B.A(n, n2);
                b3 = com.donutsmp.teams.G.A.A.B.C.F.A(n, n2);
            }
        } else {
            return;
        }
        list.add(b);
        if (bl) {
            list.add(b2);
            list.add(b3);
        }
    }
}

