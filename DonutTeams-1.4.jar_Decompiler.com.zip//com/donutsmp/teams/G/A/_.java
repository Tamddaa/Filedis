/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import java.lang.reflect.Type;

public interface _<T> {
    public T A(Type var1);
}

