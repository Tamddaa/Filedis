/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.Collection;
import java.util.Objects;

public final class H {
    private final Field A;

    public H(Field field) {
        this.A = Objects.requireNonNull(field);
    }

    public Class<?> A() {
        return this.A.getDeclaringClass();
    }

    public String C() {
        return this.A.getName();
    }

    public Type E() {
        return this.A.getGenericType();
    }

    public Class<?> B() {
        return this.A.getType();
    }

    public <T extends Annotation> T A(Class<T> clazz) {
        return this.A.getAnnotation(clazz);
    }

    public Collection<Annotation> D() {
        return Arrays.asList(this.A.getAnnotations());
    }

    public boolean A(int n) {
        return (this.A.getModifiers() & n) != 0;
    }

    public String toString() {
        return this.A.toString();
    }
}

