/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A.B;

import com.donutsmp.teams.G.A.A.N$_B;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class A<T> {
    private final Class<? super T> C;
    private final Type B;
    private final int A;

    protected A() {
        this.B = this.B();
        this.C = N$_B.G(this.B);
        this.A = this.B.hashCode();
    }

    private A(Type type) {
        this.B = N$_B.H(Objects.requireNonNull(type));
        this.C = N$_B.G(this.B);
        this.A = this.B.hashCode();
    }

    private Type B() {
        Type type = this.getClass().getGenericSuperclass();
        if (type instanceof ParameterizedType) {
            ParameterizedType parameterizedType = (ParameterizedType)type;
            if (parameterizedType.getRawType() == A.class) {
                return N$_B.H(parameterizedType.getActualTypeArguments()[0]);
            }
        } else if (type == A.class) {
            throw new IllegalStateException("TypeToken must be created with a type argument: new TypeToken<...>() {}; When using code shrinkers (ProGuard, R8, ...) make sure that generic signatures are preserved.");
        }
        throw new IllegalStateException("Must only create direct subclasses of TypeToken");
    }

    public final Class<? super T> C() {
        return this.C;
    }

    public final Type A() {
        return this.B;
    }

    @Deprecated
    public boolean B(Class<?> clazz) {
        return this.A(clazz);
    }

    @Deprecated
    public boolean A(Type type) {
        if (type == null) {
            return false;
        }
        if (this.B.equals(type)) {
            return true;
        }
        if (this.B instanceof Class) {
            return this.C.isAssignableFrom(N$_B.G(type));
        }
        if (this.B instanceof ParameterizedType) {
            return com.donutsmp.teams.G.A.B.A.A(type, (ParameterizedType)this.B, new HashMap<String, Type>());
        }
        if (this.B instanceof GenericArrayType) {
            return this.C.isAssignableFrom(N$_B.G(type)) && com.donutsmp.teams.G.A.B.A.A(type, (GenericArrayType)this.B);
        }
        throw com.donutsmp.teams.G.A.B.A.A(this.B, Class.class, ParameterizedType.class, GenericArrayType.class);
    }

    @Deprecated
    public boolean A(A<?> a) {
        return this.A(a.A());
    }

    private static boolean A(Type type, GenericArrayType genericArrayType) {
        Type type2 = genericArrayType.getGenericComponentType();
        if (type2 instanceof ParameterizedType) {
            Type type3 = type;
            if (type instanceof GenericArrayType) {
                type3 = ((GenericArrayType)type).getGenericComponentType();
            } else if (type instanceof Class) {
                Class<?> clazz = (Class<?>)type;
                while (clazz.isArray()) {
                    clazz = clazz.getComponentType();
                }
                type3 = clazz;
            }
            return com.donutsmp.teams.G.A.B.A.A(type3, (ParameterizedType)type2, new HashMap<String, Type>());
        }
        return true;
    }

    private static boolean A(Type type, ParameterizedType parameterizedType, Map<String, Type> map) {
        if (type == null) {
            return false;
        }
        if (parameterizedType.equals(type)) {
            return true;
        }
        Class<?> clazz = N$_B.G(type);
        ParameterizedType parameterizedType2 = null;
        if (type instanceof ParameterizedType) {
            parameterizedType2 = (ParameterizedType)type;
        }
        if (parameterizedType2 != null) {
            Type[] object = parameterizedType2.getActualTypeArguments();
            TypeVariable<Class<?>>[] typeVariableArray = clazz.getTypeParameters();
            for (int i = 0; i < object.length; ++i) {
                Type type2 = object[i];
                TypeVariable<Class<?>> typeVariable = typeVariableArray[i];
                while (type2 instanceof TypeVariable) {
                    TypeVariable typeVariable2 = (TypeVariable)type2;
                    type2 = map.get(typeVariable2.getName());
                }
                map.put(typeVariable.getName(), type2);
            }
            if (com.donutsmp.teams.G.A.B.A.A(parameterizedType2, parameterizedType, map)) {
                return true;
            }
        }
        for (Type type2 : clazz.getGenericInterfaces()) {
            if (!com.donutsmp.teams.G.A.B.A.A(type2, parameterizedType, new HashMap<String, Type>(map))) continue;
            return true;
        }
        Type type3 = clazz.getGenericSuperclass();
        return com.donutsmp.teams.G.A.B.A.A(type3, parameterizedType, new HashMap<String, Type>(map));
    }

    private static boolean A(ParameterizedType parameterizedType, ParameterizedType parameterizedType2, Map<String, Type> map) {
        if (parameterizedType.getRawType().equals(parameterizedType2.getRawType())) {
            Type[] typeArray = parameterizedType.getActualTypeArguments();
            Type[] typeArray2 = parameterizedType2.getActualTypeArguments();
            for (int i = 0; i < typeArray.length; ++i) {
                if (com.donutsmp.teams.G.A.B.A.A(typeArray[i], typeArray2[i], map)) continue;
                return false;
            }
            return true;
        }
        return false;
    }

    private static AssertionError A(Type type, Class<?> ... classArray) {
        StringBuilder stringBuilder = new StringBuilder("Unexpected type. Expected one of: ");
        for (Class<?> clazz : classArray) {
            stringBuilder.append(clazz.getName()).append(", ");
        }
        stringBuilder.append("but got: ").append(type.getClass().getName()).append(", for type token: ").append(type.toString()).append('.');
        return new AssertionError((Object)stringBuilder.toString());
    }

    private static boolean A(Type type, Type type2, Map<String, Type> map) {
        return type2.equals(type) || type instanceof TypeVariable && type2.equals(map.get(((TypeVariable)type).getName()));
    }

    public final int hashCode() {
        return this.A;
    }

    public final boolean equals(Object object) {
        return object instanceof A && N$_B.A(this.B, ((A)object).B);
    }

    public final String toString() {
        return N$_B.E(this.B);
    }

    public static A<?> C(Type type) {
        return new A(type);
    }

    public static <T> A<T> A(Class<T> clazz) {
        return new A<T>(clazz);
    }

    public static A<?> A(Type type, Type ... typeArray) {
        Objects.requireNonNull(type);
        Objects.requireNonNull(typeArray);
        if (!(type instanceof Class)) {
            throw new IllegalArgumentException("rawType must be of type Class, but was " + type);
        }
        int n = typeArray.length;
        Class clazz = (Class)type;
        TypeVariable<Class<T>>[] typeVariableArray = clazz.getTypeParameters();
        int n2 = typeVariableArray.length;
        if (n != n2) {
            throw new IllegalArgumentException(clazz.getName() + " requires " + n2 + " type arguments, but got " + n);
        }
        for (int i = 0; i < n2; ++i) {
            Type type2 = typeArray[i];
            Class<?> clazz2 = N$_B.G(type2);
            TypeVariable typeVariable = typeVariableArray[i];
            for (Type type3 : typeVariable.getBounds()) {
                Class<?> clazz3 = N$_B.G(type3);
                if (clazz3.isAssignableFrom(clazz2)) continue;
                throw new IllegalArgumentException("Type argument " + type2 + " does not satisfy bounds for type variable " + typeVariable + " declared by " + type);
            }
        }
        return new A(N$_B.A(null, type, typeArray));
    }

    public static A<?> B(Type type) {
        return new A(N$_B.C(type));
    }
}

