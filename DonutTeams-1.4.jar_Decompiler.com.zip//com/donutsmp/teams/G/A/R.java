/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import com.donutsmp.teams.G.A.T;

public final class R
extends T {
    private static final long A = 1L;

    public R(String string) {
        super(string);
    }

    public R(String string, Throwable throwable) {
        super(string, throwable);
    }

    public R(Throwable throwable) {
        super(throwable);
    }
}

