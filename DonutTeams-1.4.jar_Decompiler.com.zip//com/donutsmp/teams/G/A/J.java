/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import com.donutsmp.teams.G.A.F;
import java.lang.reflect.Field;
import java.util.Locale;

public enum J implements F
{
    A{

        @Override
        public String A(Field field) {
            return field.getName();
        }
    }
    ,
    E{

        @Override
        public String A(Field field) {
            return 2.A(field.getName());
        }
    }
    ,
    H{

        @Override
        public String A(Field field) {
            return 3.A(3.A(field.getName(), ' '));
        }
    }
    ,
    D{

        @Override
        public String A(Field field) {
            return 4.A(field.getName(), '_').toUpperCase(Locale.ENGLISH);
        }
    }
    ,
    G{

        @Override
        public String A(Field field) {
            return 5.A(field.getName(), '_').toLowerCase(Locale.ENGLISH);
        }
    }
    ,
    F{

        @Override
        public String A(Field field) {
            return 6.A(field.getName(), '-').toLowerCase(Locale.ENGLISH);
        }
    }
    ,
    B{

        @Override
        public String A(Field field) {
            return 7.A(field.getName(), '.').toLowerCase(Locale.ENGLISH);
        }
    };


    static String A(String string, char c) {
        StringBuilder stringBuilder = new StringBuilder();
        int n = string.length();
        for (int i = 0; i < n; ++i) {
            char c2 = string.charAt(i);
            if (Character.isUpperCase(c2) && stringBuilder.length() != 0) {
                stringBuilder.append(c);
            }
            stringBuilder.append(c2);
        }
        return stringBuilder.toString();
    }

    static String A(String string) {
        int n = string.length();
        for (int i = 0; i < n; ++i) {
            char c = string.charAt(i);
            if (!Character.isLetter(c)) continue;
            if (Character.isUpperCase(c)) {
                return string;
            }
            char c2 = Character.toUpperCase(c);
            if (i == 0) {
                return c2 + string.substring(1);
            }
            return string.substring(0, i) + c2 + string.substring(i + 1);
        }
        return string;
    }
}

