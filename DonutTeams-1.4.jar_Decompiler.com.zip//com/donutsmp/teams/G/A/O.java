/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import com.donutsmp.teams.G.A.P;
import java.lang.reflect.Type;

public interface O {
    public P A(Object var1);

    public P A(Object var1, Type var2);
}

