/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import com.donutsmp.teams.G.A.B.A;
import com.donutsmp.teams.G.A.Q;
import com.donutsmp.teams.G.A.V;

public interface B {
    public <T> V<T> A(Q var1, A<T> var2);
}

