/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import com.donutsmp.teams.G.A.A.I;
import com.donutsmp.teams.G.A.D.A;
import com.donutsmp.teams.G.A.D.E;
import com.donutsmp.teams.G.A.P;
import com.donutsmp.teams.G.A.R;
import com.donutsmp.teams.G.A.T;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.Iterator;
import java.util.NoSuchElementException;

public final class D
implements Iterator<P> {
    private final E B;
    private final Object A;

    public D(String string) {
        this(new StringReader(string));
    }

    public D(Reader reader) {
        this.B = new E(reader);
        this.B.B(true);
        this.A = new Object();
    }

    public P A() throws T {
        if (!this.hasNext()) {
            throw new NoSuchElementException();
        }
        try {
            return I.A(this.B);
        } catch (StackOverflowError stackOverflowError) {
            throw new T("Failed parsing JSON source to Json", stackOverflowError);
        } catch (OutOfMemoryError outOfMemoryError) {
            throw new T("Failed parsing JSON source to Json", outOfMemoryError);
        }
    }

    @Override
    public boolean hasNext() {
        Object object = this.A;
        synchronized (object) {
            try {
                return this.B.G() != com.donutsmp.teams.G.A.D.A.H;
            } catch (com.donutsmp.teams.G.A.D.D d) {
                throw new com.donutsmp.teams.G.A.A(d);
            } catch (IOException iOException) {
                throw new R(iOException);
            }
        }
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException();
    }
}

