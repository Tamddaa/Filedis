/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import com.donutsmp.teams.G.A.O;
import com.donutsmp.teams.G.A.P;
import java.lang.reflect.Type;

public interface L<T> {
    public P A(T var1, Type var2, O var3);
}

