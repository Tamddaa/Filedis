/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import com.donutsmp.teams.G.A.A.C.B;
import com.donutsmp.teams.G.A.A.C.E;
import com.donutsmp.teams.G.A.A.C.F;
import com.donutsmp.teams.G.A.A.C.G;
import com.donutsmp.teams.G.A.A.C.I;
import com.donutsmp.teams.G.A.A.C.J;
import com.donutsmp.teams.G.A.A.C.M;
import com.donutsmp.teams.G.A.A.C.N;
import com.donutsmp.teams.G.A.A.C.O;
import com.donutsmp.teams.G.A.A.K;
import com.donutsmp.teams.G.A.A.L;
import com.donutsmp.teams.G.A.D.A;
import com.donutsmp.teams.G.A.D.C;
import com.donutsmp.teams.G.A.D.D;
import com.donutsmp.teams.G.A.P;
import com.donutsmp.teams.G.A.R;
import com.donutsmp.teams.G.A.U;
import com.donutsmp.teams.G.A.V;
import com.donutsmp.teams.G.A.W;
import com.donutsmp.teams.G.A.Z;
import com.donutsmp.teams.G.A._;
import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicLongArray;

public final class Q {
    static final boolean V = false;
    static final boolean M = false;
    static final boolean A = false;
    static final boolean R = true;
    static final boolean b = false;
    static final boolean Y = false;
    static final boolean f = false;
    static final boolean j = true;
    static final String I = null;
    static final com.donutsmp.teams.G.A.F U = com.donutsmp.teams.G.A.J.A;
    static final com.donutsmp.teams.G.A.E G = com.donutsmp.teams.G.A.M.A;
    static final com.donutsmp.teams.G.A.E T = com.donutsmp.teams.G.A.M.B;
    private static final String P = ")]}'\n";
    private final ThreadLocal<Map<com.donutsmp.teams.G.A.B.A<?>, V<?>>> e = new ThreadLocal();
    private final ConcurrentMap<com.donutsmp.teams.G.A.B.A<?>, V<?>> D = new ConcurrentHashMap();
    private final com.donutsmp.teams.G.A.A.G J;
    private final M K;
    final List<com.donutsmp.teams.G.A.B> Q;
    final K C;
    final com.donutsmp.teams.G.A.F h;
    final Map<Type, _<?>> g;
    final boolean Z;
    final boolean B;
    final boolean d;
    final boolean a;
    final boolean X;
    final boolean _;
    final boolean E;
    final boolean N;
    final String O;
    final int L;
    final int c;
    final Z F;
    final List<com.donutsmp.teams.G.A.B> S;
    final List<com.donutsmp.teams.G.A.B> W;
    final com.donutsmp.teams.G.A.E H;
    final com.donutsmp.teams.G.A.E i;
    final List<W> k;

    public Q() {
        this(com.donutsmp.teams.G.A.A.K.c, U, Collections.emptyMap(), false, false, false, true, false, false, false, true, com.donutsmp.teams.G.A.Z.A, I, 2, 2, Collections.emptyList(), Collections.emptyList(), Collections.emptyList(), G, T, Collections.emptyList());
    }

    Q(K k, com.donutsmp.teams.G.A.F f, Map<Type, _<?>> map, boolean bl, boolean bl2, boolean bl3, boolean bl4, boolean bl5, boolean bl6, boolean bl7, boolean bl8, Z z, String string, int n, int n2, List<com.donutsmp.teams.G.A.B> list, List<com.donutsmp.teams.G.A.B> list2, List<com.donutsmp.teams.G.A.B> list3, com.donutsmp.teams.G.A.E e, com.donutsmp.teams.G.A.E e2, List<W> list4) {
        this.C = k;
        this.h = f;
        this.g = map;
        this.J = new com.donutsmp.teams.G.A.A.G(map, bl8, list4);
        this.Z = bl;
        this.B = bl2;
        this.d = bl3;
        this.a = bl4;
        this.X = bl5;
        this._ = bl6;
        this.E = bl7;
        this.N = bl8;
        this.F = z;
        this.O = string;
        this.L = n;
        this.c = n2;
        this.S = list;
        this.W = list2;
        this.H = e;
        this.i = e2;
        this.k = list4;
        ArrayList<com.donutsmp.teams.G.A.B> arrayList = new ArrayList<com.donutsmp.teams.G.A.B>();
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.D);
        arrayList.add(com.donutsmp.teams.G.A.A.C.O.D(e));
        arrayList.add(k);
        arrayList.addAll(list3);
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.S);
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.P);
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.e);
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.h);
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.i);
        V<Number> v = com.donutsmp.teams.G.A.Q.A(z);
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.B(Long.TYPE, Long.class, v));
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.B(Double.TYPE, Double.class, this.A(bl7)));
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.B(Float.TYPE, Float.class, this.B(bl7)));
        arrayList.add(com.donutsmp.teams.G.A.A.C.C.B(e2));
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.X);
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.l);
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.B(AtomicLong.class, com.donutsmp.teams.G.A.Q.A(v)));
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.B(AtomicLongArray.class, com.donutsmp.teams.G.A.Q.B(v)));
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.F);
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.c);
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.t);
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.L);
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.B(BigDecimal.class, com.donutsmp.teams.G.A.A.C.L.G));
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.B(BigInteger.class, com.donutsmp.teams.G.A.A.C.L.o));
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.B(com.donutsmp.teams.G.A.A.J.class, com.donutsmp.teams.G.A.A.C.L.U));
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.w);
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.g);
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.W);
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.I);
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.s);
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.v);
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.Y);
        arrayList.add(com.donutsmp.teams.G.A.A.C.F.V);
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.a);
        if (com.donutsmp.teams.G.A.A.B.C.E) {
            arrayList.add(com.donutsmp.teams.G.A.A.B.C.C);
            arrayList.add(com.donutsmp.teams.G.A.A.B.C.D);
            arrayList.add(com.donutsmp.teams.G.A.A.B.C.A);
        }
        arrayList.add(com.donutsmp.teams.G.A.A.C.K.g);
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.Q);
        arrayList.add(new B(this.J));
        arrayList.add(new N(this.J, bl2));
        this.K = new M(this.J);
        arrayList.add(this.K);
        arrayList.add(com.donutsmp.teams.G.A.A.C.L.H);
        arrayList.add(new E(this.J, f, k, this.K, list4));
        this.Q = Collections.unmodifiableList(arrayList);
    }

    public com.donutsmp.teams.G.A.C E() {
        return new com.donutsmp.teams.G.A.C(this);
    }

    @Deprecated
    public K D() {
        return this.C;
    }

    public com.donutsmp.teams.G.A.F C() {
        return this.h;
    }

    public boolean B() {
        return this.Z;
    }

    public boolean A() {
        return this.a;
    }

    private V<Number> A(boolean bl) {
        if (bl) {
            return com.donutsmp.teams.G.A.A.C.L.J;
        }
        return new V<Number>(){

            public Double q(com.donutsmp.teams.G.A.D.E e) throws IOException {
                if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                    e.S();
                    return null;
                }
                return e.U();
            }

            public void J(C c, Number number) throws IOException {
                if (number == null) {
                    c.C();
                    return;
                }
                double d = number.doubleValue();
                com.donutsmp.teams.G.A.Q.A(d);
                c.A(d);
            }
        };
    }

    private V<Number> B(boolean bl) {
        if (bl) {
            return com.donutsmp.teams.G.A.A.C.L.k;
        }
        return new V<Number>(){

            public Float p(com.donutsmp.teams.G.A.D.E e) throws IOException {
                if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                    e.S();
                    return null;
                }
                return Float.valueOf((float)e.U());
            }

            public void I(C c, Number number) throws IOException {
                if (number == null) {
                    c.C();
                    return;
                }
                float f = number.floatValue();
                com.donutsmp.teams.G.A.Q.A(f);
                Number number2 = number instanceof Float ? (Number)number : (Number)Float.valueOf(f);
                c.A(number2);
            }
        };
    }

    static void A(double d) {
        if (Double.isNaN(d) || Double.isInfinite(d)) {
            throw new IllegalArgumentException(d + " is not a valid double value as per JSON specification. To override this behavior, use GsonBuilder.serializeSpecialFloatingPointValues() method.");
        }
    }

    private static V<Number> A(Z z) {
        if (z == com.donutsmp.teams.G.A.Z.A) {
            return com.donutsmp.teams.G.A.A.C.L.q;
        }
        return new V<Number>(){

            public Number o(com.donutsmp.teams.G.A.D.E e) throws IOException {
                if (e.G() == com.donutsmp.teams.G.A.D.A.E) {
                    e.S();
                    return null;
                }
                return e.B();
            }

            public void H(C c, Number number) throws IOException {
                if (number == null) {
                    c.C();
                    return;
                }
                c.E(number.toString());
            }
        };
    }

    private static V<AtomicLong> A(final V<Number> v) {
        return new V<AtomicLong>(){

            @Override
            public void A(C c, AtomicLong atomicLong) throws IOException {
                v.A(c, Long.valueOf(atomicLong.get()));
            }

            public AtomicLong n(com.donutsmp.teams.G.A.D.E e) throws IOException {
                Number number = (Number)v.A(e);
                return new AtomicLong(number.longValue());
            }
        }.A();
    }

    private static V<AtomicLongArray> B(final V<Number> v) {
        return new V<AtomicLongArray>(){

            @Override
            public void A(C c, AtomicLongArray atomicLongArray) throws IOException {
                c.D();
                int n = atomicLongArray.length();
                for (int i = 0; i < n; ++i) {
                    v.A(c, Long.valueOf(atomicLongArray.get(i)));
                }
                c.H();
            }

            public AtomicLongArray m(com.donutsmp.teams.G.A.D.E e) throws IOException {
                ArrayList<Long> arrayList = new ArrayList<Long>();
                e.H();
                while (e.A()) {
                    long l = ((Number)v.A(e)).longValue();
                    arrayList.add(l);
                }
                e._();
                int n = arrayList.size();
                AtomicLongArray atomicLongArray = new AtomicLongArray(n);
                for (int i = 0; i < n; ++i) {
                    atomicLongArray.set(i, (Long)arrayList.get(i));
                }
                return atomicLongArray;
            }
        }.A();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public <T> V<T> A(com.donutsmp.teams.G.A.B.A<T> a) {
        V<Object> v;
        Objects.requireNonNull(a, "type must not be null");
        V v2 = (V)this.D.get(a);
        if (v2 != null) {
            V v3 = v2;
            return v3;
        }
        Map<com.donutsmp.teams.G.A.B.A<?>, V<?>> map = this.e.get();
        boolean bl = false;
        if (map == null) {
            map = new HashMap();
            this.e.set(map);
            bl = true;
        } else {
            v = map.get(a);
            if (v != null) {
                return v;
            }
        }
        v = null;
        try {
            _A _A2 = new _A();
            map.put(a, _A2);
            for (com.donutsmp.teams.G.A.B b : this.Q) {
                v = b.A(this, a);
                if (v == null) continue;
                _A2.B(v);
                map.put(a, v);
                break;
            }
        } finally {
            if (bl) {
                this.e.remove();
            }
        }
        if (v == null) {
            throw new IllegalArgumentException("GSON (2.10.1) cannot handle " + a);
        }
        if (bl) {
            this.D.putAll(map);
        }
        return v;
    }

    public <T> V<T> A(com.donutsmp.teams.G.A.B b, com.donutsmp.teams.G.A.B.A<T> a) {
        if (!this.Q.contains(b)) {
            b = this.K;
        }
        boolean bl = false;
        for (com.donutsmp.teams.G.A.B b2 : this.Q) {
            if (!bl) {
                if (b2 != b) continue;
                bl = true;
                continue;
            }
            V<T> v = b2.A(this, a);
            if (v == null) continue;
            return v;
        }
        throw new IllegalArgumentException("GSON cannot serialize " + a);
    }

    public <T> V<T> A(Class<T> clazz) {
        return this.A(com.donutsmp.teams.G.A.B.A.A(clazz));
    }

    public P A(Object object) {
        if (object == null) {
            return com.donutsmp.teams.G.A.U.B;
        }
        return this.B(object, object.getClass());
    }

    public P B(Object object, Type type) {
        G g = new G();
        this.A(object, type, g);
        return g.O();
    }

    public String B(Object object) {
        if (object == null) {
            return this.A(com.donutsmp.teams.G.A.U.B);
        }
        return this.A(object, object.getClass());
    }

    public String A(Object object, Type type) {
        StringWriter stringWriter = new StringWriter();
        this.A(object, type, stringWriter);
        return stringWriter.toString();
    }

    public void A(Object object, Appendable appendable) throws R {
        if (object != null) {
            this.A(object, object.getClass(), appendable);
        } else {
            this.A((P)com.donutsmp.teams.G.A.U.B, appendable);
        }
    }

    public void A(Object object, Type type, Appendable appendable) throws R {
        try {
            C c = this.A(com.donutsmp.teams.G.A.A.I.A(appendable));
            this.A(object, type, c);
        } catch (IOException iOException) {
            throw new R(iOException);
        }
    }

    public void A(Object object, Type type, C c) throws R {
        V<?> v = this.A(com.donutsmp.teams.G.A.B.A.C(type));
        boolean bl = c.G();
        c.C(true);
        boolean bl2 = c.L();
        c.B(this.a);
        boolean bl3 = c.E();
        c.D(this.Z);
        try {
            v.A(c, object);
        } catch (IOException iOException) {
            throw new R(iOException);
        } catch (AssertionError assertionError) {
            throw new AssertionError("AssertionError (GSON 2.10.1): " + ((Throwable)((Object)assertionError)).getMessage(), (Throwable)((Object)assertionError));
        } finally {
            c.C(bl);
            c.B(bl2);
            c.D(bl3);
        }
    }

    public String A(P p) {
        StringWriter stringWriter = new StringWriter();
        this.A(p, (Appendable)stringWriter);
        return stringWriter.toString();
    }

    public void A(P p, Appendable appendable) throws R {
        try {
            C c = this.A(com.donutsmp.teams.G.A.A.I.A(appendable));
            this.A(p, c);
        } catch (IOException iOException) {
            throw new R(iOException);
        }
    }

    public C A(Writer writer) throws IOException {
        if (this.d) {
            writer.write(P);
        }
        C c = new C(writer);
        if (this.X) {
            c.C("  ");
        }
        c.B(this.a);
        c.C(this._);
        c.D(this.Z);
        return c;
    }

    public com.donutsmp.teams.G.A.D.E A(Reader reader) {
        com.donutsmp.teams.G.A.D.E e = new com.donutsmp.teams.G.A.D.E(reader);
        e.B(this._);
        return e;
    }

    public void A(P p, C c) throws R {
        boolean bl = c.G();
        c.C(true);
        boolean bl2 = c.L();
        c.B(this.a);
        boolean bl3 = c.E();
        c.D(this.Z);
        try {
            com.donutsmp.teams.G.A.A.I.A(p, c);
        } catch (IOException iOException) {
            throw new R(iOException);
        } catch (AssertionError assertionError) {
            throw new AssertionError("AssertionError (GSON 2.10.1): " + ((Throwable)((Object)assertionError)).getMessage(), (Throwable)((Object)assertionError));
        } finally {
            c.C(bl);
            c.B(bl2);
            c.D(bl3);
        }
    }

    public <T> T A(String string, Class<T> clazz) throws com.donutsmp.teams.G.A.A {
        T t = this.A(string, com.donutsmp.teams.G.A.B.A.A(clazz));
        return com.donutsmp.teams.G.A.A.L.A(clazz).cast(t);
    }

    public <T> T A(String string, Type type) throws com.donutsmp.teams.G.A.A {
        return (T)this.A(string, com.donutsmp.teams.G.A.B.A.C(type));
    }

    public <T> T A(String string, com.donutsmp.teams.G.A.B.A<T> a) throws com.donutsmp.teams.G.A.A {
        if (string == null) {
            return null;
        }
        StringReader stringReader = new StringReader(string);
        return this.A((Reader)stringReader, a);
    }

    public <T> T A(Reader reader, Class<T> clazz) throws com.donutsmp.teams.G.A.A, R {
        T t = this.A(reader, com.donutsmp.teams.G.A.B.A.A(clazz));
        return com.donutsmp.teams.G.A.A.L.A(clazz).cast(t);
    }

    public <T> T A(Reader reader, Type type) throws R, com.donutsmp.teams.G.A.A {
        return (T)this.A(reader, com.donutsmp.teams.G.A.B.A.C(type));
    }

    public <T> T A(Reader reader, com.donutsmp.teams.G.A.B.A<T> a) throws R, com.donutsmp.teams.G.A.A {
        com.donutsmp.teams.G.A.D.E e = this.A(reader);
        T t = this.A(e, a);
        com.donutsmp.teams.G.A.Q.A(t, e);
        return t;
    }

    private static void A(Object object, com.donutsmp.teams.G.A.D.E e) {
        try {
            if (object != null && e.G() != com.donutsmp.teams.G.A.D.A.H) {
                throw new com.donutsmp.teams.G.A.A("JSON document was not fully consumed.");
            }
        } catch (D d) {
            throw new com.donutsmp.teams.G.A.A(d);
        } catch (IOException iOException) {
            throw new R(iOException);
        }
    }

    public <T> T A(com.donutsmp.teams.G.A.D.E e, Type type) throws R, com.donutsmp.teams.G.A.A {
        return (T)this.A(e, com.donutsmp.teams.G.A.B.A.C(type));
    }

    public <T> T A(com.donutsmp.teams.G.A.D.E e, com.donutsmp.teams.G.A.B.A<T> a) throws R, com.donutsmp.teams.G.A.A {
        boolean bl = true;
        boolean bl2 = e.F();
        e.B(true);
        try {
            e.G();
            bl = false;
            V<T> v = this.A(a);
            T t = v.A(e);
            return t;
        } catch (EOFException eOFException) {
            if (bl) {
                T t = null;
                return t;
            }
            throw new com.donutsmp.teams.G.A.A(eOFException);
        } catch (IllegalStateException illegalStateException) {
            throw new com.donutsmp.teams.G.A.A(illegalStateException);
        } catch (IOException iOException) {
            throw new com.donutsmp.teams.G.A.A(iOException);
        } catch (AssertionError assertionError) {
            throw new AssertionError("AssertionError (GSON 2.10.1): " + ((Throwable)((Object)assertionError)).getMessage(), (Throwable)((Object)assertionError));
        } finally {
            e.B(bl2);
        }
    }

    public <T> T A(P p, Class<T> clazz) throws com.donutsmp.teams.G.A.A {
        T t = this.A(p, com.donutsmp.teams.G.A.B.A.A(clazz));
        return com.donutsmp.teams.G.A.A.L.A(clazz).cast(t);
    }

    public <T> T A(P p, Type type) throws com.donutsmp.teams.G.A.A {
        return (T)this.A(p, com.donutsmp.teams.G.A.B.A.C(type));
    }

    public <T> T A(P p, com.donutsmp.teams.G.A.B.A<T> a) throws com.donutsmp.teams.G.A.A {
        if (p == null) {
            return null;
        }
        return this.A((com.donutsmp.teams.G.A.D.E)new J(p), a);
    }

    public String toString() {
        return "{serializeNulls:" + this.Z + ",factories:" + this.Q + ",instanceCreators:" + this.J + "}";
    }

    static class _A<T>
    extends I<T> {
        private V<T> d = null;

        _A() {
        }

        public void B(V<T> v) {
            if (this.d != null) {
                throw new AssertionError((Object)"Delegate is already set");
            }
            this.d = v;
        }

        private V<T> G() {
            V<T> v = this.d;
            if (v == null) {
                throw new IllegalStateException("Adapter for type with cyclic dependency has been used before dependency has been resolved");
            }
            return v;
        }

        @Override
        public V<T> E() {
            return this.G();
        }

        @Override
        public T A(com.donutsmp.teams.G.A.D.E e) throws IOException {
            return this.G().A(e);
        }

        @Override
        public void A(C c, T t) throws IOException {
            this.G().A(c, t);
        }
    }
}

