/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import com.donutsmp.teams.G.A.A.I;
import com.donutsmp.teams.G.A.D.A;
import com.donutsmp.teams.G.A.D.D;
import com.donutsmp.teams.G.A.D.E;
import com.donutsmp.teams.G.A.P;
import com.donutsmp.teams.G.A.R;
import com.donutsmp.teams.G.A.T;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

public final class Y {
    @Deprecated
    public Y() {
    }

    public static P A(String string) throws com.donutsmp.teams.G.A.A {
        return Y.B(new StringReader(string));
    }

    public static P B(Reader reader) throws R, com.donutsmp.teams.G.A.A {
        try {
            E e = new E(reader);
            P p = Y.A(e);
            if (!p.L() && e.G() != A.H) {
                throw new com.donutsmp.teams.G.A.A("Did not consume the entire document.");
            }
            return p;
        } catch (D d) {
            throw new com.donutsmp.teams.G.A.A(d);
        } catch (IOException iOException) {
            throw new R(iOException);
        } catch (NumberFormatException numberFormatException) {
            throw new com.donutsmp.teams.G.A.A(numberFormatException);
        }
    }

    public static P A(E e) throws R, com.donutsmp.teams.G.A.A {
        boolean bl = e.F();
        e.B(true);
        try {
            P p = I.A(e);
            return p;
        } catch (StackOverflowError stackOverflowError) {
            throw new T("Failed parsing JSON source: " + e + " to Json", stackOverflowError);
        } catch (OutOfMemoryError outOfMemoryError) {
            throw new T("Failed parsing JSON source: " + e + " to Json", outOfMemoryError);
        } finally {
            e.B(bl);
        }
    }

    @Deprecated
    public P B(String string) throws com.donutsmp.teams.G.A.A {
        return Y.A(string);
    }

    @Deprecated
    public P A(Reader reader) throws R, com.donutsmp.teams.G.A.A {
        return Y.B(reader);
    }

    @Deprecated
    public P B(E e) throws R, com.donutsmp.teams.G.A.A {
        return Y.A(e);
    }
}

