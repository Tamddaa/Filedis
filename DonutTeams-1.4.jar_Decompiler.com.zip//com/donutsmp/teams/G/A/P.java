/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import com.donutsmp.teams.G.A.A.I;
import com.donutsmp.teams.G.A.D.C;
import com.donutsmp.teams.G.A.G;
import com.donutsmp.teams.G.A.S;
import com.donutsmp.teams.G.A.U;
import com.donutsmp.teams.G.A.X;
import java.io.IOException;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.math.BigInteger;

public abstract class P {
    @Deprecated
    public P() {
    }

    public abstract P N();

    public boolean J() {
        return this instanceof X;
    }

    public boolean K() {
        return this instanceof S;
    }

    public boolean C() {
        return this instanceof G;
    }

    public boolean L() {
        return this instanceof U;
    }

    public S P() {
        if (this.K()) {
            return (S)this;
        }
        throw new IllegalStateException("Not a JSON Object: " + this);
    }

    public X T() {
        if (this.J()) {
            return (X)this;
        }
        throw new IllegalStateException("Not a JSON Array: " + this);
    }

    public G E() {
        if (this.C()) {
            return (G)this;
        }
        throw new IllegalStateException("Not a JSON Primitive: " + this);
    }

    public U G() {
        if (this.L()) {
            return (U)this;
        }
        throw new IllegalStateException("Not a JSON Null: " + this);
    }

    public boolean S() {
        throw new UnsupportedOperationException(this.getClass().getSimpleName());
    }

    public Number D() {
        throw new UnsupportedOperationException(this.getClass().getSimpleName());
    }

    public String M() {
        throw new UnsupportedOperationException(this.getClass().getSimpleName());
    }

    public double H() {
        throw new UnsupportedOperationException(this.getClass().getSimpleName());
    }

    public float B() {
        throw new UnsupportedOperationException(this.getClass().getSimpleName());
    }

    public long F() {
        throw new UnsupportedOperationException(this.getClass().getSimpleName());
    }

    public int U() {
        throw new UnsupportedOperationException(this.getClass().getSimpleName());
    }

    public byte R() {
        throw new UnsupportedOperationException(this.getClass().getSimpleName());
    }

    @Deprecated
    public char Q() {
        throw new UnsupportedOperationException(this.getClass().getSimpleName());
    }

    public BigDecimal O() {
        throw new UnsupportedOperationException(this.getClass().getSimpleName());
    }

    public BigInteger I() {
        throw new UnsupportedOperationException(this.getClass().getSimpleName());
    }

    public short A() {
        throw new UnsupportedOperationException(this.getClass().getSimpleName());
    }

    public String toString() {
        try {
            StringWriter stringWriter = new StringWriter();
            C c = new C(stringWriter);
            c.C(true);
            I.A(this, c);
            return stringWriter.toString();
        } catch (IOException iOException) {
            throw new AssertionError((Object)iOException);
        }
    }
}

