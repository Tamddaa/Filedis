/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

public class T
extends RuntimeException {
    static final long serialVersionUID = -4086729973971783390L;

    public T(String string) {
        super(string);
    }

    public T(String string, Throwable throwable) {
        super(string, throwable);
    }

    public T(Throwable throwable) {
        super(throwable);
    }
}

