/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import com.donutsmp.teams.G.A.K;
import com.donutsmp.teams.G.A.P;
import com.donutsmp.teams.G.A.T;
import java.lang.reflect.Type;

public interface N<T> {
    public T A(P var1, Type var2, K var3) throws T;
}

