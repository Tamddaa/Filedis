/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import com.donutsmp.teams.G.A.A.D;
import com.donutsmp.teams.G.A.G;
import com.donutsmp.teams.G.A.P;
import com.donutsmp.teams.G.A.U;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class X
extends P
implements Iterable<P> {
    private final ArrayList<P> C;

    public X() {
        this.C = new ArrayList();
    }

    public X(int n) {
        this.C = new ArrayList(n);
    }

    public X c() {
        if (!this.C.isEmpty()) {
            X x = new X(this.C.size());
            for (P p : this.C) {
                x.C(p.N());
            }
            return x;
        }
        return new X();
    }

    public void A(Boolean bl) {
        this.C.add(bl == null ? U.B : new G(bl));
    }

    public void A(Character c) {
        this.C.add(c == null ? U.B : new G(c));
    }

    public void A(Number number) {
        this.C.add(number == null ? U.B : new G(number));
    }

    public void G(String string) {
        this.C.add(string == null ? U.B : new G(string));
    }

    public void C(P p) {
        if (p == null) {
            p = U.B;
        }
        this.C.add(p);
    }

    public void A(X x) {
        this.C.addAll(x.C);
    }

    public P A(int n, P p) {
        return this.C.set(n, p == null ? U.B : p);
    }

    public boolean B(P p) {
        return this.C.remove(p);
    }

    public P B(int n) {
        return this.C.remove(n);
    }

    public boolean A(P p) {
        return this.C.contains(p);
    }

    public int f() {
        return this.C.size();
    }

    public boolean e() {
        return this.C.isEmpty();
    }

    @Override
    public Iterator<P> iterator() {
        return this.C.iterator();
    }

    public P A(int n) {
        return this.C.get(n);
    }

    private P d() {
        int n = this.C.size();
        if (n == 1) {
            return this.C.get(0);
        }
        throw new IllegalStateException("Array must have size 1, but has size " + n);
    }

    @Override
    public Number D() {
        return this.d().D();
    }

    @Override
    public String M() {
        return this.d().M();
    }

    @Override
    public double H() {
        return this.d().H();
    }

    @Override
    public BigDecimal O() {
        return this.d().O();
    }

    @Override
    public BigInteger I() {
        return this.d().I();
    }

    @Override
    public float B() {
        return this.d().B();
    }

    @Override
    public long F() {
        return this.d().F();
    }

    @Override
    public int U() {
        return this.d().U();
    }

    @Override
    public byte R() {
        return this.d().R();
    }

    @Override
    @Deprecated
    public char Q() {
        return this.d().Q();
    }

    @Override
    public short A() {
        return this.d().A();
    }

    @Override
    public boolean S() {
        return this.d().S();
    }

    public List<P> b() {
        return new D<P>(this.C);
    }

    public boolean equals(Object object) {
        return object == this || object instanceof X && ((X)object).C.equals(this.C);
    }

    public int hashCode() {
        return this.C.hashCode();
    }
}

