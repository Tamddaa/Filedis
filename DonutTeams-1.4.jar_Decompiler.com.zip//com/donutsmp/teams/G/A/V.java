/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import com.donutsmp.teams.G.A.A.C.G;
import com.donutsmp.teams.G.A.A.C.J;
import com.donutsmp.teams.G.A.D.A;
import com.donutsmp.teams.G.A.D.C;
import com.donutsmp.teams.G.A.D.E;
import com.donutsmp.teams.G.A.P;
import com.donutsmp.teams.G.A.R;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;

public abstract class V<T> {
    public abstract void A(C var1, T var2) throws IOException;

    public final void A(Writer writer, T t) throws IOException {
        C c = new C(writer);
        this.A(c, t);
    }

    public final V<T> A() {
        return new V<T>(){

            @Override
            public void A(C c, T t) throws IOException {
                if (t == null) {
                    c.C();
                } else {
                    V.this.A(c, t);
                }
            }

            @Override
            public T A(E e) throws IOException {
                if (e.G() == A.E) {
                    e.S();
                    return null;
                }
                return V.this.A(e);
            }
        };
    }

    public final String B(T t) {
        StringWriter stringWriter = new StringWriter();
        try {
            this.A(stringWriter, t);
        } catch (IOException iOException) {
            throw new R(iOException);
        }
        return stringWriter.toString();
    }

    public final P A(T t) {
        try {
            G g = new G();
            this.A(g, t);
            return g.O();
        } catch (IOException iOException) {
            throw new R(iOException);
        }
    }

    public abstract T A(E var1) throws IOException;

    public final T A(Reader reader) throws IOException {
        E e = new E(reader);
        return this.A(e);
    }

    public final T A(String string) throws IOException {
        return this.A(new StringReader(string));
    }

    public final T A(P p) {
        try {
            J j = new J(p);
            return this.A(j);
        } catch (IOException iOException) {
            throw new R(iOException);
        }
    }
}

