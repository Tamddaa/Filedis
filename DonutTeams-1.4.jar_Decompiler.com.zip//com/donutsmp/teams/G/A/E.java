/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.G.A;

import java.io.IOException;

public interface E {
    public Number A(com.donutsmp.teams.G.A.D.E var1) throws IOException;
}

