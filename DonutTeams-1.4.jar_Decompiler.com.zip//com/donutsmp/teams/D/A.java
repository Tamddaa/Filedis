/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 */
package com.donutsmp.teams.D;

import java.util.UUID;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class A
implements InventoryHolder {
    private final UUID A;

    public A(UUID uUID) {
        this.A = uUID;
    }

    public UUID A() {
        return this.A;
    }

    public Inventory getInventory() {
        return null;
    }
}

