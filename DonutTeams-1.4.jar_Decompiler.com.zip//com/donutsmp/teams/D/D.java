/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 */
package com.donutsmp.teams.D;

import com.donutsmp.teams.E.A;
import com.donutsmp.teams.Teams;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class D
implements InventoryHolder {
    private final Inventory C;
    private final Teams B;
    private final A A;
    private final OfflinePlayer E;
    private final Player D;

    public D(Teams teams, Player player, OfflinePlayer offlinePlayer, A a) {
        this.B = teams;
        this.D = player;
        this.E = offlinePlayer;
        this.A = a;
        String string = teams.getLegacyMsg("member_gui_title", "%player%", offlinePlayer.getName());
        this.C = Bukkit.createInventory((InventoryHolder)this, (int)27, (String)string);
        this.C();
    }

    private void C() {
        if (this.A == null || this.E == null) {
            return;
        }
        com.donutsmp.teams.E.D d = this.A.D(this.E.getUniqueId());
        if (d == null) {
            this.B.getLogger().warning("Could not load MemberData for " + this.E.getName() + " in MemberOptionsGUI.");
            d = new com.donutsmp.teams.E.D();
        }
        this.C.setItem(10, this.A(Material.WHITE_BANNER, "member_gui_perm_home_name", this.A("member_gui_perm_home_lore"), d.A()));
        this.C.setItem(11, this.A(Material.OAK_DOOR, this.B.getRawMsg("member_gui_kick_name", new String[0]), this.A("member_gui_kick_lore")));
        this.C.setItem(12, this.A(Material.IRON_HELMET, "member_gui_perm_manage_name", this.A("member_gui_perm_manage_lore"), d.D()));
        this.C.setItem(13, this.A(Material.IRON_SWORD, "member_gui_perm_pvp_name", this.A("member_gui_perm_pvp_lore"), d.C()));
        this.C.setItem(14, this.A(Material.ENDER_PEARL, "member_gui_perm_visithome_name", this.A("member_gui_perm_visithome_lore"), d.B()));
        this.C.setItem(15, this.A(Material.FEATHER, "member_gui_perm_chat_name", this.A("member_gui_perm_chat_lore"), d.F()));
        this.C.setItem(18, this.A(Material.RED_STAINED_GLASS_PANE, this.B.getRawMsg("member_gui_back_name", new String[0]), null));
    }

    public void A(Player player) {
        player.openInventory(this.C);
    }

    private List<String> A(String string) {
        return this.B.getMessagesConfig().getStringList(string);
    }

    private ItemStack A(Material material, String string3, List<String> list, boolean bl) {
        String string4 = this.B.getRawMsg(string3, new String[0]);
        String string5 = bl ? this.B.getRawMsg("member_gui_status_on", new String[0]) : this.B.getRawMsg("member_gui_status_off", new String[0]);
        List<String> list2 = list.stream().map(string -> string.replace("%player%", this.E.getName())).map(string2 -> string2.replace("%status%", string5)).collect(Collectors.toList());
        return this.A(material, string4, list2);
    }

    private ItemStack A(Material material, String string2, List<String> list) {
        ItemStack itemStack = new ItemStack(material);
        ItemMeta itemMeta = itemStack.getItemMeta();
        if (itemMeta != null) {
            String string3 = string2.replace("%player%", this.E.getName());
            itemMeta.setDisplayName(Teams.colorize(string3));
            if (list != null && !list.isEmpty()) {
                List list2 = list.stream().map(string -> string.replace("%player%", this.E.getName())).map(Teams::colorize).collect(Collectors.toList());
                itemMeta.setLore(list2);
            }
            itemStack.setItemMeta(itemMeta);
        }
        return itemStack;
    }

    public Inventory getInventory() {
        return this.C;
    }

    public OfflinePlayer B() {
        return this.E;
    }

    public A A() {
        return this.A;
    }
}

