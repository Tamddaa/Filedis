/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.SkullMeta
 *  org.bukkit.persistence.PersistentDataType
 */
package com.donutsmp.teams.D;

import com.donutsmp.teams.B.A;
import com.donutsmp.teams.Teams;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;

public class C
implements InventoryHolder {
    private Inventory G;
    private final Teams E;
    private final com.donutsmp.teams.E.A B;
    private int F;
    private int D;
    private static final int A = 44;
    public static final NamespacedKey C = new NamespacedKey("donutsmp_teams", "gui_page");

    private C(Teams teams, com.donutsmp.teams.E.A a) {
        this.E = teams;
        this.B = a;
    }

    public C(Teams teams) {
        this.E = teams;
        this.B = null;
        this.G = null;
        this.F = 1;
        this.D = 1;
    }

    public void B(Player player) {
        this.A(player, 1);
    }

    public void A(Player player, int n) {
        com.donutsmp.teams.E.A a = this.E.getTeamManager().K(player);
        if (a == null) {
            this.E.sendPrefixedMessage((CommandSender)player, "not_in_a_team", new String[0]);
            return;
        }
        try {
            C c = new C(this.E, a);
            c.B(player, n);
            player.openInventory(c.getInventory());
        } catch (Exception exception) {
            player.sendMessage(String.valueOf(ChatColor.RED) + "An error occurred trying to open the team menu (GUI). Check console.");
            this.E.getLogger().log(Level.SEVERE, "Error creating/opening TeamGUI for " + player.getName(), exception);
        }
    }

    private void B(Player player, int n) {
        A a = this.E.getPlayerSortPreference(player);
        List<UUID> list = this.B.H().stream().filter(uUID -> !uUID.equals(this.B.K())).collect(Collectors.toList());
        List<UUID> list2 = this.A(list, a);
        int n2 = list2.size();
        this.D = n2 <= 0 ? 1 : (int)Math.ceil((double)n2 / 44.0);
        this.F = Math.max(1, Math.min(n, this.D));
        String string = this.E.getRawMsg("gui_title_paginated", "%team_name%", this.B.I(), "%current_page%", String.valueOf(this.F), "%total_pages%", String.valueOf(this.D));
        this.G = Bukkit.createInventory((InventoryHolder)this, (int)54, (String)Teams.colorize(string));
        this.C();
        this.A(list2);
        this.A(player);
    }

    private List<UUID> A(List<UUID> list, A a) {
        List<UUID> list2 = new ArrayList<UUID>(list);
        if (a == com.donutsmp.teams.B.A.A) {
            list2 = list2.stream().filter(uUID -> Bukkit.getOfflinePlayer((UUID)uUID).isOnline()).collect(Collectors.toList());
            list2.sort(Comparator.comparing(uUID -> {
                OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((UUID)uUID);
                return offlinePlayer.getName() != null ? offlinePlayer.getName() : "";
            }, String.CASE_INSENSITIVE_ORDER));
            return list2;
        }
        switch (a) {
            case F: {
                list2.sort(Comparator.comparing(uUID -> {
                    OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((UUID)uUID);
                    return offlinePlayer.getName() != null ? offlinePlayer.getName() : "";
                }, String.CASE_INSENSITIVE_ORDER));
                break;
            }
            case B: {
                list2.sort(Comparator.comparing(uUID -> {
                    OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((UUID)uUID);
                    return offlinePlayer.getName() != null ? offlinePlayer.getName() : "";
                }, String.CASE_INSENSITIVE_ORDER));
                break;
            }
            case C: {
                list2.sort(Comparator.comparing(uUID -> {
                    OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((UUID)uUID);
                    return offlinePlayer.getName() != null ? offlinePlayer.getName() : "";
                }, String.CASE_INSENSITIVE_ORDER));
                break;
            }
            case E: {
                list2.sort(Comparator.comparing(uUID -> {
                    OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((UUID)uUID);
                    return offlinePlayer.getName() != null ? offlinePlayer.getName() : "";
                }, String.CASE_INSENSITIVE_ORDER));
            }
        }
        return list2;
    }

    private void A(List<UUID> list) {
        int n = (this.F - 1) * 44;
        int n2 = Math.min(n + 44, list.size());
        List<Object> list2 = new ArrayList();
        if (n <= n2 && n2 <= list.size()) {
            list2 = list.subList(n, n2);
        } else {
            this.E.getLogger().severe("SubList index out of bounds! Start: " + n + ", End: " + n2 + ", Size: " + list.size());
        }
        int n3 = 1;
        for (UUID uUID : list2) {
            if (n3 >= 45) break;
            OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((UUID)uUID);
            ItemStack itemStack = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta skullMeta = (SkullMeta)itemStack.getItemMeta();
            if (skullMeta != null) {
                try {
                    skullMeta.setOwningPlayer(offlinePlayer);
                } catch (Exception exception) {
                    this.E.getLogger().warning("Could not set skull owner for " + offlinePlayer.getName() + " (UUID: " + String.valueOf(uUID) + ")");
                }
                skullMeta.setDisplayName("\u00a77[Member] \u00a7f" + (offlinePlayer.getName() != null ? offlinePlayer.getName() : "Unknown"));
                itemStack.setItemMeta((ItemMeta)skullMeta);
                this.G.setItem(n3, itemStack);
            }
            ++n3;
        }
    }

    private void C() {
        Object object;
        ItemStack itemStack;
        List<String> list;
        String string2;
        Object object2;
        ItemStack itemStack2;
        if (this.G == null) {
            return;
        }
        OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((UUID)this.B.K());
        ItemStack itemStack3 = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta skullMeta = (SkullMeta)itemStack3.getItemMeta();
        if (skullMeta != null) {
            skullMeta.setOwningPlayer(offlinePlayer);
            skullMeta.setDisplayName("\u00a7c[Owner] \u00a7f" + (offlinePlayer.getName() != null ? offlinePlayer.getName() : "Unknown"));
            itemStack3.setItemMeta((ItemMeta)skullMeta);
        }
        this.G.setItem(0, itemStack3);
        int n = this.E.getConfig().getInt("max_team_members", 50);
        String string3 = this.E.getRawMsg("gui_items.search.name", new String[0]);
        List<String> list2 = this.A("gui_items.search.lore");
        this.G.setItem(45, this.A(Material.OAK_SIGN, string3, list2));
        this.G.setItem(46, this.A(com.donutsmp.teams.B.A.C));
        if (this.F > 1) {
            var8_7 = this.E.getRawMsg("gui_items.back_page.name", new String[0]);
            itemStack2 = this.A(Material.ARROW, var8_7, var9_9 = this.A("gui_items.back_page.lore"));
            object2 = itemStack2.getItemMeta();
            if (object2 != null) {
                object2.getPersistentDataContainer().set(C, PersistentDataType.INTEGER, (Object)this.F);
                itemStack2.setItemMeta(object2);
            }
        } else {
            var8_7 = this.E.getRawMsg("gui_items.nav_disabled.name", "&cNo more pages");
            var9_9 = this.A("gui_items.nav_disabled.lore");
            itemStack2 = this.A(Material.ARROW, var8_7, var9_9);
        }
        this.G.setItem(48, itemStack2);
        int n2 = this.B.H().size();
        int n3 = this.B.G().size();
        object2 = this.E.getRawMsg("gui_items.team_info.name", new String[0]).replace("%team_name%", this.B.I());
        List<String> list3 = this.A("gui_items.team_info.lore").stream().map(string -> string.replace("%max_members%", String.valueOf(n))).map(string -> string.replace("%current_members%", String.valueOf(n2))).map(string -> string.replace("%ally_count%", String.valueOf(n3))).collect(Collectors.toList());
        ItemStack itemStack4 = this.A(Material.IRON_HELMET, (String)object2, list3);
        ItemMeta itemMeta = itemStack4.getItemMeta();
        if (itemMeta != null) {
            itemMeta.getPersistentDataContainer().set(C, PersistentDataType.INTEGER, (Object)this.F);
            itemStack4.setItemMeta(itemMeta);
        }
        this.G.setItem(49, itemStack4);
        if (this.F < this.D) {
            string2 = this.E.getRawMsg("gui_items.next_page.name", new String[0]);
            itemStack = this.A(Material.ARROW, string2, list = this.A("gui_items.next_page.lore"));
            object = itemStack.getItemMeta();
            if (object != null) {
                object.getPersistentDataContainer().set(C, PersistentDataType.INTEGER, (Object)this.F);
                itemStack.setItemMeta(object);
            }
        } else {
            string2 = this.E.getRawMsg("gui_items.nav_disabled.name", "&cNo more pages");
            list = this.A("gui_items.nav_disabled.lore");
            itemStack = this.A(Material.ARROW, string2, list);
        }
        this.G.setItem(50, itemStack);
        string2 = this.E.getRawMsg("gui_items.team_home.name", new String[0]);
        list = this.A("gui_items.team_home.lore");
        this.G.setItem(52, this.A(Material.WHITE_BANNER, string2, list));
        object = this.B.F() ? this.E.getRawMsg("pvp_status_on", new String[0]) : this.E.getRawMsg("pvp_status_off", new String[0]);
        String string4 = this.E.getRawMsg("gui_items.pvp.name", new String[0]);
        List<String> list4 = this.A("gui_items.pvp.lore").stream().map(arg_0 -> C.A((String)object, arg_0)).collect(Collectors.toList());
        ItemStack itemStack5 = this.A(Material.IRON_SWORD, string4, list4);
        ItemMeta itemMeta2 = itemStack5.getItemMeta();
        if (itemMeta2 != null) {
            itemMeta2.getPersistentDataContainer().set(C, PersistentDataType.INTEGER, (Object)this.F);
            itemStack5.setItemMeta(itemMeta2);
        }
        this.G.setItem(53, itemStack5);
    }

    private List<String> A(String string) {
        List list = this.E.getMessagesConfig().getStringList(string);
        return list != null && !list.isEmpty() ? list : Collections.emptyList();
    }

    private ItemStack A(Material material, String string, List<String> list) {
        ItemStack itemStack = new ItemStack(material);
        ItemMeta itemMeta = itemStack.getItemMeta();
        if (itemMeta != null) {
            itemMeta.setDisplayName(Teams.colorize(string));
            List list2 = list.stream().map(Teams::colorize).collect(Collectors.toList());
            itemMeta.setLore(list2);
            itemStack.setItemMeta(itemMeta);
        }
        return itemStack;
    }

    private ItemStack A(A a) {
        String string = this.E.getRawMsg("gui_items.sort.name", new String[0]);
        String string2 = this.E.getRawMsg("gui_items.sort.color_selected", "&a");
        String string3 = this.E.getRawMsg("gui_items.sort.color_unselected", "&7");
        String string4 = this.E.getRawMsg("gui_items.sort.line_join_date", new String[0]);
        String string5 = this.E.getRawMsg("gui_items.sort.line_permissions", new String[0]);
        String string6 = this.E.getRawMsg("gui_items.sort.line_money", new String[0]);
        String string7 = this.E.getRawMsg("gui_items.sort.line_alphabetical", new String[0]);
        String string8 = this.E.getRawMsg("gui_items.sort.line_online", new String[0]);
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add((a == com.donutsmp.teams.B.A.C ? string2 : string3) + string4);
        arrayList.add((a == com.donutsmp.teams.B.A.B ? string2 : string3) + string5);
        arrayList.add((a == com.donutsmp.teams.B.A.E ? string2 : string3) + string6);
        arrayList.add((a == com.donutsmp.teams.B.A.F ? string2 : string3) + string7);
        arrayList.add((a == com.donutsmp.teams.B.A.A ? string2 : string3) + string8);
        List<String> list = this.A("gui_items.sort.lore_extra");
        arrayList.addAll(list);
        return this.A(Material.HOPPER, string, arrayList);
    }

    public void A(Player player) {
        if (this.G == null) {
            return;
        }
        A a = this.E.getPlayerSortPreference(player);
        this.G.setItem(46, this.A(a));
    }

    public Inventory getInventory() {
        return this.G;
    }

    public int A() {
        return this.F;
    }

    public com.donutsmp.teams.E.A B() {
        return this.B;
    }

    private static /* synthetic */ String A(String string, String string2) {
        return string2.replace("%pvp_status%", string);
    }
}

