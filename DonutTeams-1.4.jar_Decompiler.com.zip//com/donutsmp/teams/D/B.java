/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 */
package com.donutsmp.teams.D;

import com.donutsmp.teams.E.A;
import com.donutsmp.teams.E.C;
import com.donutsmp.teams.Teams;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class B
implements InventoryHolder {
    private final Inventory C;
    private final Teams B;
    private final C E;
    private final Player D;
    private final A A;

    public B(Teams teams, C c, Player player) {
        this.B = teams;
        this.E = c;
        this.D = player;
        this.A = c.K(player);
        String string = teams.getLegacyMsg("settings_gui_title", new String[0]);
        this.C = Bukkit.createInventory((InventoryHolder)this, (int)36, (String)string);
        this.A();
    }

    private void A() {
        if (this.A == null) {
            return;
        }
        boolean bl = this.A.E();
        ItemStack itemStack = this.A(Material.PAPER, this.B.getRawMsg("settings_team_invites_name", new String[0]), bl ? this.A("settings_team_invites_lore_on") : this.A("settings_team_invites_lore_off"));
        this.C.setItem(3, itemStack);
        boolean bl2 = this.A.A();
        ItemStack itemStack2 = this.A(Material.BIRCH_SIGN, this.B.getRawMsg("settings_ally_invites_name", new String[0]), bl2 ? this.A("settings_ally_invites_lore_on") : this.A("settings_ally_invites_lore_off"));
        this.C.setItem(4, itemStack2);
        boolean bl3 = this.A.J();
        ItemStack itemStack3 = this.A(bl3 ? Material.LIME_STAINED_GLASS_PANE : Material.GRAY_STAINED_GLASS_PANE, this.B.getRawMsg("settings_chat_iso_name", new String[0]), bl3 ? this.A("settings_chat_iso_lore_on") : this.A("settings_chat_iso_lore_off"));
        this.C.setItem(5, itemStack3);
    }

    public void A(Player player) {
        player.openInventory(this.C);
    }

    private List<String> A(String string) {
        return this.B.getMessagesConfig().getStringList(string);
    }

    private ItemStack A(Material material, String string, List<String> list) {
        ItemStack itemStack = new ItemStack(material);
        ItemMeta itemMeta = itemStack.getItemMeta();
        if (itemMeta != null) {
            itemMeta.setDisplayName(Teams.colorize(string));
            List list2 = list.stream().map(Teams::colorize).collect(Collectors.toList());
            itemMeta.setLore(list2);
            itemStack.setItemMeta(itemMeta);
        }
        return itemStack;
    }

    public Inventory getInventory() {
        return this.C;
    }

    public Player B() {
        return this.D;
    }

    public A C() {
        return this.A;
    }
}

