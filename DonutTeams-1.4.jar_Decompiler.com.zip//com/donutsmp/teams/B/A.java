/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.B;

public final class A
extends Enum<A> {
    public static final /* enum */ A C = new A();
    public static final /* enum */ A B = new A();
    public static final /* enum */ A E = new A();
    public static final /* enum */ A F = new A();
    public static final /* enum */ A A = new A();
    private static final /* synthetic */ A[] D;

    public static A[] values() {
        return (A[])D.clone();
    }

    public static A valueOf(String string) {
        return Enum.valueOf(A.class, string);
    }

    public A B() {
        A[] aArray = com.donutsmp.teams.B.A.values();
        int n = this.ordinal();
        int n2 = (n + 1) % aArray.length;
        return aArray[n2];
    }

    private static /* synthetic */ A[] A() {
        return new A[]{C, B, E, F, A};
    }

    static {
        D = com.donutsmp.teams.B.A.A();
    }
}

