/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.configuration.Configuration
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Listener
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 */
package com.donutsmp.teams;

import com.donutsmp.teams.B.A;
import com.donutsmp.teams.F.B;
import com.donutsmp.teams.F.C;
import com.donutsmp.teams.F.D;
import com.donutsmp.teams.F.E;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.Configuration;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public final class Teams
extends JavaPlugin {
    private com.donutsmp.teams.E.C G;
    private com.donutsmp.teams.E.B C;
    private FileConfiguration B = null;
    private File F = null;
    private final Map<UUID, A> A = new HashMap<UUID, A>();
    private com.donutsmp.teams.C.A E = null;
    private static final Pattern D = Pattern.compile("&#([A-Fa-f0-9]{6})");

    public static String colorize(String string) {
        if (string == null) {
            return "";
        }
        Matcher matcher = D.matcher(string);
        StringBuffer stringBuffer = new StringBuffer();
        while (matcher.find()) {
            String string2 = matcher.group(1);
            StringBuilder stringBuilder = new StringBuilder("\u00a7x");
            for (char c : string2.toCharArray()) {
                stringBuilder.append('\u00a7').append(c);
            }
            matcher.appendReplacement(stringBuffer, stringBuilder.toString());
        }
        matcher.appendTail(stringBuffer);
        return ChatColor.translateAlternateColorCodes((char)'&', (String)stringBuffer.toString());
    }

    public void onEnable() {
        Object object;
        this.getLogger().info("DonutTeams enabling...");
        this.getLogger().info("Loading config.yml...");
        this.saveDefaultConfig();
        FileConfiguration fileConfiguration = this.getConfig();
        InputStream inputStream = this.getResource("config.yml");
        if (inputStream != null) {
            try {
                object = new InputStreamReader(inputStream, StandardCharsets.UTF_8);
                try {
                    YamlConfiguration yamlConfiguration = YamlConfiguration.loadConfiguration((Reader)object);
                    fileConfiguration.addDefaults((Configuration)yamlConfiguration);
                    fileConfiguration.options().copyDefaults(true);
                    this.saveConfig();
                    this.getLogger().info("config.yml loaded and merged successfully.");
                } finally {
                    ((InputStreamReader)object).close();
                }
            } catch (IOException iOException) {
                this.getLogger().log(Level.SEVERE, "Could not load default config.yml from JAR", iOException);
            }
        } else {
            this.getLogger().severe("!!! Default config.yml NOT FOUND in JAR!");
        }
        this.loadMessages();
        this.C = new com.donutsmp.teams.E.B(this);
        this.G = new com.donutsmp.teams.E.C(this);
        this.G.E();
        object = new com.donutsmp.teams.A.A(this);
        this.getCommand("team").setExecutor((CommandExecutor)object);
        this.getCommand("team").setTabCompleter((TabCompleter)object);
        this.getCommand("teamsettings").setExecutor((CommandExecutor)object);
        this.getCommand("teamsettings").setTabCompleter((TabCompleter)object);
        this.getCommand("donutteamsreload").setExecutor((CommandExecutor)object);
        this.getServer().getPluginManager().registerEvents((Listener)new com.donutsmp.teams.F.A(this), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new B(this), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new D(this), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new E(this), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new C(this), (Plugin)this);
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            this.getLogger().info("PlaceholderAPI found! Registering placeholders...");
            this.E = new com.donutsmp.teams.C.A(this);
            this.E.register();
        } else {
            this.getLogger().warning("PlaceholderAPI not found, placeholders will not be available.");
        }
        this.getLogger().info("DonutTeams has been enabled!");
    }

    public void onDisable() {
        this.getLogger().info("DonutTeams disabling. Saving data...");
        if (this.E != null) {
            try {
                this.E.unregister();
            } catch (Exception exception) {
                this.getLogger().log(Level.WARNING, "Error unregistering PAPI", exception);
            }
        }
        if (this.G != null) {
            this.G.D();
            this.G.A();
        }
        this.getLogger().info("DonutTeams has been disabled.");
    }

    public com.donutsmp.teams.E.C getTeamManager() {
        return this.G;
    }

    public com.donutsmp.teams.E.B getEnderChestManager() {
        return this.C;
    }

    public FileConfiguration getMessagesConfig() {
        if (this.B == null) {
            this.reloadMessages();
        }
        return this.B;
    }

    public void reloadMessages() {
        if (this.F == null) {
            this.F = new File(this.getDataFolder(), "messages.yml");
        }
        this.B = YamlConfiguration.loadConfiguration((File)this.F);
        InputStream inputStream = this.getResource("messages.yml");
        if (inputStream != null) {
            try (InputStreamReader inputStreamReader = new InputStreamReader(inputStream, StandardCharsets.UTF_8);){
                YamlConfiguration yamlConfiguration = YamlConfiguration.loadConfiguration((Reader)inputStreamReader);
                this.B.setDefaults((Configuration)yamlConfiguration);
                this.B.options().copyDefaults(true);
                this.saveMessages();
            } catch (IOException iOException) {
                this.getLogger().log(Level.SEVERE, "Could not load default messages.yml from JAR", iOException);
            }
        } else {
            this.getLogger().severe("!!! Default messages.yml NOT FOUND in JAR!");
        }
    }

    public void saveMessages() {
        if (this.B == null || this.F == null) {
            return;
        }
        try {
            this.getMessagesConfig().save(this.F);
        } catch (IOException iOException) {
            this.getLogger().log(Level.SEVERE, "Could not save messages config to " + String.valueOf(this.F), iOException);
        }
    }

    public void loadMessages() {
        if (!this.getDataFolder().exists()) {
            this.getDataFolder().mkdirs();
        }
        if (this.F == null) {
            this.F = new File(this.getDataFolder(), "messages.yml");
        }
        if (!this.F.exists()) {
            this.saveResource("messages.yml", false);
        }
        this.reloadMessages();
    }

    public String getRawMsg(String string, String ... stringArray) {
        String string2 = this.getMessagesConfig().getString(string);
        if (string2 == null) {
            string2 = this.getConfig().getString(string);
        }
        if (string2 == null) {
            this.getLogger().warning("Missing message key: " + string);
            return "&cError: Missing msg for '" + string + "'";
        }
        for (int i = 0; i < stringArray.length; i += 2) {
            if (i + 1 >= stringArray.length || stringArray[i] == null || stringArray[i + 1] == null) continue;
            string2 = string2.replace(stringArray[i], stringArray[i + 1]);
        }
        return string2;
    }

    public String getLegacyMsg(String string, String ... stringArray) {
        String string2 = this.getRawMsg(string, stringArray);
        return Teams.colorize(string2);
    }

    public void sendMessage(CommandSender commandSender, String string, String ... stringArray) {
        if (commandSender == null) {
            return;
        }
        commandSender.sendMessage(this.getLegacyMsg(string, stringArray));
    }

    public void sendMessage(CommandSender commandSender, String string) {
        if (commandSender == null) {
            return;
        }
        commandSender.sendMessage(Teams.colorize(string));
    }

    public void sendPrefixedMessage(CommandSender commandSender, String string, String ... stringArray) {
        if (commandSender == null) {
            return;
        }
        String string2 = this.getLegacyMsg("prefix", "&b[DonutTeams] &f");
        String string3 = this.getLegacyMsg(string, stringArray);
        commandSender.sendMessage(string2 + string3);
    }

    public void broadcastMessage(String string, String ... stringArray) {
        String string2 = this.getLegacyMsg(string, stringArray);
        Bukkit.broadcastMessage((String)string2);
    }

    public void updatePlaceholders() {
        if (this.E != null && Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), (String)("papi ecloud download " + this.E.getIdentifier()));
            this.E.register();
        }
    }

    public A getPlayerSortPreference(Player player) {
        return this.A.getOrDefault(player.getUniqueId(), com.donutsmp.teams.B.A.C);
    }

    public void setPlayerSortPreference(Player player, A a) {
        if (player != null) {
            this.A.put(player.getUniqueId(), a);
        }
    }

    public static String stripColorCodes(String string) {
        if (string == null) {
            return null;
        }
        String string2 = Teams.colorize(string);
        return ChatColor.stripColor((String)string2);
    }
}

