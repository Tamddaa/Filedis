/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.ChatMessageType
 *  net.md_5.bungee.api.chat.TextComponent
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Location
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.util.StringUtil
 */
package com.donutsmp.teams.A;

import com.donutsmp.teams.D.B;
import com.donutsmp.teams.E.C;
import com.donutsmp.teams.E.D;
import com.donutsmp.teams.Teams;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;
import java.util.stream.Collectors;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.util.StringUtil;

public class A
implements CommandExecutor,
TabCompleter {
    private final Teams A;
    private final C B;

    public A(Teams teams) {
        this.A = teams;
        this.B = teams.getTeamManager();
    }

    private boolean A(String string) {
        if (!this.A.getConfig().getBoolean("name_filter.enabled", true)) {
            return false;
        }
        String string2 = string.toLowerCase().replaceAll("[^a-z0-9]", "");
        List list = this.A.getConfig().getStringList("name_filter.blacklist");
        if (list == null) {
            return false;
        }
        for (String string3 : list) {
            if (!string2.contains(string3.toLowerCase())) continue;
            return true;
        }
        return false;
    }

    public boolean onCommand(CommandSender commandSender, Command command, String string, String[] stringArray) {
        String string2;
        if (command.getName().equalsIgnoreCase("donutteamsreload")) {
            if (!commandSender.hasPermission("donutsmp.teams.reload")) {
                this.A.sendPrefixedMessage(commandSender, "no_permission", new String[0]);
                return true;
            }
            this.A.reloadConfig();
            this.A.loadMessages();
            this.A.sendPrefixedMessage(commandSender, "plugin_reloaded", new String[0]);
            return true;
        }
        if (!(commandSender instanceof Player)) {
            commandSender.sendMessage(this.A.getLegacyMsg("player_only_command", new String[0]));
            return true;
        }
        Player player = (Player)commandSender;
        if (command.getName().equalsIgnoreCase("teamsettings")) {
            if (!player.hasPermission("donutsmp.teams.settings")) {
                this.A.sendPrefixedMessage((CommandSender)player, "no_permission", new String[0]);
                return true;
            }
            com.donutsmp.teams.E.A a = this.B.K(player);
            if (a == null) {
                this.A.sendPrefixedMessage((CommandSender)player, "not_in_a_team", new String[0]);
                return true;
            }
            if (!a.F(player.getUniqueId())) {
                this.A.sendPrefixedMessage((CommandSender)player, "must_be_owner", new String[0]);
                return true;
            }
            new B(this.A, this.B, player).A(player);
            return true;
        }
        if (stringArray.length == 0) {
            if (this.B.G(player)) {
                try {
                    new com.donutsmp.teams.D.C(this.A).B(player);
                } catch (Exception exception) {
                    player.sendMessage(String.valueOf(ChatColor.RED) + "An error occurred trying to open the team menu.");
                    this.A.getLogger().log(Level.SEVERE, "Error opening TeamGUI for " + player.getName(), exception);
                }
            } else {
                this.A.sendPrefixedMessage((CommandSender)player, "no_team_gui_error", new String[0]);
            }
            return true;
        }
        block19 : switch (string2 = stringArray[0].toLowerCase()) {
            case "create": {
                if (!player.hasPermission("donutsmp.teams.create")) {
                    this.A.sendPrefixedMessage((CommandSender)player, "no_permission", new String[0]);
                    return true;
                }
                if (stringArray.length < 2) {
                    player.sendMessage("\u00a7cUsage: /team create <name>");
                    return true;
                }
                if (this.B.G(player)) {
                    this.A.sendPrefixedMessage((CommandSender)player, "already_in_team", new String[0]);
                    return true;
                }
                String string3 = String.join((CharSequence)" ", Arrays.copyOfRange(stringArray, 1, stringArray.length));
                String string4 = Teams.stripColorCodes(string3);
                if (string4.trim().isEmpty()) {
                    this.A.sendPrefixedMessage((CommandSender)player, "invalid_team_name", new String[0]);
                    return true;
                }
                if (this.A(string4)) {
                    this.A.sendPrefixedMessage((CommandSender)player, "invalid_team_name_offensive", new String[0]);
                    return true;
                }
                if (this.B.A(string4) != null) {
                    this.A.sendPrefixedMessage((CommandSender)player, "team_name_taken", new String[0]);
                    return true;
                }
                com.donutsmp.teams.E.A a = this.B.A(string3, player);
                if (a == null) {
                    this.A.sendPrefixedMessage((CommandSender)player, "team_name_taken", new String[0]);
                    return true;
                }
                String string5 = this.A.getLegacyMsg("team_created_actionbar", new String[0]);
                player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText((String)string5));
                this.A.sendMessage((CommandSender)player, "team_created");
                if (!this.A.getConfig().getBoolean("broadcasts.team-create.enabled")) break;
                this.A.broadcastMessage("broadcast_team_created", "%player%", player.getName(), "%team_name%", string3);
                break;
            }
            case "info": {
                com.donutsmp.teams.E.A a = this.B.K(player);
                if (a == null) {
                    this.A.sendPrefixedMessage((CommandSender)player, "not_in_a_team", new String[0]);
                    return true;
                }
                this.A.sendMessage((CommandSender)player, "&8&m----------------------------------");
                this.A.sendMessage((CommandSender)player, "&dTeam Info: &r" + a.I());
                OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((UUID)a.K());
                this.A.sendMessage((CommandSender)player, "&dOwner: &f" + (offlinePlayer.getName() != null ? offlinePlayer.getName() : "Unknown"));
                StringBuilder stringBuilder = new StringBuilder();
                int n = 0;
                ArrayList<UUID> arrayList = new ArrayList<UUID>(a.H());
                arrayList.sort(Comparator.comparing(uUID -> {
                    OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((UUID)uUID);
                    return offlinePlayer.getName() != null ? offlinePlayer.getName().toLowerCase() : "";
                }));
                for (UUID uUID2 : arrayList) {
                    OfflinePlayer offlinePlayer2 = Bukkit.getOfflinePlayer((UUID)uUID2);
                    stringBuilder.append(offlinePlayer2.getName() != null ? offlinePlayer2.getName() : "Unknown").append(", ");
                    ++n;
                }
                if (n > 0) {
                    this.A.sendMessage((CommandSender)player, "&dMembers (&f" + n + "&d): &f" + stringBuilder.substring(0, stringBuilder.length() - 2));
                } else {
                    this.A.sendMessage((CommandSender)player, "&dMembers (&f0&d): &f-");
                }
                this.A.sendMessage((CommandSender)player, "&dTeam PvP: " + (a.F() ? this.A.getLegacyMsg("pvp_status_on", new String[0]) : this.A.getLegacyMsg("pvp_status_off", new String[0])));
                this.A.sendMessage((CommandSender)player, "&8&m----------------------------------");
                break;
            }
            case "join": {
                if (stringArray.length < 2) {
                    player.sendMessage(String.valueOf(ChatColor.RED) + "Usage: /team join <teamName>");
                    return true;
                }
                String string6 = String.join((CharSequence)" ", Arrays.copyOfRange(stringArray, 1, stringArray.length));
                com.donutsmp.teams.E.A a = this.B.A(string6);
                if (a == null) {
                    this.A.sendPrefixedMessage((CommandSender)player, "team_not_found", "%team_name%", string6);
                    return true;
                }
                if (!a.E()) {
                    this.A.sendPrefixedMessage((CommandSender)player, "invites_disabled_team", "%team_name%", a.I());
                    return true;
                }
                if (!this.B.C(player, a.I())) {
                    this.A.sendPrefixedMessage((CommandSender)player, "no_pending_invite", new String[0]);
                    return true;
                }
                if (this.B.G(player)) {
                    this.A.sendPrefixedMessage((CommandSender)player, "already_in_team", new String[0]);
                    return true;
                }
                this.B.H(player);
                this.B.B(player, a.I());
                this.A.sendMessage((CommandSender)player, "invite_accepted", "%team_name%", a.I());
                for (UUID uUID3 : a.H()) {
                    Player player2 = Bukkit.getPlayer((UUID)uUID3);
                    if (player2 == null || !player2.isOnline() || player2.equals((Object)player)) continue;
                    this.A.sendMessage((CommandSender)player2, "player_joined", "%player%", player.getName());
                }
                break;
            }
            case "disband": {
                com.donutsmp.teams.E.A a = this.B.K(player);
                if (a == null) {
                    this.A.sendPrefixedMessage((CommandSender)player, "not_in_a_team", new String[0]);
                    return true;
                }
                if (!a.F(player.getUniqueId())) {
                    this.A.sendPrefixedMessage((CommandSender)player, "must_be_owner", new String[0]);
                    return true;
                }
                String string7 = a.I();
                this.B.A(a);
                this.A.sendPrefixedMessage((CommandSender)player, "team_disbanded", "%team_name%", string7);
                break;
            }
            case "invite": {
                com.donutsmp.teams.E.A a = this.B.K(player);
                if (a == null) {
                    this.A.sendPrefixedMessage((CommandSender)player, "not_in_a_team", new String[0]);
                    return true;
                }
                D d = a.D(player.getUniqueId());
                if (!(a.F(player.getUniqueId()) || d != null && d.D())) {
                    this.A.sendPrefixedMessage((CommandSender)player, "no_permission_manage", new String[0]);
                    return true;
                }
                if (stringArray.length < 2) {
                    player.sendMessage(String.valueOf(ChatColor.RED) + "Usage: /team invite <player>");
                    return true;
                }
                Player player3 = Bukkit.getPlayer((String)stringArray[1]);
                if (player3 == null) {
                    this.A.sendPrefixedMessage((CommandSender)player, "player_not_found", new String[0]);
                    return true;
                }
                if (this.B.G(player3)) {
                    com.donutsmp.teams.E.A a2 = this.B.K(player3);
                    if (a2 != null && !a2.E()) {
                        this.A.sendPrefixedMessage((CommandSender)player, "invites_disabled_team", "%team_name%", a2.I());
                        return true;
                    }
                    if (a2 != null && a2.equals(a)) {
                        this.A.sendPrefixedMessage((CommandSender)player, "player_not_in_your_team", new String[0]);
                        return true;
                    }
                }
                if (this.B.G(player3)) {
                    this.A.sendPrefixedMessage((CommandSender)player, "already_in_team", new String[0]);
                    return true;
                }
                this.B.A(player3, a);
                this.A.sendPrefixedMessage((CommandSender)player, "invite_sent", "%player%", player3.getName());
                this.A.sendPrefixedMessage((CommandSender)player3, "invite_received", "%player%", player.getName(), "%team_name%", a.I());
                break;
            }
            case "kick": {
                com.donutsmp.teams.E.A a = this.B.K(player);
                if (a == null) {
                    this.A.sendPrefixedMessage((CommandSender)player, "not_in_a_team", new String[0]);
                    return true;
                }
                D d = a.D(player.getUniqueId());
                if (!(a.F(player.getUniqueId()) || d != null && d.D())) {
                    this.A.sendPrefixedMessage((CommandSender)player, "no_permission_manage", new String[0]);
                    return true;
                }
                if (stringArray.length < 2) {
                    player.sendMessage(String.valueOf(ChatColor.RED) + "Usage: /team kick <player>");
                    return true;
                }
                OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((String)stringArray[1]);
                if (!offlinePlayer.hasPlayedBefore() && !offlinePlayer.isOnline()) {
                    this.A.sendPrefixedMessage((CommandSender)player, "player_not_found", new String[0]);
                    return true;
                }
                if (!a.E(offlinePlayer.getUniqueId())) {
                    this.A.sendPrefixedMessage((CommandSender)player, "player_not_in_your_team", new String[0]);
                    return true;
                }
                if (offlinePlayer.getUniqueId().equals(player.getUniqueId())) {
                    this.A.sendPrefixedMessage((CommandSender)player, "cannot_kick_self", new String[0]);
                    return true;
                }
                if (a.F(offlinePlayer.getUniqueId()) && !a.F(player.getUniqueId())) {
                    this.A.sendPrefixedMessage((CommandSender)player, "no_permission", new String[0]);
                    return true;
                }
                Player player4 = offlinePlayer.getPlayer();
                this.B.A(offlinePlayer.getUniqueId());
                this.A.sendPrefixedMessage((CommandSender)player, "player_kicked", "%player%", offlinePlayer.getName());
                if (player4 == null) break;
                this.A.sendPrefixedMessage((CommandSender)player4, "you_were_kicked", "%team_name%", a.I());
                break;
            }
            case "leave": {
                com.donutsmp.teams.E.A a = this.B.K(player);
                if (a == null) {
                    this.A.sendPrefixedMessage((CommandSender)player, "not_in_a_team", new String[0]);
                    return true;
                }
                String string8 = player.getName();
                HashSet<UUID> hashSet = new HashSet<UUID>(a.H());
                this.B.E(player);
                this.A.sendPrefixedMessage((CommandSender)player, "you_left_team", new String[0]);
                hashSet.remove(player.getUniqueId());
                for (UUID uUID4 : hashSet) {
                    Player player5 = Bukkit.getPlayer((UUID)uUID4);
                    if (player5 == null || !player5.isOnline()) continue;
                    this.A.sendPrefixedMessage((CommandSender)player5, "player_left", "%player%", string8);
                }
                break;
            }
            case "sethome": {
                com.donutsmp.teams.E.A a = this.B.K(player);
                if (a == null) {
                    this.A.sendPrefixedMessage((CommandSender)player, "not_in_a_team", new String[0]);
                    return true;
                }
                D d = a.D(player.getUniqueId());
                if (!(a.F(player.getUniqueId()) || d != null && d.A())) {
                    this.A.sendPrefixedMessage((CommandSender)player, "no_permission_home", new String[0]);
                    return true;
                }
                a.A(player.getLocation());
                this.A.sendPrefixedMessage((CommandSender)player, "home_set", new String[0]);
                break;
            }
            case "delhome": {
                com.donutsmp.teams.E.A a = this.B.K(player);
                if (a == null) {
                    this.A.sendPrefixedMessage((CommandSender)player, "not_in_a_team", new String[0]);
                    return true;
                }
                D d = a.D(player.getUniqueId());
                if (!(a.F(player.getUniqueId()) || d != null && d.A())) {
                    this.A.sendPrefixedMessage((CommandSender)player, "no_permission_home", new String[0]);
                    return true;
                }
                if (a.B() == null) {
                    this.A.sendPrefixedMessage((CommandSender)player, "no_home_set", new String[0]);
                    return true;
                }
                a.A((Location)null);
                this.A.sendPrefixedMessage((CommandSender)player, "home_deleted", new String[0]);
                break;
            }
            case "home": {
                com.donutsmp.teams.E.A a = this.B.K(player);
                if (a == null) {
                    this.A.sendPrefixedMessage((CommandSender)player, "not_in_a_team", new String[0]);
                    return true;
                }
                D d = a.D(player.getUniqueId());
                if (!(a.F(player.getUniqueId()) || d != null && d.B())) {
                    this.A.sendPrefixedMessage((CommandSender)player, "no_permission_visit_home", new String[0]);
                    return true;
                }
                if (a.B() == null) {
                    this.A.sendPrefixedMessage((CommandSender)player, "no_home_set", new String[0]);
                    return true;
                }
                this.B.J(player);
                break;
            }
            case "chat": {
                com.donutsmp.teams.E.A a = this.B.K(player);
                if (a == null) {
                    this.A.sendPrefixedMessage((CommandSender)player, "not_in_a_team", new String[0]);
                    return true;
                }
                D d = a.D(player.getUniqueId());
                if (d == null || !d.F()) {
                    this.A.sendPrefixedMessage((CommandSender)player, "no_permission_chat", new String[0]);
                    return true;
                }
                if (stringArray.length == 1) {
                    boolean bl = this.B.A(player);
                    this.A.sendPrefixedMessage((CommandSender)player, bl ? "team_chat_enabled" : "team_chat_disabled", new String[0]);
                    break;
                }
                String string9 = String.join((CharSequence)" ", Arrays.copyOfRange(stringArray, 1, stringArray.length));
                this.B.A(player, string9);
                break;
            }
            case "rename": {
                if (!player.hasPermission("donutsmp.teams.rename")) {
                    this.A.sendPrefixedMessage((CommandSender)player, "no_permission", new String[0]);
                    return true;
                }
                com.donutsmp.teams.E.A a = this.B.K(player);
                if (a == null) {
                    this.A.sendPrefixedMessage((CommandSender)player, "not_in_a_team", new String[0]);
                    return true;
                }
                if (!a.F(player.getUniqueId())) {
                    this.A.sendPrefixedMessage((CommandSender)player, "must_be_owner", new String[0]);
                    return true;
                }
                if (stringArray.length < 2) {
                    player.sendMessage(String.valueOf(ChatColor.RED) + "Usage: /team rename <new-name>");
                    return true;
                }
                String string10 = String.join((CharSequence)" ", Arrays.copyOfRange(stringArray, 1, stringArray.length));
                String string11 = Teams.stripColorCodes(string10);
                if (string11.trim().isEmpty()) {
                    this.A.sendPrefixedMessage((CommandSender)player, "invalid_team_name", new String[0]);
                    return true;
                }
                if (this.A(string11)) {
                    this.A.sendPrefixedMessage((CommandSender)player, "invalid_team_name_offensive", new String[0]);
                    return true;
                }
                String string12 = a.I();
                if (this.B.A(string11) != null && !string11.equalsIgnoreCase(Teams.stripColorCodes(string12))) {
                    this.A.sendPrefixedMessage((CommandSender)player, "team_name_taken", new String[0]);
                    return true;
                }
                if (!this.B.B(a, string10)) {
                    this.A.sendPrefixedMessage((CommandSender)player, "team_name_taken", new String[0]);
                    return true;
                }
                this.A.getEnderChestManager().B(a.D(), string10);
                this.A.sendPrefixedMessage((CommandSender)player, "team_renamed", "%team_name%", string12, "%new_team_name%", string10);
                break;
            }
            case "enderchest": 
            case "ec": {
                if (!player.hasPermission("donutsmp.teams.enderchest")) {
                    this.A.sendPrefixedMessage((CommandSender)player, "no_permission", new String[0]);
                    return true;
                }
                com.donutsmp.teams.E.A a = this.B.K(player);
                if (a == null) {
                    this.A.sendPrefixedMessage((CommandSender)player, "not_in_a_team", new String[0]);
                    return true;
                }
                Inventory inventory = this.A.getEnderChestManager().C(a.D(), a.I());
                this.A.sendPrefixedMessage((CommandSender)player, "opening_enderchest", new String[0]);
                player.openInventory(inventory);
                break;
            }
            case "ally": {
                String string13;
                if (!this.A.getConfig().getBoolean("features.allies.enabled", true)) {
                    this.A.sendPrefixedMessage((CommandSender)player, "ally_feature_disabled", new String[0]);
                    return true;
                }
                if (!player.hasPermission("donutsmp.teams.ally")) {
                    this.A.sendPrefixedMessage((CommandSender)player, "no_permission", new String[0]);
                    return true;
                }
                com.donutsmp.teams.E.A a = this.B.K(player);
                if (a == null) {
                    this.A.sendPrefixedMessage((CommandSender)player, "not_in_a_team", new String[0]);
                    return true;
                }
                if (stringArray.length < 2) {
                    player.sendMessage(String.valueOf(ChatColor.RED) + "Usage: /team ally <invite|accept|deny|chat>");
                    return true;
                }
                switch (string13 = stringArray[1].toLowerCase()) {
                    case "chat": {
                        if (a.G().isEmpty()) {
                            this.A.sendPrefixedMessage((CommandSender)player, "no_allies_for_chat", new String[0]);
                            return true;
                        }
                        if (stringArray.length == 2) {
                            boolean bl = this.B.I(player);
                            this.A.sendPrefixedMessage((CommandSender)player, bl ? "ally_chat_enabled" : "ally_chat_disabled", new String[0]);
                            break block19;
                        }
                        String string14 = String.join((CharSequence)" ", Arrays.copyOfRange(stringArray, 2, stringArray.length));
                        this.B.D(player, string14);
                        break block19;
                    }
                    case "invite": 
                    case "accept": 
                    case "deny": {
                        if (!a.F(player.getUniqueId())) {
                            this.A.sendPrefixedMessage((CommandSender)player, "not_owner_ally", new String[0]);
                            return true;
                        }
                        if (stringArray.length < 3) {
                            player.sendMessage(String.valueOf(ChatColor.RED) + "Usage: /team ally " + string13 + " <teamName>");
                            return true;
                        }
                        String string15 = String.join((CharSequence)" ", Arrays.copyOfRange(stringArray, 2, stringArray.length));
                        com.donutsmp.teams.E.A a3 = this.B.A(string15);
                        if (a3 == null) {
                            this.A.sendPrefixedMessage((CommandSender)player, "team_not_found", "%team_name%", string15);
                            return true;
                        }
                        if (a3.equals(a)) {
                            this.A.sendPrefixedMessage((CommandSender)player, "cannot_ally_self", new String[0]);
                            return true;
                        }
                        if (string13.equals("invite")) {
                            if (a.I(a3.D())) {
                                this.A.sendPrefixedMessage((CommandSender)player, "already_allies", "%team_name%", a3.I());
                                return true;
                            }
                            if (!a3.A()) {
                                this.A.sendPrefixedMessage((CommandSender)player, "invites_disabled_sender", "%team_name%", a3.I());
                                return true;
                            }
                            this.B.C(a, a3);
                            this.A.sendPrefixedMessage((CommandSender)player, "ally_invite_sent", "%team_name%", a3.I());
                            break block19;
                        }
                        if (string13.equals("accept")) {
                            if (!this.B.A(a.D(), a3.D())) {
                                this.A.sendPrefixedMessage((CommandSender)player, "ally_invite_not_found", "%team_name%", a3.I());
                                return true;
                            }
                            this.B.A(a, a3);
                            break block19;
                        }
                        if (!this.B.A(a.D(), a3.D())) {
                            this.A.sendPrefixedMessage((CommandSender)player, "ally_invite_not_found", "%team_name%", a3.I());
                            return true;
                        }
                        this.B.B(a, a3);
                        break block19;
                    }
                }
                player.sendMessage(String.valueOf(ChatColor.RED) + "Usage: /team ally <invite|accept|deny|chat>");
                break;
            }
            case "admin": {
                if (!player.hasPermission("donutsmp.teams.admin")) {
                    this.A.sendPrefixedMessage((CommandSender)player, "no_permission", new String[0]);
                    return true;
                }
                if (stringArray.length < 3) {
                    player.sendMessage(String.valueOf(ChatColor.RED) + "Usage: /team admin <ec|rename|disband|pvp> <team-name> [new-name|on|off]");
                    return true;
                }
                String string16 = stringArray[1].toLowerCase();
                ArrayList<String> arrayList = new ArrayList<String>();
                int n = 3;
                if (string16.equals("rename") || string16.equals("pvp")) {
                    int n2 = n = stringArray.length > 3 ? 3 : -1;
                    if (string16.equals("rename") && stringArray.length > 3) {
                        n = stringArray.length - 1;
                        arrayList.addAll(Arrays.asList(stringArray).subList(2, n));
                    } else if (string16.equals("pvp") && stringArray.length > 3) {
                        n = stringArray.length - 1;
                        arrayList.addAll(Arrays.asList(stringArray).subList(2, n));
                    } else {
                        arrayList.addAll(Arrays.asList(stringArray).subList(2, stringArray.length));
                        n = -1;
                    }
                } else {
                    arrayList.addAll(Arrays.asList(stringArray).subList(2, stringArray.length));
                    n = -1;
                }
                String string17 = String.join((CharSequence)" ", arrayList);
                String string18 = Teams.stripColorCodes(string17);
                com.donutsmp.teams.E.A a = this.B.A(string18);
                if (a == null) {
                    this.A.sendPrefixedMessage((CommandSender)player, "team_not_found", "%team_name%", string17);
                    return true;
                }
                switch (string16) {
                    case "ec": 
                    case "enderchest": {
                        Inventory inventory = this.A.getEnderChestManager().C(a.D(), a.I());
                        this.A.sendPrefixedMessage((CommandSender)player, "admin_opening_ec", "%team_name%", a.I());
                        player.openInventory(inventory);
                        break block19;
                    }
                    case "rename": {
                        if (n == -1 || n >= stringArray.length) {
                            player.sendMessage(String.valueOf(ChatColor.RED) + "Usage: /team admin rename <team-name> <new-name>");
                            return true;
                        }
                        String string19 = stringArray[n];
                        String string20 = Teams.stripColorCodes(string19);
                        if (string20.trim().isEmpty()) {
                            this.A.sendPrefixedMessage((CommandSender)player, "invalid_team_name", new String[0]);
                            return true;
                        }
                        String string21 = a.I();
                        if (this.B.A(string20) != null && !string20.equalsIgnoreCase(Teams.stripColorCodes(string21))) {
                            this.A.sendPrefixedMessage((CommandSender)player, "team_name_taken", new String[0]);
                            return true;
                        }
                        if (!this.B.B(a, string19)) {
                            this.A.sendPrefixedMessage((CommandSender)player, "team_name_taken", new String[0]);
                            return true;
                        }
                        this.A.getEnderChestManager().B(a.D(), string19);
                        this.A.sendPrefixedMessage((CommandSender)player, "team_renamed", "%team_name%", string21, "%new_team_name%", string19);
                        break block19;
                    }
                    case "disband": {
                        String string22 = a.I();
                        this.B.A(a);
                        this.A.sendPrefixedMessage((CommandSender)player, "team_disbanded", "%team_name%", string22);
                        break block19;
                    }
                    case "pvp": {
                        if (n == -1 || n >= stringArray.length || !stringArray[n].equalsIgnoreCase("on") && !stringArray[n].equalsIgnoreCase("off")) {
                            player.sendMessage(String.valueOf(ChatColor.RED) + "Usage: /team admin pvp <team-name> <on|off>");
                            return true;
                        }
                        boolean bl = stringArray[n].equalsIgnoreCase("on");
                        a.A(bl);
                        this.A.sendPrefixedMessage((CommandSender)player, bl ? "pvp_toggled_on" : "pvp_toggled_off", new String[0]);
                        break block19;
                    }
                }
                this.A.sendPrefixedMessage((CommandSender)player, "admin_unknown_command", new String[0]);
                break;
            }
            default: {
                this.A.sendPrefixedMessage((CommandSender)player, "unknown_command", new String[0]);
            }
        }
        return true;
    }

    public List<String> onTabComplete(CommandSender commandSender, Command command, String string2, String[] stringArray) {
        if (!(commandSender instanceof Player)) {
            return Collections.emptyList();
        }
        Player player = (Player)commandSender;
        ArrayList<String> arrayList = new ArrayList<String>();
        List<String> list = Arrays.asList("disband", "invite", "kick", "leave", "sethome", "delhome", "home", "chat", "info", "rename", "ec", "enderchest", "ally");
        List<String> list2 = Arrays.asList("create", "join");
        List<String> list3 = Arrays.asList("admin");
        List<String> list4 = Arrays.asList("ec", "enderchest", "rename", "disband", "pvp");
        List<String> list5 = Arrays.asList("on", "off");
        List<String> list6 = Arrays.asList("invite", "accept", "deny", "chat");
        boolean bl = this.A.getConfig().getBoolean("features.allies.enabled", true);
        if (stringArray.length == 1) {
            String string3 = stringArray[0].toLowerCase();
            if (this.B.G(player)) {
                StringUtil.copyPartialMatches((String)string3, list, arrayList);
                if (!bl) {
                    arrayList.remove("ally");
                }
            } else {
                StringUtil.copyPartialMatches((String)string3, list2, arrayList);
            }
            if (commandSender.hasPermission("donutsmp.teams.admin")) {
                StringUtil.copyPartialMatches((String)string3, list3, arrayList);
            }
        } else if (stringArray.length == 2) {
            String string4 = stringArray[0].toLowerCase();
            String string5 = stringArray[1].toLowerCase();
            if (string4.equals("admin") && commandSender.hasPermission("donutsmp.teams.admin")) {
                StringUtil.copyPartialMatches((String)string5, list4, arrayList);
            } else if (string4.equals("ally") && this.B.G(player) && bl) {
                StringUtil.copyPartialMatches((String)string5, list6, arrayList);
            } else if ((string4.equals("invite") || string4.equals("kick")) && this.B.G(player)) {
                StringUtil.copyPartialMatches((String)string5, (Iterable)Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(string -> !string.equals(player.getName())).collect(Collectors.toList()), arrayList);
            } else if (string4.equals("join") && !this.B.G(player)) {
                StringUtil.copyPartialMatches((String)string5, this.B.B(), arrayList);
            }
        } else if (stringArray.length >= 3) {
            String string6 = stringArray[0].toLowerCase();
            String string7 = stringArray[1].toLowerCase();
            if (string6.equals("admin") && commandSender.hasPermission("donutsmp.teams.admin") && list4.contains(string7)) {
                int n;
                boolean bl2 = string7.equals("rename") || string7.equals("pvp");
                int n2 = n = bl2 ? stringArray.length - 1 : stringArray.length;
                if (stringArray.length == n + 1 && bl2) {
                    if (string7.equals("pvp")) {
                        StringUtil.copyPartialMatches((String)stringArray[stringArray.length - 1].toLowerCase(), list5, arrayList);
                    }
                } else if (stringArray.length <= n) {
                    String string8 = String.join((CharSequence)" ", Arrays.copyOfRange(stringArray, 2, stringArray.length)).toLowerCase();
                    for (String string9 : this.B.B()) {
                        if (!string9.toLowerCase().startsWith(string8)) continue;
                        arrayList.add(string9);
                    }
                }
            } else if (string6.equals("join") && !this.B.G(player)) {
                String string10 = String.join((CharSequence)" ", Arrays.copyOfRange(stringArray, 1, stringArray.length)).toLowerCase();
                for (String string11 : this.B.B()) {
                    if (!string11.toLowerCase().startsWith(string10)) continue;
                    arrayList.add(string11);
                }
            } else if (string6.equals("ally") && bl && (string7.equals("invite") || string7.equals("accept") || string7.equals("deny"))) {
                String string12 = String.join((CharSequence)" ", Arrays.copyOfRange(stringArray, 2, stringArray.length)).toLowerCase();
                String string13 = Teams.stripColorCodes(this.B.K(player).I()).toLowerCase();
                for (String string14 : this.B.B()) {
                    if (string14.equals(string13) || !string14.toLowerCase().startsWith(string12)) continue;
                    arrayList.add(string14);
                }
            }
        }
        Collections.sort(arrayList);
        return arrayList;
    }
}

