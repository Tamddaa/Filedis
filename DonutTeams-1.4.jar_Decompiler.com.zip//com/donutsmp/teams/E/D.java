/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package com.donutsmp.teams.E;

import java.util.HashMap;
import java.util.Map;

public class D {
    public static final String B = "canEditHome";
    public static final String A = "canManageTeammates";
    public static final String C = "canTogglePVP";
    public static final String J = "canVisitHome";
    public static final String E = "canTeamChat";
    private boolean G;
    private boolean F;
    private boolean H;
    private boolean D;
    private boolean I;

    public D() {
        this.G = false;
        this.F = false;
        this.H = false;
        this.D = false;
        this.I = true;
    }

    public D(boolean bl) {
        this.G = bl;
        this.F = bl;
        this.H = bl;
        this.D = true;
        this.I = true;
    }

    public D(Map<String, Object> map) {
        if (map == null) {
            new D();
            return;
        }
        this.G = (Boolean)map.getOrDefault(B, false);
        this.F = (Boolean)map.getOrDefault(A, false);
        this.H = (Boolean)map.getOrDefault(C, false);
        this.D = (Boolean)map.getOrDefault(J, false);
        this.I = (Boolean)map.getOrDefault(E, true);
    }

    public Map<String, Object> E() {
        HashMap<String, Object> hashMap = new HashMap<String, Object>();
        hashMap.put(B, this.G);
        hashMap.put(A, this.F);
        hashMap.put(C, this.H);
        hashMap.put(J, this.D);
        hashMap.put(E, this.I);
        return hashMap;
    }

    public boolean A() {
        return this.G;
    }

    public boolean D() {
        return this.F;
    }

    public boolean C() {
        return this.H;
    }

    public boolean B() {
        return this.D;
    }

    public boolean F() {
        return this.I;
    }

    public void E(boolean bl) {
        this.G = bl;
    }

    public void A(boolean bl) {
        this.F = bl;
    }

    public void C(boolean bl) {
        this.H = bl;
    }

    public void B(boolean bl) {
        this.D = bl;
    }

    public void D(boolean bl) {
        this.I = bl;
    }
}

