/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemStack
 */
package com.donutsmp.teams.E;

import com.donutsmp.teams.E.A;
import com.donutsmp.teams.Teams;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

public class B {
    private final Teams B;
    private final Map<UUID, Inventory> A = new HashMap<UUID, Inventory>();

    public B(Teams teams) {
        this.B = teams;
    }

    public Inventory C(UUID uUID, String string) {
        if (this.A.containsKey(uUID)) {
            return this.A.get(uUID);
        }
        Inventory inventory = this.A(uUID, string);
        this.A.put(uUID, inventory);
        return inventory;
    }

    private Inventory A(UUID uUID, String string) {
        String string2 = this.B.getRawMsg("enderchest_title", "%team_name%", string);
        String string3 = Teams.colorize(string2);
        return Bukkit.createInventory((InventoryHolder)new com.donutsmp.teams.D.A(uUID), (int)54, (String)string3);
    }

    public Inventory B(UUID uUID) {
        return this.A.get(uUID);
    }

    public void A(UUID uUID, ItemStack[] itemStackArray) {
        Object object;
        Inventory inventory = this.A.get(uUID);
        if (inventory == null) {
            this.B.getLogger().warning("Attempted to update contents for non-loaded Ender Chest: " + String.valueOf(uUID) + ". Creating empty instance.");
            object = this.B.getTeamManager().B(uUID);
            if (object != null) {
                inventory = this.A(uUID, ((A)object).I());
                this.A.put(uUID, inventory);
            } else {
                this.B.getLogger().severe("Cannot update EC contents for " + String.valueOf(uUID) + ": Team not found!");
                return;
            }
        }
        object = itemStackArray;
        if (itemStackArray.length > inventory.getSize()) {
            object = Arrays.copyOf(itemStackArray, inventory.getSize());
            this.B.getLogger().warning("Attempted to set contents larger than inventory size for EC " + String.valueOf(uUID) + ". Contents truncated.");
        } else if (itemStackArray.length < inventory.getSize()) {
            object = Arrays.copyOf(itemStackArray, inventory.getSize());
        }
        inventory.setContents((ItemStack[])object);
    }

    public void A(UUID uUID) {
        this.A.remove(uUID);
        this.B.getLogger().info("Removed Ender Chest from memory for team " + String.valueOf(uUID));
    }

    public void B(UUID uUID, String string) {
        Inventory inventory = this.A.get(uUID);
        if (inventory != null) {
            Inventory inventory2 = this.A(uUID, string);
            inventory2.setContents(inventory.getContents());
            this.A.put(uUID, inventory2);
        }
    }
}

