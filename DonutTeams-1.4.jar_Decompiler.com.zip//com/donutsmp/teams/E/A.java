/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 */
package com.donutsmp.teams.E;

import com.donutsmp.teams.E.D;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Location;

public class A {
    private final UUID F;
    private String A;
    private UUID B;
    private final Map<UUID, D> E;
    private Location G;
    private boolean J;
    private final Set<UUID> I;
    private boolean H = true;
    private boolean D = true;
    private boolean C = false;

    public A(String string, UUID uUID, UUID uUID2) {
        this.A = string;
        this.B = uUID;
        this.F = uUID2;
        this.E = new HashMap<UUID, D>();
        this.E.put(uUID, new D(true));
        this.G = null;
        this.J = false;
        this.I = new HashSet<UUID>();
    }

    public UUID D() {
        return this.F;
    }

    public String I() {
        return this.A;
    }

    public UUID K() {
        return this.B;
    }

    public Set<UUID> H() {
        return this.E.keySet();
    }

    public Map<UUID, D> C() {
        return this.E;
    }

    public D D(UUID uUID) {
        return this.E.get(uUID);
    }

    public Location B() {
        return this.G;
    }

    public boolean F() {
        return this.J;
    }

    public Set<UUID> G() {
        return this.I;
    }

    public boolean A() {
        return this.H;
    }

    public boolean E() {
        return this.D;
    }

    public boolean J() {
        return this.C;
    }

    public void A(String string) {
        this.A = string;
    }

    public void H(UUID uUID) {
        if (this.E.containsKey(this.B)) {
            this.E.put(this.B, new D(false));
        }
        this.B = uUID;
        this.E.put(uUID, new D(true));
    }

    public void A(Location location) {
        this.G = location;
    }

    public void A(boolean bl) {
        this.J = bl;
    }

    public void B(boolean bl) {
        this.H = bl;
    }

    public void D(boolean bl) {
        this.D = bl;
    }

    public void C(boolean bl) {
        this.C = bl;
    }

    public void G(UUID uUID) {
        this.E.put(uUID, new D(false));
    }

    public void A(UUID uUID, D d) {
        this.E.put(uUID, d);
    }

    public void C(UUID uUID) {
        this.E.remove(uUID);
    }

    public boolean E(UUID uUID) {
        return this.E.containsKey(uUID);
    }

    public boolean F(UUID uUID) {
        return this.B.equals(uUID);
    }

    public void A(UUID uUID) {
        this.I.add(uUID);
    }

    public void B(UUID uUID) {
        this.I.remove(uUID);
    }

    public boolean I(UUID uUID) {
        return this.I.contains(uUID);
    }
}

