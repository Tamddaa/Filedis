/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.ChatMessageType
 *  net.md_5.bungee.api.chat.TextComponent
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.Sound
 *  org.bukkit.command.CommandSender
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package com.donutsmp.teams.E;

import com.donutsmp.teams.E.A;
import com.donutsmp.teams.E.D;
import com.donutsmp.teams.Teams;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Level;
import java.util.stream.Collectors;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class C {
    private final Teams E;
    private final Map<UUID, A> I = new HashMap<UUID, A>();
    private final Map<String, UUID> L = new HashMap<String, UUID>();
    private final Map<UUID, UUID> F = new HashMap<UUID, UUID>();
    private final Map<UUID, String> H = new HashMap<UUID, String>();
    private final Set<UUID> D = new HashSet<UUID>();
    private final Set<UUID> K = new HashSet<UUID>();
    private final Map<UUID, Set<UUID>> J = new HashMap<UUID, Set<UUID>>();
    private final Set<UUID> B = new HashSet<UUID>();
    private final Map<UUID, BukkitTask> C = new HashMap<UUID, BukkitTask>();
    private File G;
    private FileConfiguration A;

    public C(Teams teams) {
        this.E = teams;
        this.G = new File(teams.getDataFolder(), "teams.yml");
    }

    public Map<UUID, BukkitTask> C() {
        return this.C;
    }

    public void D() {
        for (BukkitTask bukkitTask : new HashMap<UUID, BukkitTask>(this.C).values()) {
            bukkitTask.cancel();
        }
        this.C.clear();
        this.E.getLogger().info("Cancelled all active teleport tasks.");
    }

    public void J(final Player player) {
        A a = this.K(player);
        if (a == null) {
            this.E.sendPrefixedMessage((CommandSender)player, "not_in_a_team", new String[0]);
            return;
        }
        D d = a.D(player.getUniqueId());
        if (!(a.F(player.getUniqueId()) || d != null && d.B())) {
            this.E.sendPrefixedMessage((CommandSender)player, "no_permission_visit_home", new String[0]);
            return;
        }
        final Location location = a.B();
        if (location == null) {
            this.E.sendPrefixedMessage((CommandSender)player, "no_home_set", new String[0]);
            return;
        }
        if (this.C.containsKey(player.getUniqueId())) {
            this.E.sendPrefixedMessage((CommandSender)player, "teleport_cooldown_cancel_already", new String[0]);
            return;
        }
        final int n = this.E.getConfig().getInt("teleport_cooldown_seconds", 5);
        this.E.sendPrefixedMessage((CommandSender)player, "teleport_cooldown_start", "%time%", String.valueOf(n));
        BukkitTask bukkitTask = new BukkitRunnable(){
            int C;
            {
                this.C = n;
            }

            public void run() {
                if (!player.isOnline()) {
                    this.cancel();
                    C.this.C.remove(player.getUniqueId());
                    return;
                }
                if (this.C > 0) {
                    String string = C.this.E.getLegacyMsg("teleport_cooldown_timer", "%time%", String.valueOf(this.C));
                    player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText((String)string));
                    player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 1.5f);
                    --this.C;
                } else {
                    player.teleport(location);
                    C.this.E.sendPrefixedMessage((CommandSender)player, "teleport_cooldown_success", new String[0]);
                    player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);
                    C.this.C.remove(player.getUniqueId());
                    this.cancel();
                }
            }
        }.runTaskTimer((Plugin)this.E, 0L, 20L);
        this.C.put(player.getUniqueId(), bukkitTask);
    }

    public A A(String string, Player player) {
        String string2 = Teams.stripColorCodes(string).toLowerCase();
        if (this.L.containsKey(string2)) {
            return null;
        }
        UUID uUID = UUID.randomUUID();
        A a = new A(string, player.getUniqueId(), uUID);
        this.I.put(uUID, a);
        this.L.put(string2, uUID);
        this.F.put(player.getUniqueId(), uUID);
        this.A();
        return a;
    }

    public void A(A a) {
        if (a == null) {
            return;
        }
        String string2 = Teams.stripColorCodes(a.I()).toLowerCase();
        UUID uUID = a.D();
        for (UUID uUID2 : new HashSet<UUID>(a.H())) {
            this.F.remove(uUID2);
        }
        this.I.remove(uUID);
        this.L.remove(string2);
        this.H.values().removeIf(string -> string.equalsIgnoreCase(a.I()));
        this.E.getEnderChestManager().A(uUID);
        this.A();
    }

    public void E() {
        if (!this.G.exists()) {
            this.E.getLogger().info("teams.yml not found, creating new one.");
            try {
                this.G.createNewFile();
            } catch (IOException iOException) {
                this.E.getLogger().log(Level.SEVERE, "Could not create teams.yml!", iOException);
                return;
            }
        }
        this.A = YamlConfiguration.loadConfiguration((File)this.G);
        ConfigurationSection configurationSection = this.A.getConfigurationSection("teams");
        if (configurationSection == null) {
            this.E.getLogger().info("No teams found in teams.yml.");
            return;
        }
        int n = 0;
        for (String string : configurationSection.getKeys(false)) {
            try {
                ItemStack[] itemStackArray;
                ItemStack[] itemStackArray2;
                Object object3;
                Object object22;
                UUID uUID = UUID.fromString(string);
                ConfigurationSection configurationSection2 = configurationSection.getConfigurationSection(string);
                if (configurationSection2 == null) continue;
                String string2 = configurationSection2.getString("name");
                UUID uUID2 = UUID.fromString(configurationSection2.getString("owner"));
                A a = new A(string2, uUID2, uUID);
                a.A(configurationSection2.getBoolean("friendlyFire", false));
                a.D(configurationSection2.getBoolean("allowTeamInvites", true));
                a.B(configurationSection2.getBoolean("allowAllyInvites", true));
                a.C(configurationSection2.getBoolean("chatIsolation", false));
                if (configurationSection2.isConfigurationSection("home")) {
                    a.A(Location.deserialize((Map)configurationSection2.getConfigurationSection("home").getValues(true)));
                }
                List list = configurationSection2.getStringList("allies");
                for (Object object22 : list) {
                    a.A(UUID.fromString((String)object22));
                }
                ConfigurationSection configurationSection3 = configurationSection2.getConfigurationSection("members");
                if (configurationSection3 != null) {
                    for (Object object3 : configurationSection3.getKeys(false)) {
                        itemStackArray2 = UUID.fromString((String)object3);
                        if (itemStackArray2.equals(uUID2)) {
                            itemStackArray = new D(configurationSection3.getConfigurationSection((String)object3).getValues(false));
                            a.C().put(uUID2, (D)itemStackArray);
                        } else {
                            itemStackArray = new D(configurationSection3.getConfigurationSection((String)object3).getValues(false));
                            a.A((UUID)itemStackArray2, (D)itemStackArray);
                        }
                        this.F.put((UUID)itemStackArray2, uUID);
                    }
                }
                object22 = this.E.getEnderChestManager().C(uUID, string2);
                if (configurationSection2.contains("enderchest_contents") && (object3 = configurationSection2.getList("enderchest_contents")) != null) {
                    itemStackArray2 = object3.toArray(new ItemStack[0]);
                    if (itemStackArray2.length == object22.getSize()) {
                        object22.setContents(itemStackArray2);
                    } else {
                        itemStackArray = Arrays.copyOf(itemStackArray2, object22.getSize());
                        object22.setContents(itemStackArray);
                        this.E.getLogger().warning("Mismatched EC size for team " + string2 + "! Data may be truncated.");
                    }
                }
                this.I.put(uUID, a);
                this.L.put(Teams.stripColorCodes(string2).toLowerCase(), uUID);
                ++n;
            } catch (Exception exception) {
                this.E.getLogger().log(Level.WARNING, "Failed to load team with ID: " + string, exception);
            }
        }
        this.E.getLogger().info("Successfully loaded " + n + " teams.");
    }

    public void A() {
        if (this.A == null) {
            this.A = YamlConfiguration.loadConfiguration((File)this.G);
        }
        this.A.set("teams", null);
        ConfigurationSection configurationSection = this.A.createSection("teams");
        for (A a : this.I.values()) {
            ConfigurationSection configurationSection2 = configurationSection.createSection(a.D().toString());
            configurationSection2.set("name", (Object)a.I());
            configurationSection2.set("owner", (Object)a.K().toString());
            configurationSection2.set("friendlyFire", (Object)a.F());
            configurationSection2.set("allowTeamInvites", (Object)a.E());
            configurationSection2.set("allowAllyInvites", (Object)a.A());
            configurationSection2.set("chatIsolation", (Object)a.J());
            if (a.B() != null) {
                configurationSection2.set("home", (Object)a.B().serialize());
            }
            List list = a.G().stream().map(UUID::toString).collect(Collectors.toList());
            configurationSection2.set("allies", list);
            ConfigurationSection configurationSection3 = configurationSection2.createSection("members");
            for (Map.Entry<UUID, D> entry : a.C().entrySet()) {
                configurationSection3.set(entry.getKey().toString(), entry.getValue().E());
            }
            Inventory inventory = this.E.getEnderChestManager().B(a.D());
            if (inventory == null) continue;
            configurationSection2.set("enderchest_contents", (Object)inventory.getContents());
        }
        try {
            this.A.save(this.G);
        } catch (IOException iOException) {
            this.E.getLogger().log(Level.SEVERE, "Could not save teams.yml!", iOException);
        }
    }

    public void D(UUID uUID) {
        Inventory inventory;
        if (this.A == null) {
            this.A = YamlConfiguration.loadConfiguration((File)this.G);
        }
        if ((inventory = this.E.getEnderChestManager().B(uUID)) == null) {
            this.E.getLogger().warning("Tried to save EChest for " + String.valueOf(uUID) + " but it wasn't loaded in memory.");
            return;
        }
        this.A.set("teams." + uUID.toString() + ".enderchest_contents", (Object)inventory.getContents());
        try {
            this.A.save(this.G);
        } catch (IOException iOException) {
            this.E.getLogger().log(Level.SEVERE, "Could not save teams.yml (for EChest update)!", iOException);
        }
    }

    public A K(Player player) {
        if (player == null) {
            return null;
        }
        UUID uUID = this.F.get(player.getUniqueId());
        return uUID != null ? this.I.get(uUID) : null;
    }

    public A A(String string) {
        String string2 = Teams.stripColorCodes(string).toLowerCase();
        UUID uUID = this.L.get(string2);
        return uUID != null ? this.I.get(uUID) : null;
    }

    public A B(UUID uUID) {
        return this.I.get(uUID);
    }

    public A C(UUID uUID) {
        UUID uUID2 = this.F.get(uUID);
        return uUID2 != null ? this.I.get(uUID2) : null;
    }

    public boolean G(Player player) {
        return this.F.containsKey(player.getUniqueId());
    }

    public boolean C(Player player, String string) {
        String string2 = this.H.get(player.getUniqueId());
        return string2 != null && string2.equalsIgnoreCase(string);
    }

    public void H(Player player) {
        this.H.remove(player.getUniqueId());
    }

    public void B(Player player, String string) {
        A a = this.A(string);
        if (a != null) {
            a.G(player.getUniqueId());
            this.F.put(player.getUniqueId(), a.D());
            this.A();
        }
    }

    public void A(Player player, A a) {
        this.H.put(player.getUniqueId(), a.I());
    }

    public void A(UUID uUID) {
        UUID uUID2 = this.F.get(uUID);
        if (uUID2 != null) {
            A a = this.I.get(uUID2);
            if (a != null) {
                a.C(uUID);
                if (a.F(uUID)) {
                    Optional optional = a.H().stream().findFirst();
                    if (optional.isPresent()) {
                        a.H((UUID)optional.get());
                        this.E.getLogger().info("Owner left team " + a.I() + ". New owner is " + String.valueOf(optional.get()));
                    } else {
                        this.E.getLogger().info("Owner left team " + a.I() + ". Disbanding team as it is empty.");
                        this.A(a);
                        return;
                    }
                }
            }
            this.F.remove(uUID);
            this.A();
        }
    }

    public void E(Player player) {
        this.A(player.getUniqueId());
    }

    public boolean A(Player player) {
        UUID uUID = player.getUniqueId();
        if (this.D.contains(uUID)) {
            this.D.remove(uUID);
            return false;
        }
        this.D.add(uUID);
        this.B.remove(uUID);
        return true;
    }

    public void A(Player player, String string) {
        A a = this.K(player);
        if (a == null) {
            return;
        }
        String string2 = this.E.getLegacyMsg("team_chat_format", "%player%", player.getName(), "%message%", string);
        for (UUID uUID : a.H()) {
            Player player2 = Bukkit.getPlayer((UUID)uUID);
            if (player2 == null || !player2.isOnline()) continue;
            player2.sendMessage(string2);
        }
        this.E.getLogger().info("[TeamChat] " + Teams.stripColorCodes(string2));
    }

    public boolean B(A a, String string) {
        String string2 = Teams.stripColorCodes(a.I()).toLowerCase();
        String string3 = Teams.stripColorCodes(string).toLowerCase();
        if (this.L.containsKey(string3) && !string3.equals(string2)) {
            return false;
        }
        a.A(string);
        this.L.remove(string2);
        this.L.put(string3, a.D());
        this.A();
        return true;
    }

    public boolean I(Player player) {
        UUID uUID = player.getUniqueId();
        if (this.B.contains(uUID)) {
            this.B.remove(uUID);
            return false;
        }
        this.B.add(uUID);
        this.D.remove(uUID);
        return true;
    }

    public void D(Player player, String string) {
        Object object;
        A a = this.K(player);
        if (a == null) {
            return;
        }
        String string2 = this.E.getLegacyMsg("ally_chat_format", "%team%", a.I(), "%player%", player.getName(), "%message%", string);
        HashSet<UUID> hashSet = new HashSet<UUID>();
        for (UUID uUID : a.H()) {
            object = Bukkit.getPlayer((UUID)uUID);
            if (object == null || !object.isOnline()) continue;
            object.sendMessage(string2);
            hashSet.add(uUID);
        }
        for (UUID uUID : a.G()) {
            object = this.B(uUID);
            if (object == null) continue;
            for (UUID uUID2 : ((A)object).H()) {
                Player player2;
                if (hashSet.contains(uUID2) || (player2 = Bukkit.getPlayer((UUID)uUID2)) == null || !player2.isOnline()) continue;
                player2.sendMessage(string2);
            }
        }
        this.E.getLogger().info("[AllyChat] " + Teams.stripColorCodes(string2));
    }

    public void C(A a, A a2) {
        Set set = this.J.getOrDefault(a.D(), new HashSet());
        set.add(a2.D());
        this.J.put(a.D(), set);
        Player player = Bukkit.getPlayer((UUID)a2.K());
        if (player != null && player.isOnline()) {
            this.E.sendPrefixedMessage((CommandSender)player, "ally_invite_received", "%team_name%", a.I());
        }
    }

    public boolean A(UUID uUID, UUID uUID2) {
        Set<UUID> set = this.J.get(uUID2);
        return set != null && set.contains(uUID);
    }

    public void A(A a, A a2) {
        if (!this.A(a.D(), a2.D())) {
            return;
        }
        Set<UUID> set = this.J.get(a2.D());
        set.remove(a.D());
        a.A(a2.D());
        a2.A(a.D());
        a.H().stream().map(Bukkit::getPlayer).filter(Objects::nonNull).forEach(player -> this.E.sendPrefixedMessage((CommandSender)player, "ally_accepted_sender", "%team_name%", a2.I()));
        a2.H().stream().map(Bukkit::getPlayer).filter(Objects::nonNull).forEach(player -> this.E.sendPrefixedMessage((CommandSender)player, "ally_accepted_receiver", "%team_name%", a.I()));
        this.A();
    }

    public void B(A a, A a2) {
        Player player;
        if (!this.A(a.D(), a2.D())) {
            return;
        }
        Set<UUID> set = this.J.get(a2.D());
        set.remove(a.D());
        Player player2 = Bukkit.getPlayer((UUID)a.K());
        if (player2 != null && player2.isOnline()) {
            this.E.sendPrefixedMessage((CommandSender)player2, "ally_denied_sender", "%team_name%", a2.I());
        }
        if ((player = Bukkit.getPlayer((UUID)a2.K())) != null && player.isOnline()) {
            this.E.sendPrefixedMessage((CommandSender)player, "ally_denied_receiver", "%team_name%", a.I());
        }
    }

    public Collection<String> B() {
        return this.L.keySet();
    }

    public void B(Player player) {
        this.K.add(player.getUniqueId());
    }

    public boolean B(A a) {
        boolean bl = !a.F();
        a.A(bl);
        this.A();
        return bl;
    }

    public boolean D(Player player) {
        return this.K.contains(player.getUniqueId());
    }

    public void F(Player player) {
        this.K.remove(player.getUniqueId());
    }

    public boolean L(Player player) {
        return this.B.contains(player.getUniqueId());
    }

    public boolean C(Player player) {
        return this.D.contains(player.getUniqueId());
    }
}

