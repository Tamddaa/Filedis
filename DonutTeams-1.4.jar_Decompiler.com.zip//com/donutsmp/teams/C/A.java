/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  me.clip.placeholderapi.expansion.PlaceholderExpansion
 *  org.bukkit.OfflinePlayer
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package com.donutsmp.teams.C;

import com.donutsmp.teams.Teams;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class A
extends PlaceholderExpansion {
    private final Teams A;

    public A(Teams teams) {
        this.A = teams;
    }

    @NotNull
    public String getIdentifier() {
        return "donutsmpteams";
    }

    @NotNull
    public String getAuthor() {
        return this.A.getDescription().getAuthors().toString();
    }

    @NotNull
    public String getVersion() {
        return this.A.getDescription().getVersion();
    }

    public boolean persist() {
        return true;
    }

    public boolean canRegister() {
        return true;
    }

    @Nullable
    public String onRequest(OfflinePlayer offlinePlayer, @NotNull String string) {
        if (offlinePlayer == null) {
            return null;
        }
        if (string.equalsIgnoreCase("team_name")) {
            com.donutsmp.teams.E.A a = this.A.getTeamManager().C(offlinePlayer.getUniqueId());
            if (a != null) {
                return Teams.colorize(a.I());
            }
            return this.A.getLegacyMsg("placeholder_no_team", "&7None");
        }
        return null;
    }
}

