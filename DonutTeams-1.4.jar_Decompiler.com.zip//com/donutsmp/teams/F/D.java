/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryCloseEvent
 */
package com.donutsmp.teams.F;

import com.donutsmp.teams.D.A;
import com.donutsmp.teams.Teams;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;

public class D
implements Listener {
    private final Teams A;

    public D(Teams teams) {
        this.A = teams;
    }

    @EventHandler
    public void A(InventoryCloseEvent inventoryCloseEvent) {
        if (inventoryCloseEvent.getInventory().getHolder() instanceof A) {
            A a = (A)inventoryCloseEvent.getInventory().getHolder();
            Player player = (Player)inventoryCloseEvent.getPlayer();
            this.A.getEnderChestManager().A(a.A(), inventoryCloseEvent.getInventory().getContents());
            this.A.getTeamManager().D(a.A());
        }
    }
}

