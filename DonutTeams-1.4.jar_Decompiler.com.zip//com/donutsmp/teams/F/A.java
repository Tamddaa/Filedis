/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.inventory.InventoryCloseEvent
 *  org.bukkit.inventory.InventoryHolder
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.SkullMeta
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 */
package com.donutsmp.teams.F;

import com.donutsmp.teams.D.B;
import com.donutsmp.teams.E.C;
import com.donutsmp.teams.E.D;
import com.donutsmp.teams.Teams;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

public class A
implements Listener {
    private final Teams B;
    private final C C;
    private final Map<UUID, UUID> A = new HashMap<UUID, UUID>();

    public A(Teams teams) {
        this.B = teams;
        this.C = teams.getTeamManager();
    }

    @EventHandler(priority=EventPriority.LOW)
    public void A(InventoryClickEvent inventoryClickEvent) {
        InventoryHolder inventoryHolder = inventoryClickEvent.getInventory().getHolder();
        if (!(inventoryHolder instanceof com.donutsmp.teams.D.C || inventoryHolder instanceof B || inventoryHolder instanceof com.donutsmp.teams.D.D)) {
            return;
        }
        if (!(inventoryClickEvent.getWhoClicked() instanceof Player)) {
            return;
        }
        inventoryClickEvent.setCancelled(true);
        Player player = (Player)inventoryClickEvent.getWhoClicked();
        ItemStack itemStack = inventoryClickEvent.getCurrentItem();
        if (itemStack == null || itemStack.getType() == Material.AIR) {
            return;
        }
        if (inventoryHolder instanceof com.donutsmp.teams.D.C) {
            if (itemStack.getType() == Material.PLAYER_HEAD && inventoryClickEvent.getSlot() >= 0 && inventoryClickEvent.getSlot() <= 44) {
                this.A(player, itemStack, (com.donutsmp.teams.D.C)inventoryHolder);
            } else if (itemStack.getType() != Material.PLAYER_HEAD && itemStack.getType() != Material.GRAY_STAINED_GLASS_PANE) {
                this.A(inventoryClickEvent, player, itemStack, (com.donutsmp.teams.D.C)inventoryHolder);
            }
        } else if (inventoryHolder instanceof B) {
            this.A(inventoryClickEvent, player, (B)inventoryHolder);
        } else if (inventoryHolder instanceof com.donutsmp.teams.D.D) {
            this.A(inventoryClickEvent, player, (com.donutsmp.teams.D.D)inventoryHolder);
        }
    }

    @EventHandler
    public void A(InventoryCloseEvent inventoryCloseEvent) {
        if (inventoryCloseEvent.getInventory().getHolder() instanceof com.donutsmp.teams.D.D) {
            this.A.remove(inventoryCloseEvent.getPlayer().getUniqueId());
        }
    }

    private void A(Player player, ItemStack itemStack, com.donutsmp.teams.D.C c) {
        boolean bl;
        com.donutsmp.teams.E.A a = c.B();
        if (a == null) {
            return;
        }
        D d = a.D(player.getUniqueId());
        boolean bl2 = bl = a.F(player.getUniqueId()) || d != null && d.D();
        if (!bl) {
            return;
        }
        SkullMeta skullMeta = (SkullMeta)itemStack.getItemMeta();
        if (skullMeta == null) {
            return;
        }
        OfflinePlayer offlinePlayer = skullMeta.getOwningPlayer();
        if (offlinePlayer == null) {
            return;
        }
        if (offlinePlayer.getUniqueId().equals(player.getUniqueId())) {
            return;
        }
        if (a.F(offlinePlayer.getUniqueId())) {
            return;
        }
        new com.donutsmp.teams.D.D(this.B, player, offlinePlayer, a).A(player);
    }

    private void A(InventoryClickEvent inventoryClickEvent, Player player, B b) {
        int n = inventoryClickEvent.getSlot();
        com.donutsmp.teams.E.A a = b.C();
        if (a == null) {
            player.closeInventory();
            return;
        }
        if (!a.F(player.getUniqueId())) {
            player.closeInventory();
            return;
        }
        switch (n) {
            case 3: {
                a.D(!a.E());
                break;
            }
            case 4: {
                a.B(!a.A());
                break;
            }
            case 5: {
                a.C(!a.J());
                break;
            }
            default: {
                return;
            }
        }
        new B(this.B, this.C, player).A(player);
    }

    private void A(InventoryClickEvent inventoryClickEvent, Player player, com.donutsmp.teams.D.D d) {
        int n = inventoryClickEvent.getSlot();
        com.donutsmp.teams.E.A a = d.A();
        OfflinePlayer offlinePlayer = d.B();
        if (a == null || offlinePlayer == null) {
            player.closeInventory();
            return;
        }
        D d2 = a.D(offlinePlayer.getUniqueId());
        if (d2 == null) {
            player.closeInventory();
            this.B.getLogger().severe("Failed to get MemberData for " + offlinePlayer.getName() + " during click event!");
            return;
        }
        UUID uUID = player.getUniqueId();
        UUID uUID2 = offlinePlayer.getUniqueId();
        switch (n) {
            case 10: {
                d2.E(!d2.A());
                break;
            }
            case 11: {
                if (this.A.get(uUID) != null && this.A.get(uUID).equals(uUID2)) {
                    this.A.remove(uUID);
                    player.closeInventory();
                    this.B.getLogger().info(player.getName() + " confirmed kick for " + offlinePlayer.getName());
                    Bukkit.dispatchCommand((CommandSender)player, (String)("team kick " + offlinePlayer.getName()));
                } else {
                    this.A.put(uUID, uUID2);
                    this.B.sendPrefixedMessage((CommandSender)player, "member_kick_confirm", "%player%", offlinePlayer.getName());
                    Bukkit.getScheduler().runTaskLater((Plugin)this.B, () -> this.A.remove(uUID, uUID2), 100L);
                }
                return;
            }
            case 12: {
                d2.A(!d2.D());
                break;
            }
            case 13: {
                d2.C(!d2.C());
                break;
            }
            case 14: {
                d2.B(!d2.B());
                break;
            }
            case 15: {
                d2.D(!d2.F());
                break;
            }
            case 18: {
                new com.donutsmp.teams.D.C(this.B).A(player, 1);
                return;
            }
            default: {
                return;
            }
        }
        this.A.remove(uUID);
        new com.donutsmp.teams.D.D(this.B, player, offlinePlayer, a).A(player);
    }

    private void A(InventoryClickEvent inventoryClickEvent, Player player, ItemStack itemStack, com.donutsmp.teams.D.C c) {
        int n = inventoryClickEvent.getSlot();
        com.donutsmp.teams.E.A a = c.B();
        if (a == null) {
            a = this.C.K(player);
        }
        if (a == null) {
            player.closeInventory();
            this.B.sendPrefixedMessage((CommandSender)player, "not_in_a_team", new String[0]);
            return;
        }
        int n2 = c.A();
        D d = a.D(player.getUniqueId());
        if (n >= 45 && n <= 53) {
            switch (n) {
                case 45: {
                    this.C.B(player);
                    this.B.sendPrefixedMessage((CommandSender)player, "search_prompt", new String[0]);
                    player.closeInventory();
                    break;
                }
                case 46: {
                    com.donutsmp.teams.B.A a2 = this.B.getPlayerSortPreference(player);
                    com.donutsmp.teams.B.A a3 = a2.B();
                    this.B.setPlayerSortPreference(player, a3);
                    c.A(player, n2);
                    this.B.sendPrefixedMessage((CommandSender)player, "sort_changed", "%sort_type%", a3.name());
                    if (a3 != com.donutsmp.teams.B.A.E) break;
                    this.B.sendPrefixedMessage((CommandSender)player, "sort_not_implemented", new String[0]);
                    break;
                }
                case 48: {
                    ItemMeta itemMeta = itemStack.getItemMeta();
                    int n3 = n2;
                    if (itemMeta != null && itemMeta.getPersistentDataContainer().has(com.donutsmp.teams.D.C.C, PersistentDataType.INTEGER)) {
                        n3 = (Integer)itemMeta.getPersistentDataContainer().getOrDefault(com.donutsmp.teams.D.C.C, PersistentDataType.INTEGER, (Object)n2);
                    }
                    if (itemStack.getType() != Material.ARROW || n3 <= 1) break;
                    c.A(player, n3 - 1);
                    break;
                }
                case 49: {
                    c.A(player, n2);
                    break;
                }
                case 50: {
                    ItemMeta itemMeta = itemStack.getItemMeta();
                    int n4 = n2;
                    if (itemMeta != null && itemMeta.getPersistentDataContainer().has(com.donutsmp.teams.D.C.C, PersistentDataType.INTEGER)) {
                        n4 = (Integer)itemMeta.getPersistentDataContainer().getOrDefault(com.donutsmp.teams.D.C.C, PersistentDataType.INTEGER, (Object)n2);
                    }
                    if (itemStack.getType() != Material.ARROW) break;
                    c.A(player, n4 + 1);
                    break;
                }
                case 52: {
                    if (!(a.F(player.getUniqueId()) || d != null && d.B())) {
                        this.B.sendPrefixedMessage((CommandSender)player, "no_permission_visit_home", new String[0]);
                        return;
                    }
                    if (a.B() != null) {
                        player.closeInventory();
                        this.C.J(player);
                        break;
                    }
                    this.B.sendPrefixedMessage((CommandSender)player, "no_home_set", new String[0]);
                    break;
                }
                case 53: {
                    if (!(a.F(player.getUniqueId()) || d != null && d.C())) {
                        this.B.sendPrefixedMessage((CommandSender)player, "no_permission_pvp", new String[0]);
                        return;
                    }
                    boolean bl = this.C.B(a);
                    this.B.sendPrefixedMessage((CommandSender)player, bl ? "pvp_toggled_on" : "pvp_toggled_off", new String[0]);
                    c.A(player, n2);
                }
            }
        }
    }
}

