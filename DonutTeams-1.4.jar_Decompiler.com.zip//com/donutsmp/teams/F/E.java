/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.entity.EntityDamageByEntityEvent
 */
package com.donutsmp.teams.F;

import com.donutsmp.teams.E.A;
import com.donutsmp.teams.E.C;
import com.donutsmp.teams.Teams;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class E
implements Listener {
    private final Teams A;
    private final C B;

    public E(Teams teams) {
        this.A = teams;
        this.B = teams.getTeamManager();
    }

    @EventHandler
    public void A(EntityDamageByEntityEvent entityDamageByEntityEvent) {
        if (!(entityDamageByEntityEvent.getEntity() instanceof Player) || !(entityDamageByEntityEvent.getDamager() instanceof Player)) {
            return;
        }
        Player player = (Player)entityDamageByEntityEvent.getEntity();
        Player player2 = (Player)entityDamageByEntityEvent.getDamager();
        A a = this.B.K(player);
        A a2 = this.B.K(player2);
        if (a != null && a.equals(a2) && !a.F()) {
            entityDamageByEntityEvent.setCancelled(true);
            this.A.sendPrefixedMessage((CommandSender)player2, "pvp_prevented", new String[0]);
        }
    }
}

