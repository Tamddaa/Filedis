/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Sound
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerMoveEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.scheduler.BukkitTask
 */
package com.donutsmp.teams.F;

import com.donutsmp.teams.Teams;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitTask;

public class C
implements Listener {
    private final Teams B;
    private final com.donutsmp.teams.E.C C;
    private final Map<UUID, BukkitTask> A;

    public C(Teams teams) {
        this.B = teams;
        this.C = teams.getTeamManager();
        this.A = this.C.C();
    }

    @EventHandler
    public void A(PlayerMoveEvent playerMoveEvent) {
        Player player = playerMoveEvent.getPlayer();
        UUID uUID = player.getUniqueId();
        if (!this.A.containsKey(uUID)) {
            return;
        }
        Location location = playerMoveEvent.getFrom();
        Location location2 = playerMoveEvent.getTo();
        if (location2 == null || location.getBlockX() != location2.getBlockX() || location.getBlockY() != location2.getBlockY() || location.getBlockZ() != location2.getBlockZ()) {
            BukkitTask bukkitTask = this.A.get(uUID);
            bukkitTask.cancel();
            this.A.remove(uUID);
            this.B.sendPrefixedMessage((CommandSender)player, "teleport_cooldown_cancel_move", new String[0]);
            player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_LAND, 1.0f, 1.0f);
        }
    }

    @EventHandler
    public void A(PlayerQuitEvent playerQuitEvent) {
        Player player = playerQuitEvent.getPlayer();
        UUID uUID = player.getUniqueId();
        if (this.A.containsKey(uUID)) {
            BukkitTask bukkitTask = this.A.get(uUID);
            bukkitTask.cancel();
            this.A.remove(uUID);
        }
    }
}

