/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.AsyncPlayerChatEvent
 */
package com.donutsmp.teams.F;

import com.donutsmp.teams.E.A;
import com.donutsmp.teams.E.C;
import com.donutsmp.teams.E.D;
import com.donutsmp.teams.Teams;
import java.util.ArrayList;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class B
implements Listener {
    private final C B;
    private final Teams A;

    public B(Teams teams) {
        this.A = teams;
        this.B = teams.getTeamManager();
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void A(AsyncPlayerChatEvent asyncPlayerChatEvent) {
        D d;
        Player player2 = asyncPlayerChatEvent.getPlayer();
        A a = this.B.K(player2);
        D d2 = d = a != null ? a.D(player2.getUniqueId()) : null;
        if (this.B.D(player2)) {
            asyncPlayerChatEvent.setCancelled(true);
            this.B.F(player2);
            String string = asyncPlayerChatEvent.getMessage().toLowerCase();
            if (a == null) {
                return;
            }
            ArrayList<String> arrayList = new ArrayList<String>();
            for (UUID object : a.H()) {
                OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((UUID)object);
                if (offlinePlayer.getName() == null || !offlinePlayer.getName().toLowerCase().contains(string)) continue;
                String string2 = offlinePlayer.isOnline() ? this.A.getLegacyMsg("search_status_online", new String[0]) : this.A.getLegacyMsg("search_status_offline", new String[0]);
                arrayList.add(this.A.getLegacyMsg("search_result_format", "%player%", offlinePlayer.getName(), "%status%", string2));
            }
            if (arrayList.isEmpty()) {
                this.A.sendPrefixedMessage((CommandSender)player2, "search_no_results", "%query%", string);
            } else {
                this.A.sendPrefixedMessage((CommandSender)player2, "search_header", "%count%", String.valueOf(arrayList.size()));
                for (String string3 : arrayList) {
                    this.A.sendMessage((CommandSender)player2, string3);
                }
            }
            return;
        }
        if (this.B.L(player2)) {
            asyncPlayerChatEvent.setCancelled(true);
            if (d == null || !d.F()) {
                this.A.sendPrefixedMessage((CommandSender)player2, "no_permission_chat", new String[0]);
                return;
            }
            this.B.D(player2, asyncPlayerChatEvent.getMessage());
            return;
        }
        if (this.B.C(player2)) {
            asyncPlayerChatEvent.setCancelled(true);
            if (d == null || !d.F()) {
                this.A.sendPrefixedMessage((CommandSender)player2, "no_permission_chat", new String[0]);
                return;
            }
            this.B.A(player2, asyncPlayerChatEvent.getMessage());
            return;
        }
        if (a != null && a.J()) {
            asyncPlayerChatEvent.getRecipients().removeIf(player -> {
                A a2 = this.B.K((Player)player);
                if (a2 == null) {
                    return true;
                }
                if (a2.equals(a)) {
                    return false;
                }
                return !a2.I(a.D());
            });
            return;
        }
        asyncPlayerChatEvent.getRecipients().removeIf(player -> {
            A a2 = this.B.K((Player)player);
            if (a2 == null || !a2.J()) {
                return false;
            }
            if (a == null) {
                return true;
            }
            if (a2.equals(a)) {
                return false;
            }
            return !a2.I(a.D());
        });
    }
}

