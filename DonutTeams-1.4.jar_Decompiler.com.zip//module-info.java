/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
/* synthetic */ module com.google.gson {
    // version: 2.10.1

    requires static java.sql;
    requires static jdk.unsupported;

    exports com.google.gson;
    exports com.google.gson.annotations;
    exports com.google.gson.reflect;
    exports com.google.gson.stream;

}

