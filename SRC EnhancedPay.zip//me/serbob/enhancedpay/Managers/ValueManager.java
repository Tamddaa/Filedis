package me.serbob.enhancedpay.Managers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import me.serbob.clickableheads.objectholders.ClickableHead;
import me.serbob.enhancedpay.EnhancedPay;
import me.serbob.enhancedpay.Utils.EconomyUtil;
import me.serbob.enhancedpay.Utils.GlobalUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

public class ValueManager {
   public static int totalPages;
   public static Map<Integer, Map<ClickableHead, Double>> baltopMap = new HashMap();
   public static List<OfflinePlayer> playerData = new ArrayList();
   public static String baltopPlayerTitle;
   public static List<String> baltopPlayerLore;

   public static void loadConfig() {
      baltopPlayerTitle = GlobalUtil.c(EnhancedPay.instance.getConfig().getString("messages.baltop.player.title"));
      baltopPlayerLore = GlobalUtil.colorizeList(EnhancedPay.instance.getConfig().getStringList("messages.baltop.player.lore"));
      playerData = new ArrayList();
      playerData.addAll(Arrays.asList(Bukkit.getOfflinePlayers()));
      int pageSize = 45;
      totalPages = (playerData.size() + pageSize - 1) / pageSize;

      try {
         playerData.sort((player1, player2) -> {
            double balance1 = EnhancedPay.getEconomy().getBalance(player1);
            double balance2 = EnhancedPay.getEconomy().getBalance(player2);
            return Double.compare(balance2, balance1);
         });
      } catch (Exception var14) {
      }

      for(int page = 1; page <= totalPages; ++page) {
         Map<ClickableHead, Double> pageData = new LinkedHashMap();
         int startIndex = (page - 1) * pageSize;
         int endIndex = Math.min(page * pageSize, playerData.size());

         for(int i = startIndex; i < endIndex; ++i) {
            OfflinePlayer offlinePlayer = (OfflinePlayer)playerData.get(i);
            String playerName = offlinePlayer.getName();
            double balance = EnhancedPay.getEconomy().getBalance(offlinePlayer);
            String finalFormat;
            if (EnhancedPay.instance.getConfig().getBoolean("format_money")) {
               finalFormat = EconomyUtil.getFormattedMoney(offlinePlayer);
            } else {
               finalFormat = EnhancedPay.getEconomy().format(balance);
            }

            List<String> temp = new ArrayList();
            Iterator var12 = baltopPlayerLore.iterator();

            while(var12.hasNext()) {
               String key = (String)var12.next();
               temp.add(GlobalUtil.c(key.replace("{balance}", finalFormat)));
            }

            ClickableHead clickableHead = new ClickableHead(offlinePlayer, baltopPlayerTitle.replace("{playerName}", offlinePlayer.getName()), temp);
            pageData.put(clickableHead, balance);
         }

         baltopMap.put(page, pageData);
      }

   }
}
