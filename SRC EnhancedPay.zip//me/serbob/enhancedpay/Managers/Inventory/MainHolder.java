package me.serbob.enhancedpay.Managers.Inventory;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class MainHolder implements InventoryHolder {
   public Inventory getInventory() {
      return null;
   }
}
