package me.serbob.enhancedpay.Managers.Inventory;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import me.serbob.clickableheads.objectholders.ClickableHead;
import me.serbob.enhancedpay.EnhancedPay;
import me.serbob.enhancedpay.Managers.ValueManager;
import me.serbob.enhancedpay.Utils.GlobalUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class InventoryManager {
   public static Map<Player, Integer> currentPage = new HashMap();

   public static void openGUI(Player player, int page) {
      String title = GlobalUtil.c(EnhancedPay.instance.getConfig().getString("gui.title").replace("{currentPage}", page.makeConcatWithConstants<invokedynamic>(page)).replace("{totalPages}", ValueManager.totalPages.makeConcatWithConstants<invokedynamic>(ValueManager.totalPages)));
      Inventory inventory = Bukkit.createInventory(new MainHolder(), 54, title);
      Map<ClickableHead, Double> pageData = (Map)ValueManager.baltopMap.get(page);
      currentPage.putIfAbsent(player, page);
      currentPage.replace(player, page);
      if (pageData != null) {
         int slot = 0;
         Iterator var6 = pageData.keySet().iterator();

         while(var6.hasNext()) {
            ClickableHead clickableHead = (ClickableHead)var6.next();
            ItemStack headItem = clickableHead.getHead();
            inventory.setItem(slot, headItem);
            ++slot;
            if (slot >= inventory.getSize()) {
               break;
            }
         }
      }

      ItemStack arrow = new ItemStack(Material.ARROW);
      ItemMeta arrowMeta;
      if (page - 1 >= 1) {
         arrowMeta = arrow.getItemMeta();
         arrowMeta.setDisplayName(GlobalUtil.c("&r&fPrevious"));
         arrow.setItemMeta(arrowMeta);
         inventory.setItem(48, arrow);
      }

      if (page + 1 <= ValueManager.baltopMap.size()) {
         arrowMeta = arrow.getItemMeta();
         arrowMeta.setDisplayName(GlobalUtil.c("&r&fNext"));
         arrow.setItemMeta(arrowMeta);
         inventory.setItem(50, arrow);
      }

      player.openInventory(inventory);
   }
}
