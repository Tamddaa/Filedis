package me.serbob.enhancedpay.Managers;

import me.serbob.enhancedpay.EnhancedPay;

public class SchedulerManager {
   public static void startBaltopRefresh() {
      EnhancedPay.foliaLib.getScheduler().runTimerAsync(ValueManager::loadConfig, 0L, (long)EnhancedPay.instance.getConfig().getInt("baltop_refresh") * 20L);
   }
}
