package me.serbob.enhancedpay.Managers;

import org.bukkit.Bukkit;

public class VersionManager {
   private static final String[] FUTURE_VERSIONS = new String[]{"1.20.6", "1.21", "1.21.1"};
   private static final VersionManager.VersionInfo SERVER_VERSION = parseServerVersion();

   public static boolean isVersion1_12OrBelow() {
      if (isFutureVersion()) {
         return false;
      } else {
         return SERVER_VERSION.majorVersion < 1 || SERVER_VERSION.majorVersion == 1 && SERVER_VERSION.minorVersion <= 12;
      }
   }

   public static boolean isVersion1_8OrAbove() {
      if (isFutureVersion()) {
         return true;
      } else {
         return SERVER_VERSION.majorVersion > 1 || SERVER_VERSION.majorVersion == 1 && SERVER_VERSION.minorVersion >= 8;
      }
   }

   public static boolean isVersion1_8() {
      if (isFutureVersion()) {
         return false;
      } else {
         return SERVER_VERSION.majorVersion == 1 && SERVER_VERSION.minorVersion == 8;
      }
   }

   private static boolean isFutureVersion() {
      String version = Bukkit.getBukkitVersion();
      String[] var1 = FUTURE_VERSIONS;
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         String futureVersion = var1[var3];
         if (version.startsWith(futureVersion)) {
            return true;
         }
      }

      return false;
   }

   private static VersionManager.VersionInfo parseServerVersion() {
      String bukkitVersion = Bukkit.getBukkitVersion();
      String[] versionParts = bukkitVersion.split("-")[0].split("\\.");
      if (versionParts.length >= 2) {
         try {
            int majorVersion = Integer.parseInt(versionParts[0]);
            int minorVersion = Integer.parseInt(versionParts[1]);
            return new VersionManager.VersionInfo(majorVersion, minorVersion);
         } catch (NumberFormatException var4) {
            return new VersionManager.VersionInfo(1, 0);
         }
      } else {
         return new VersionManager.VersionInfo(1, 0);
      }
   }

   private static class VersionInfo {
      final int majorVersion;
      final int minorVersion;

      VersionInfo(int majorVersion, int minorVersion) {
         this.majorVersion = majorVersion;
         this.minorVersion = minorVersion;
      }
   }
}
