package me.serbob.enhancedpay.Events;

import me.serbob.clickableheads.Managers.gui.TemplateGUI;
import me.serbob.clickableheads.objectholders.ClickableHead;
import me.serbob.enhancedpay.EnhancedPay;
import me.serbob.enhancedpay.Managers.Inventory.InventoryManager;
import me.serbob.enhancedpay.Managers.Inventory.MainHolder;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

public class BaltopEvent implements Listener {
   @EventHandler
   public void handleMenuClick(InventoryClickEvent event) {
      if (event.getInventory().getHolder() instanceof MainHolder) {
         event.setCancelled(true);
         ItemStack item = event.getCurrentItem();
         if (item != null && item.getType() != Material.AIR) {
            ClickableHead.handleClick(event);
            Player player = (Player)event.getWhoClicked();
            String itemName = ChatColor.stripColor(item.getItemMeta().getDisplayName());
            if (itemName.equalsIgnoreCase("Next")) {
               EnhancedPay.foliaLib.getScheduler().runLater(() -> {
                  player.setItemOnCursor((ItemStack)null);
                  InventoryManager.openGUI(player, (Integer)InventoryManager.currentPage.get(player) + 1);
               }, 1L);
            } else if (itemName.equalsIgnoreCase("Previous")) {
               EnhancedPay.foliaLib.getScheduler().runLater(() -> {
                  player.setItemOnCursor((ItemStack)null);
                  InventoryManager.openGUI(player, (Integer)InventoryManager.currentPage.get(player) - 1);
               }, 1L);
            } else {
               OfflinePlayer target = checkSkull(item);
               if (target != null) {
                  String template = EnhancedPay.instance.getConfig().getString("gui.template");
                  (new TemplateGUI(template, "              Statistics", 36, target, new MainHolder())).open(player);
               }

               if (itemName.equalsIgnoreCase("back") || item.getItemMeta().getLore().stream().anyMatch((line) -> {
                  return line.equalsIgnoreCase("click to return");
               })) {
                  InventoryManager.openGUI(player, (Integer)InventoryManager.currentPage.get(player));
               }

            }
         }
      }
   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent event) {
      if (event.getInventory().getHolder() instanceof MainHolder) {
         ClickableHead.cleanup(event.getInventory());
      }

   }

   public static OfflinePlayer checkSkull(ItemStack skull) {
      OfflinePlayer target = null;

      try {
         target = ((SkullMeta)skull.getItemMeta()).getOwningPlayer();
      } catch (Exception var3) {
      }

      return target;
   }
}
