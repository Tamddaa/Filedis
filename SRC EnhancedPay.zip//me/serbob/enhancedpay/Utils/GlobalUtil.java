package me.serbob.enhancedpay.Utils;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.bukkit.ChatColor;

public class GlobalUtil {
   private static final Pattern HEX_PATTERN = Pattern.compile("&(#[A-Fa-f0-9]{6})");

   public static String c(String preColor) {
      return format(ChatColor.translateAlternateColorCodes('&', preColor));
   }

   private static String format(String string) {
      String var10001;
      String var10002;
      for(Matcher matcher = HEX_PATTERN.matcher(string); matcher.find(); string = string.replace(var10001, net.md_5.bungee.api.ChatColor.of(var10002.replace("&", "")).makeConcatWithConstants<invokedynamic>(net.md_5.bungee.api.ChatColor.of(var10002.replace("&", ""))))) {
         var10001 = matcher.group();
         var10002 = matcher.group();
      }

      return string;
   }

   public static List<String> colorizeList(List<String> list) {
      List<String> tempList = new ArrayList();
      Iterator var2 = list.iterator();

      while(var2.hasNext()) {
         String key = (String)var2.next();
         tempList.add(c(key));
      }

      return tempList;
   }
}
