package me.serbob.enhancedpay.Utils;

import me.serbob.enhancedpay.EnhancedPay;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

public class EconomyUtil {
   public static String getFormattedMoney(OfflinePlayer player) {
      double money = EnhancedPay.getEconomy().getBalance(Bukkit.getOfflinePlayer(player.getUniqueId()));
      String var10000 = EnhancedPay.getEconomy().currencyNamePlural();
      return var10000 + Format.formatPrice(money);
   }
}
