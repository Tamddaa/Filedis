package me.serbob.enhancedpay.Utils;

import me.serbob.enhancedpay.EnhancedPay;
import me.serbob.enhancedpay.Managers.VersionManager;
import me.serbob.enhancedpay.NMS.Usages.RefActionbar;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

public class ActionBar {
   public static void sendALLVersionsActionBar(Player player, String message) {
      if (VersionManager.isVersion1_8()) {
         RefActionbar.sendActionBarPacket(player, message);
      } else {
         if (EnhancedPay.instance.getConfig().getBoolean("send_message_too")) {
            player.sendMessage(GlobalUtil.c(message));
         }

         player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(message));
      }

   }

   public static void sendALLVersionsActionBarAndSound(Player player, String path) {
      String soundStr = EnhancedPay.instance.getConfig().getString("messages." + path + ".sound");
      String text = GlobalUtil.c(EnhancedPay.instance.getConfig().getString("messages." + path + ".text").replace("{bal}", EconomyUtil.getFormattedMoney(player)));
      if (text != null && !text.isEmpty()) {
         if (EnhancedPay.instance.getConfig().getBoolean("send_message_too")) {
            player.sendMessage(GlobalUtil.c(text));
         }

         Sound sound;
         if (VersionManager.isVersion1_8()) {
            RefActionbar.sendActionBarPacket(player, GlobalUtil.c(text));
            if (!soundStr.equalsIgnoreCase("NONE") && Sound.valueOf(soundStr.toUpperCase()) != null) {
               sound = Sound.valueOf(soundStr.toUpperCase());
               player.playSound(player.getLocation(), sound, 1.0F, 1.0F);
            }
         } else {
            player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(text));
            if (!soundStr.equalsIgnoreCase("NONE") && Sound.valueOf(soundStr.toUpperCase()) != null) {
               sound = Sound.valueOf(soundStr.toUpperCase());
               player.playSound(player.getLocation(), sound, 1.0F, 1.0F);
            }
         }

      }
   }

   public static void sendALLVersionsActionBarAndSound(Player player, String path, String message) {
      String soundStr = EnhancedPay.instance.getConfig().getString("messages." + path + ".sound");
      if (EnhancedPay.instance.getConfig().getBoolean("send_message_too")) {
         player.sendMessage(GlobalUtil.c(message));
      }

      Sound sound;
      if (VersionManager.isVersion1_8()) {
         RefActionbar.sendActionBarPacket(player, GlobalUtil.c(message));
         if (!soundStr.equalsIgnoreCase("NONE") && Sound.valueOf(soundStr.toUpperCase()) != null) {
            sound = Sound.valueOf(soundStr.toUpperCase());
            player.playSound(player.getLocation(), sound, 1.0F, 1.0F);
         }
      } else {
         player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(message));
         if (!soundStr.equalsIgnoreCase("NONE") && Sound.valueOf(soundStr.toUpperCase()) != null) {
            sound = Sound.valueOf(soundStr.toUpperCase());
            player.playSound(player.getLocation(), sound, 1.0F, 1.0F);
         }
      }

   }
}
