package me.serbob.enhancedpay.Utils;

import java.text.DecimalFormat;

public class Format {
   private static final DecimalFormat df = new DecimalFormat("#,##0.00");

   public static String formatPrice(double price) {
      if (price >= 1.0E12D) {
         return df.format(price / 1.0E12D) + "T";
      } else if (price >= 1.0E9D) {
         return df.format(price / 1.0E9D) + "B";
      } else if (price >= 1000000.0D) {
         return df.format(price / 1000000.0D) + "M";
      } else if (price >= 1000.0D) {
         return df.format(price / 1000.0D) + "K";
      } else {
         return price == (double)((long)price) ? String.format("%d", (long)price) : df.format(price);
      }
   }
}
