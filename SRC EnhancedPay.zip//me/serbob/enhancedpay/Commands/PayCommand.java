package me.serbob.enhancedpay.Commands;

import me.serbob.enhancedpay.EnhancedPay;
import me.serbob.enhancedpay.Utils.ActionBar;
import me.serbob.enhancedpay.Utils.Format;
import me.serbob.enhancedpay.Utils.GlobalUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PayCommand implements CommandExecutor {
   public boolean onCommand(CommandSender sender, Command command, String commandLabel, String[] args) {
      if (!(sender instanceof Player)) {
         Bukkit.getLogger().info("You are not a player.");
         return false;
      } else if (args.length < 2) {
         ActionBar.sendALLVersionsActionBarAndSound((Player)sender, "pay.usage");
         return false;
      } else {
         OfflinePlayer player = Bukkit.getOfflinePlayer(((Player)sender).getUniqueId());
         Player target = Bukkit.getPlayer(args[0]);
         if (target == null) {
            ActionBar.sendALLVersionsActionBarAndSound(player.getPlayer(), "not_found");
            return false;
         } else if (PayToggleCommand.hasPaymentsDisabled(target.getUniqueId())) {
            ActionBar.sendALLVersionsActionBarAndSound(player.getPlayer(), "pay.target_disabled");
            return false;
         } else {
            String amountStr = args[1].toLowerCase();

            double amount;
            try {
               if (amountStr.endsWith("k")) {
                  amount = Double.parseDouble(amountStr.substring(0, amountStr.length() - 1)) * 1000.0D;
               } else if (amountStr.endsWith("m")) {
                  amount = Double.parseDouble(amountStr.substring(0, amountStr.length() - 1)) * 1000000.0D;
               } else if (amountStr.endsWith("b")) {
                  amount = Double.parseDouble(amountStr.substring(0, amountStr.length() - 1)) * 1.0E9D;
               } else if (amountStr.endsWith("t")) {
                  amount = Double.parseDouble(amountStr.substring(0, amountStr.length() - 1)) * 1.0E12D;
               } else {
                  amount = Double.parseDouble(amountStr);
               }
            } catch (NumberFormatException var15) {
               ActionBar.sendALLVersionsActionBarAndSound(player.getPlayer(), "pay.error");
               return false;
            }

            double money = EnhancedPay.getEconomy().getBalance(player);
            if (amount > money) {
               ActionBar.sendALLVersionsActionBarAndSound(player.getPlayer(), "pay.insufficient");
               return false;
            } else {
               OfflinePlayer offlineTarget = Bukkit.getOfflinePlayer(target.getUniqueId());
               if (!offlineTarget.getUniqueId().equals(player.getUniqueId()) && !(amount <= 0.0D)) {
                  EnhancedPay.getEconomy().withdrawPlayer(player, amount);
                  EnhancedPay.getEconomy().depositPlayer(offlineTarget, amount);
                  String paySender = GlobalUtil.c(EnhancedPay.instance.getConfig().getString("messages.pay.sender.text").replace("{amount}", Format.formatPrice(amount)).replace("{receiver}", target.getName()));
                  ActionBar.sendALLVersionsActionBarAndSound(player.getPlayer(), "pay.sender", paySender);
                  if (!PayToggleCommand.hasAlertsDisabled(target.getUniqueId())) {
                     String payReceiver = GlobalUtil.c(EnhancedPay.instance.getConfig().getString("messages.pay.receiver.text").replace("{amount}", Format.formatPrice(amount)).replace("{sender}", player.getName()));
                     ActionBar.sendALLVersionsActionBarAndSound(target, "pay.receiver", payReceiver);
                  }

                  return true;
               } else {
                  ActionBar.sendALLVersionsActionBarAndSound(player.getPlayer(), "pay.invalid_amount");
                  return false;
               }
            }
         }
      }
   }
}
