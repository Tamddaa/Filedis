package me.serbob.enhancedpay.Commands;

import me.serbob.enhancedpay.EnhancedPay;
import me.serbob.enhancedpay.Utils.ActionBar;
import me.serbob.enhancedpay.Utils.EconomyUtil;
import me.serbob.enhancedpay.Utils.GlobalUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BalCommand implements CommandExecutor {
   public boolean onCommand(CommandSender sender, Command command, String commandLabel, String[] args) {
      if (!(sender instanceof Player)) {
         Bukkit.getLogger().info("You are not a player.");
         return true;
      } else {
         Player player = (Player)sender;
         if (args.length < 1) {
            ActionBar.sendALLVersionsActionBarAndSound(player, "balance.self");
         } else {
            Player target = Bukkit.getPlayer(args[0]);
            if (target == null) {
               ActionBar.sendALLVersionsActionBarAndSound(player.getPlayer(), "not_found");
               return false;
            }

            OfflinePlayer offlineTarget = Bukkit.getOfflinePlayer(target.getUniqueId());
            String balanceMsg = GlobalUtil.c(EnhancedPay.instance.getConfig().getString("messages.balance.someone.text").replace("{targetAmount}", EconomyUtil.getFormattedMoney(target)).replace("{target}", target.getName()));
            ActionBar.sendALLVersionsActionBarAndSound(player, "balance.someone", balanceMsg);
         }

         return true;
      }
   }
}
