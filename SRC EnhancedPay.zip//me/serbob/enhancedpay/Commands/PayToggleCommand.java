package me.serbob.enhancedpay.Commands;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import me.serbob.enhancedpay.EnhancedPay;
import me.serbob.enhancedpay.Utils.ActionBar;
import me.serbob.enhancedpay.Utils.GlobalUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class PayToggleCommand implements CommandExecutor, TabCompleter {
   private static final Set<UUID> paymentsDisabled = new HashSet();
   private static final Set<UUID> alertsDisabled = new HashSet();

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (sender instanceof Player) {
         Player player = (Player)sender;
         if (!sender.hasPermission("epay.toggle")) {
            ActionBar.sendALLVersionsActionBarAndSound(player, "paytoggle.no_permission");
            return false;
         } else if (args.length < 1) {
            ActionBar.sendALLVersionsActionBarAndSound(player, "paytoggle.usage");
            return false;
         } else {
            String toggleType = args[0].toLowerCase();
            UUID playerUUID = player.getUniqueId();
            byte var9 = -1;
            switch(toggleType.hashCode()) {
            case -1415077225:
               if (toggleType.equals("alerts")) {
                  var9 = 0;
               }
               break;
            case 1382682413:
               if (toggleType.equals("payments")) {
                  var9 = 1;
               }
            }

            switch(var9) {
            case 0:
               if (alertsDisabled.contains(playerUUID)) {
                  alertsDisabled.remove(playerUUID);
                  ActionBar.sendALLVersionsActionBarAndSound(player, "paytoggle.alerts_enabled");
               } else {
                  alertsDisabled.add(playerUUID);
                  ActionBar.sendALLVersionsActionBarAndSound(player, "paytoggle.alerts_disabled");
               }
               break;
            case 1:
               if (paymentsDisabled.contains(playerUUID)) {
                  paymentsDisabled.remove(playerUUID);
                  ActionBar.sendALLVersionsActionBarAndSound(player, "paytoggle.payments_enabled");
               } else {
                  paymentsDisabled.add(playerUUID);
                  ActionBar.sendALLVersionsActionBarAndSound(player, "paytoggle.payments_disabled");
               }
               break;
            default:
               ActionBar.sendALLVersionsActionBarAndSound(player, "paytoggle.invalid_type");
               return false;
            }

            return true;
         }
      } else {
         sender.sendMessage(GlobalUtil.c(EnhancedPay.instance.getConfig().getString("messages.paytoggle.console_error", "&cOnly players can use this command!")));
         return false;
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      return args.length == 1 ? Arrays.asList("alerts", "payments") : Collections.emptyList();
   }

   public static boolean hasPaymentsDisabled(UUID playerUUID) {
      return paymentsDisabled.contains(playerUUID);
   }

   public static boolean hasAlertsDisabled(UUID playerUUID) {
      return alertsDisabled.contains(playerUUID);
   }
}
