package me.serbob.enhancedpay.Commands;

import me.serbob.enhancedpay.Managers.Inventory.InventoryManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BaltopCommand implements CommandExecutor {
   public boolean onCommand(CommandSender sender, Command command, String commandLabel, String[] args) {
      if (!(sender instanceof Player)) {
         Bukkit.getLogger().info("You are not a player.");
         return true;
      } else {
         Player player = (Player)sender;
         InventoryManager.openGUI(player, 1);
         return true;
      }
   }
}
