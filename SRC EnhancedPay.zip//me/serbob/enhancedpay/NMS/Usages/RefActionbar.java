package me.serbob.enhancedpay.NMS.Usages;

import java.lang.reflect.Constructor;
import me.serbob.enhancedpay.NMS.Reflection;
import org.bukkit.entity.Player;

public class RefActionbar {
   public static void sendActionBarPacket(Player player, String actionbarText) {
      Object playerHandle = Reflection.getPlayerHandle(player);
      Object playerConnection = Reflection.getPlayerConnection(playerHandle);
      Object actionbarPacket = createActionbarPacket(actionbarText);
      Reflection.sendPacket(playerConnection, actionbarPacket);
   }

   public static Object createActionbarPacket(String component) {
      try {
         Class<?> actionBarPacketClass = Reflection.getNMSClass("PacketPlayOutChat");
         Object chatComponent = Reflection.createIChatBaseComponent(component);
         Constructor<?> actionBarPacketConstructor = actionBarPacketClass.getConstructor(Reflection.getNMSClass("IChatBaseComponent"), Byte.TYPE);
         byte actionBarMessageType = 2;
         return actionBarPacketConstructor.newInstance(chatComponent, actionBarMessageType);
      } catch (Exception var5) {
         return null;
      }
   }
}
