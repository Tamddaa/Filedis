package me.serbob.donutteams.lib.folialib.impl;

import java.lang.reflect.Method;
import java.util.concurrent.CompletableFuture;
import me.serbob.donutteams.lib.folialib.FoliaLib;
import me.serbob.donutteams.lib.folialib.util.ImplementationTestsUtil;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;

public class PaperImplementation extends SpigotImplementation {
   private final FoliaLib foliaLib;
   private Method teleportAsyncMethod;

   public PaperImplementation(FoliaLib foliaLib) {
      super(foliaLib);
      this.foliaLib = foliaLib;
      if (ImplementationTestsUtil.isAsyncTeleportSupported()) {
         try {
            this.teleportAsyncMethod = Entity.class.getMethod("teleportAsync", Location.class, TeleportCause.class);
         } catch (NoSuchMethodException var3) {
            throw new RuntimeException("Failed to initialize PaperImplementation", var3);
         }
      }

   }

   public CompletableFuture<Boolean> teleportAsync(Entity entity, Location location) {
      return this.teleportAsync(entity, location, TeleportCause.PLUGIN);
   }

   public CompletableFuture<Boolean> teleportAsync(Entity entity, Location location, TeleportCause cause) {
      if (!ImplementationTestsUtil.isAsyncTeleportSupported()) {
         return super.teleportAsync(entity, location, cause);
      } else {
         try {
            return (CompletableFuture)this.teleportAsyncMethod.invoke(entity, location, cause);
         } catch (Exception var5) {
            var5.printStackTrace();
            return super.teleportAsync(entity, location, cause);
         }
      }
   }
}
