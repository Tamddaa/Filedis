package me.serbob.donutteams.lib.folialib.impl;

public interface PlatformScheduler extends ServerImplementation {
}
