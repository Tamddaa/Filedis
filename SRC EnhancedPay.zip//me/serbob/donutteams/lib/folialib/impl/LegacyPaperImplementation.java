package me.serbob.donutteams.lib.folialib.impl;

import me.serbob.donutteams.lib.folialib.FoliaLib;

public class LegacyPaperImplementation extends LegacySpigotImplementation {
   public LegacyPaperImplementation(FoliaLib foliaLib) {
      super(foliaLib);
   }
}
